import { B as select_default, H as __name, U as log } from "./src-BFTritsu.js";
import { O as getUrl, T as getEffectiveHtmlLabels, a as clear, b as getConfig, c as configureSvgSize, rt as rgba, s as common_default, x as getConfig2, z as sanitizeText } from "./chunk-CSCIHK7Q-CtOBMFgQ.js";
import { t as channel } from "./channel-Cgxxj64V.js";
import { A as float64ArrayTag, B as symbolTag, C as argumentsTag, D as dataViewTag, E as booleanTag, F as numberTag, G as getTag, H as uint32ArrayTag, I as objectTag, L as regexpTag, M as int32ArrayTag, N as int8ArrayTag, O as dateTag, P as mapTag, R as setTag, T as arrayTag, U as uint8ArrayTag, V as uint16ArrayTag, W as uint8ClampedArrayTag, a as decodeEntities, b as isPrimitive, et as basis_default, g as utils_default, j as int16ArrayTag, k as float32ArrayTag, l as getStylesFromArray, v as isTypedArray, w as arrayBufferTag, z as stringTag } from "./chunk-5ZQYHXKU-UjcI8I9R.js";
import { t as line_default } from "./line-BJHAE_bE.js";
import { n as getLineFunctionsWithOffset, t as computeLabelTransform } from "./chunk-BSJP7CBP-CWPjFAHg.js";
import { n as getSubGraphTitleMargins, t as configureLabelImages } from "./chunk-L5ZTLDWV-CbQVxUrJ.js";
import { n as createText } from "./chunk-O5CBEL6O-BMotHkza.js";
import { t as getIconStyles } from "./chunk-FMBD7UC4-XHAf4gn8.js";
import { t as Graph } from "./graphlib-CuBzuzYC.js";
//#region node_modules/es-toolkit/dist/compat/predicate/isArray.mjs
/**
* Checks if the given value is an array.
*
* This function tests whether the provided value is an array or not.
* It returns `true` if the value is an array, and `false` otherwise.
*
* This function can also serve as a type predicate in TypeScript, narrowing the type of the argument to an array.
*
* @param {any} value - The value to test if it is an array.
* @returns {value is any[]} `true` if the value is an array, `false` otherwise.
*
* @example
* const value1 = [1, 2, 3];
* const value2 = 'abc';
* const value3 = () => {};
*
* console.log(isArray(value1)); // true
* console.log(isArray(value2)); // false
* console.log(isArray(value3)); // false
*/
function isArray(value) {
	return Array.isArray(value);
}
//#endregion
//#region node_modules/es-toolkit/dist/compat/object/clone.mjs
/**
* Creates a shallow clone of the given object.
*
* @template T - The type of the object.
* @param {T} obj - The object to clone.
* @returns {T} - A shallow clone of the given object.
*
* @example
* // Clone a primitive objs
* const num = 29;
* const clonedNum = clone(num);
* console.log(clonedNum); // 29
* console.log(clonedNum === num); // true
*
* @example
* // Clone an array
* const arr = [1, 2, 3];
* const clonedArr = clone(arr);
* console.log(clonedArr); // [1, 2, 3]
* console.log(clonedArr === arr); // false
*
* @example
* // Clone an object
* const obj = { a: 1, b: 'es-toolkit', c: [1, 2, 3] };
* const clonedObj = clone(obj);
* console.log(clonedObj); // { a: 1, b: 'es-toolkit', c: [1, 2, 3] }
* console.log(clonedObj === obj); // false
*/
function clone(obj) {
	if (isPrimitive(obj)) return obj;
	const tag = getTag(obj);
	if (!isCloneableObject(obj)) return {};
	if (isArray(obj)) {
		const result = Array.from(obj);
		if (obj.length > 0 && typeof obj[0] === "string" && Object.hasOwn(obj, "index")) {
			result.index = obj.index;
			result.input = obj.input;
		}
		return result;
	}
	if (isTypedArray(obj)) {
		const typedArray = obj;
		const Ctor = typedArray.constructor;
		return new Ctor(typedArray.buffer, typedArray.byteOffset, typedArray.length);
	}
	if (tag === "[object ArrayBuffer]") return new ArrayBuffer(obj.byteLength);
	if (tag === "[object DataView]") {
		const dataView = obj;
		const buffer = dataView.buffer;
		const byteOffset = dataView.byteOffset;
		const byteLength = dataView.byteLength;
		const clonedBuffer = new ArrayBuffer(byteLength);
		const srcView = new Uint8Array(buffer, byteOffset, byteLength);
		new Uint8Array(clonedBuffer).set(srcView);
		return new DataView(clonedBuffer);
	}
	if (tag === "[object Boolean]" || tag === "[object Number]" || tag === "[object String]") {
		const Ctor = obj.constructor;
		const clone = new Ctor(obj.valueOf());
		if (tag === "[object String]") cloneStringObjectProperties(clone, obj);
		else copyOwnProperties(clone, obj);
		return clone;
	}
	if (tag === "[object Date]") return new Date(Number(obj));
	if (tag === "[object RegExp]") {
		const regExp = obj;
		const clone = new RegExp(regExp.source, regExp.flags);
		clone.lastIndex = regExp.lastIndex;
		return clone;
	}
	if (tag === "[object Symbol]") return Object(Symbol.prototype.valueOf.call(obj));
	if (tag === "[object Map]") {
		const map = obj;
		const result = /* @__PURE__ */ new Map();
		map.forEach((obj, key) => {
			result.set(key, obj);
		});
		return result;
	}
	if (tag === "[object Set]") {
		const set = obj;
		const result = /* @__PURE__ */ new Set();
		set.forEach((obj) => {
			result.add(obj);
		});
		return result;
	}
	if (tag === "[object Arguments]") {
		const args = obj;
		const result = {};
		copyOwnProperties(result, args);
		result.length = args.length;
		result[Symbol.iterator] = args[Symbol.iterator];
		return result;
	}
	const result = {};
	copyPrototype(result, obj);
	copyOwnProperties(result, obj);
	copySymbolProperties(result, obj);
	return result;
}
function isCloneableObject(object) {
	switch (getTag(object)) {
		case argumentsTag:
		case arrayTag:
		case arrayBufferTag:
		case dataViewTag:
		case booleanTag:
		case dateTag:
		case float32ArrayTag:
		case float64ArrayTag:
		case int8ArrayTag:
		case int16ArrayTag:
		case int32ArrayTag:
		case mapTag:
		case numberTag:
		case objectTag:
		case regexpTag:
		case setTag:
		case stringTag:
		case symbolTag:
		case uint8ArrayTag:
		case uint8ClampedArrayTag:
		case uint16ArrayTag:
		case uint32ArrayTag: return true;
		default: return false;
	}
}
function copyOwnProperties(target, source) {
	for (const key in source) if (Object.hasOwn(source, key)) target[key] = source[key];
}
function copySymbolProperties(target, source) {
	const symbols = Object.getOwnPropertySymbols(source);
	for (let i = 0; i < symbols.length; i++) {
		const symbol = symbols[i];
		if (Object.prototype.propertyIsEnumerable.call(source, symbol)) target[symbol] = source[symbol];
	}
}
function cloneStringObjectProperties(target, source) {
	const stringLength = source.valueOf().length;
	for (const key in source) if (Object.hasOwn(source, key) && (Number.isNaN(Number(key)) || Number(key) >= stringLength)) target[key] = source[key];
}
function copyPrototype(target, source) {
	const proto = Object.getPrototypeOf(source);
	if (proto !== null) {
		if (typeof source.constructor === "function") Object.setPrototypeOf(target, proto);
	}
}
//#endregion
//#region node_modules/mermaid/dist/chunks/mermaid.core/blockDiagram-GPEHLZMM.mjs
var parser = (function() {
	var o = /* @__PURE__ */ __name(function(k, v, o2, l) {
		for (o2 = o2 || {}, l = k.length; l--; o2[k[l]] = v);
		return o2;
	}, "o"), $V0 = [1, 15], $V1 = [1, 7], $V2 = [1, 13], $V3 = [1, 14], $V4 = [1, 19], $V5 = [1, 16], $V6 = [1, 17], $V7 = [1, 18], $V8 = [8, 30], $V9 = [
		8,
		10,
		21,
		28,
		29,
		30,
		31,
		39,
		43,
		46
	], $Va = [1, 23], $Vb = [1, 24], $Vc = [
		8,
		10,
		15,
		16,
		21,
		28,
		29,
		30,
		31,
		39,
		43,
		46
	], $Vd = [
		8,
		10,
		15,
		16,
		21,
		27,
		28,
		29,
		30,
		31,
		39,
		43,
		46
	], $Ve = [1, 49];
	var parser2 = {
		trace: /* @__PURE__ */ __name(function trace() {}, "trace"),
		yy: {},
		symbols_: {
			"error": 2,
			"spaceLines": 3,
			"SPACELINE": 4,
			"NL": 5,
			"separator": 6,
			"SPACE": 7,
			"EOF": 8,
			"start": 9,
			"BLOCK_DIAGRAM_KEY": 10,
			"document": 11,
			"stop": 12,
			"statement": 13,
			"link": 14,
			"LINK": 15,
			"START_LINK": 16,
			"LINK_LABEL": 17,
			"STR": 18,
			"nodeStatement": 19,
			"columnsStatement": 20,
			"SPACE_BLOCK": 21,
			"blockStatement": 22,
			"classDefStatement": 23,
			"cssClassStatement": 24,
			"styleStatement": 25,
			"node": 26,
			"SIZE": 27,
			"COLUMNS": 28,
			"id-block": 29,
			"end": 30,
			"NODE_ID": 31,
			"nodeShapeNLabel": 32,
			"dirList": 33,
			"DIR": 34,
			"NODE_DSTART": 35,
			"NODE_DEND": 36,
			"BLOCK_ARROW_START": 37,
			"BLOCK_ARROW_END": 38,
			"classDef": 39,
			"CLASSDEF_ID": 40,
			"CLASSDEF_STYLEOPTS": 41,
			"DEFAULT": 42,
			"class": 43,
			"CLASSENTITY_IDS": 44,
			"STYLECLASS": 45,
			"style": 46,
			"STYLE_ENTITY_IDS": 47,
			"STYLE_DEFINITION_DATA": 48,
			"$accept": 0,
			"$end": 1
		},
		terminals_: {
			2: "error",
			4: "SPACELINE",
			5: "NL",
			7: "SPACE",
			8: "EOF",
			10: "BLOCK_DIAGRAM_KEY",
			15: "LINK",
			16: "START_LINK",
			17: "LINK_LABEL",
			18: "STR",
			21: "SPACE_BLOCK",
			27: "SIZE",
			28: "COLUMNS",
			29: "id-block",
			30: "end",
			31: "NODE_ID",
			34: "DIR",
			35: "NODE_DSTART",
			36: "NODE_DEND",
			37: "BLOCK_ARROW_START",
			38: "BLOCK_ARROW_END",
			39: "classDef",
			40: "CLASSDEF_ID",
			41: "CLASSDEF_STYLEOPTS",
			42: "DEFAULT",
			43: "class",
			44: "CLASSENTITY_IDS",
			45: "STYLECLASS",
			46: "style",
			47: "STYLE_ENTITY_IDS",
			48: "STYLE_DEFINITION_DATA"
		},
		productions_: [
			0,
			[3, 1],
			[3, 2],
			[3, 2],
			[6, 1],
			[6, 1],
			[6, 1],
			[9, 3],
			[12, 1],
			[12, 1],
			[12, 2],
			[12, 2],
			[11, 1],
			[11, 2],
			[14, 1],
			[14, 4],
			[13, 1],
			[13, 1],
			[13, 1],
			[13, 1],
			[13, 1],
			[13, 1],
			[13, 1],
			[19, 3],
			[19, 2],
			[19, 1],
			[20, 1],
			[22, 4],
			[22, 3],
			[26, 1],
			[26, 2],
			[33, 1],
			[33, 2],
			[32, 3],
			[32, 4],
			[23, 3],
			[23, 3],
			[24, 3],
			[25, 3]
		],
		performAction: /* @__PURE__ */ __name(function anonymous(yytext, yyleng, yylineno, yy, yystate, $$, _$) {
			var $0 = $$.length - 1;
			switch (yystate) {
				case 4:
					yy.getLogger().debug("Rule: separator (NL) ");
					break;
				case 5:
					yy.getLogger().debug("Rule: separator (Space) ");
					break;
				case 6:
					yy.getLogger().debug("Rule: separator (EOF) ");
					break;
				case 7:
					yy.getLogger().debug("Rule: hierarchy: ", $$[$0 - 1]);
					yy.setHierarchy($$[$0 - 1]);
					break;
				case 8:
					yy.getLogger().debug("Stop NL ");
					break;
				case 9:
					yy.getLogger().debug("Stop EOF ");
					break;
				case 10:
					yy.getLogger().debug("Stop NL2 ");
					break;
				case 11:
					yy.getLogger().debug("Stop EOF2 ");
					break;
				case 12:
					yy.getLogger().debug("Rule: statement: ", $$[$0]);
					typeof $$[$0].length === "number" ? this.$ = $$[$0] : this.$ = [$$[$0]];
					break;
				case 13:
					yy.getLogger().debug("Rule: statement #2: ", $$[$0 - 1]);
					this.$ = [$$[$0 - 1]].concat($$[$0]);
					break;
				case 14:
					yy.getLogger().debug("Rule: link: ", $$[$0], yytext);
					this.$ = {
						edgeTypeStr: $$[$0],
						label: ""
					};
					break;
				case 15:
					yy.getLogger().debug("Rule: LABEL link: ", $$[$0 - 3], $$[$0 - 1], $$[$0]);
					this.$ = {
						edgeTypeStr: $$[$0],
						label: $$[$0 - 1]
					};
					break;
				case 18:
					const num = parseInt($$[$0]);
					const spaceId = yy.generateId();
					this.$ = {
						id: spaceId,
						type: "space",
						label: "",
						width: num,
						children: []
					};
					break;
				case 23:
					yy.getLogger().debug("Rule: (nodeStatement link node) ", $$[$0 - 2], $$[$0 - 1], $$[$0], " typestr: ", $$[$0 - 1].edgeTypeStr);
					const edgeData = yy.edgeStrToEdgeData($$[$0 - 1].edgeTypeStr);
					const startEdgeData = yy.edgeStrToEdgeStartData($$[$0 - 1].edgeTypeStr);
					const lineThickness = yy.edgeStrToThickness($$[$0 - 1].edgeTypeStr);
					const linePattern = yy.edgeStrToPattern($$[$0 - 1].edgeTypeStr);
					this.$ = [
						{
							id: $$[$0 - 2].id,
							label: $$[$0 - 2].label,
							type: $$[$0 - 2].type,
							directions: $$[$0 - 2].directions
						},
						{
							id: $$[$0 - 2].id + "-" + $$[$0].id,
							start: $$[$0 - 2].id,
							end: $$[$0].id,
							label: $$[$0 - 1].label,
							type: "edge",
							thickness: lineThickness,
							pattern: linePattern,
							directions: $$[$0].directions,
							arrowTypeEnd: edgeData,
							arrowTypeStart: startEdgeData
						},
						{
							id: $$[$0].id,
							label: $$[$0].label,
							type: yy.typeStr2Type($$[$0].typeStr),
							directions: $$[$0].directions
						}
					];
					break;
				case 24:
					yy.getLogger().debug("Rule: nodeStatement (abc88 node size) ", $$[$0 - 1], $$[$0]);
					this.$ = {
						id: $$[$0 - 1].id,
						label: $$[$0 - 1].label,
						type: yy.typeStr2Type($$[$0 - 1].typeStr),
						directions: $$[$0 - 1].directions,
						widthInColumns: parseInt($$[$0], 10)
					};
					break;
				case 25:
					yy.getLogger().debug("Rule: nodeStatement (node) ", $$[$0]);
					this.$ = {
						id: $$[$0].id,
						label: $$[$0].label,
						type: yy.typeStr2Type($$[$0].typeStr),
						directions: $$[$0].directions,
						widthInColumns: 1
					};
					break;
				case 26:
					yy.getLogger().debug("APA123", this ? this : "na");
					yy.getLogger().debug("COLUMNS: ", $$[$0]);
					this.$ = {
						type: "column-setting",
						columns: $$[$0] === "auto" ? -1 : parseInt($$[$0])
					};
					break;
				case 27:
					yy.getLogger().debug("Rule: id-block statement : ", $$[$0 - 2], $$[$0 - 1]);
					yy.generateId();
					this.$ = {
						...$$[$0 - 2],
						type: "composite",
						children: $$[$0 - 1]
					};
					break;
				case 28:
					yy.getLogger().debug("Rule: blockStatement : ", $$[$0 - 2], $$[$0 - 1], $$[$0]);
					const id = yy.generateId();
					this.$ = {
						id,
						type: "composite",
						label: "",
						children: $$[$0 - 1]
					};
					break;
				case 29:
					yy.getLogger().debug("Rule: node (NODE_ID separator): ", $$[$0]);
					this.$ = { id: $$[$0] };
					break;
				case 30:
					yy.getLogger().debug("Rule: node (NODE_ID nodeShapeNLabel separator): ", $$[$0 - 1], $$[$0]);
					this.$ = {
						id: $$[$0 - 1],
						label: $$[$0].label,
						typeStr: $$[$0].typeStr,
						directions: $$[$0].directions
					};
					break;
				case 31:
					yy.getLogger().debug("Rule: dirList: ", $$[$0]);
					this.$ = [$$[$0]];
					break;
				case 32:
					yy.getLogger().debug("Rule: dirList: ", $$[$0 - 1], $$[$0]);
					this.$ = [$$[$0 - 1]].concat($$[$0]);
					break;
				case 33:
					yy.getLogger().debug("Rule: nodeShapeNLabel: ", $$[$0 - 2], $$[$0 - 1], $$[$0]);
					this.$ = {
						typeStr: $$[$0 - 2] + $$[$0],
						label: $$[$0 - 1]
					};
					break;
				case 34:
					yy.getLogger().debug("Rule: BLOCK_ARROW nodeShapeNLabel: ", $$[$0 - 3], $$[$0 - 2], " #3:", $$[$0 - 1], $$[$0]);
					this.$ = {
						typeStr: $$[$0 - 3] + $$[$0],
						label: $$[$0 - 2],
						directions: $$[$0 - 1]
					};
					break;
				case 35:
				case 36:
					this.$ = {
						type: "classDef",
						id: $$[$0 - 1].trim(),
						css: $$[$0].trim()
					};
					break;
				case 37:
					this.$ = {
						type: "applyClass",
						id: $$[$0 - 1].trim(),
						styleClass: $$[$0].trim()
					};
					break;
				case 38:
					this.$ = {
						type: "applyStyles",
						id: $$[$0 - 1].trim(),
						stylesStr: $$[$0].trim()
					};
					break;
			}
		}, "anonymous"),
		table: [
			{
				9: 1,
				10: [1, 2]
			},
			{ 1: [3] },
			{
				10: $V0,
				11: 3,
				13: 4,
				19: 5,
				20: 6,
				21: $V1,
				22: 8,
				23: 9,
				24: 10,
				25: 11,
				26: 12,
				28: $V2,
				29: $V3,
				31: $V4,
				39: $V5,
				43: $V6,
				46: $V7
			},
			{ 8: [1, 20] },
			o($V8, [2, 12], {
				13: 4,
				19: 5,
				20: 6,
				22: 8,
				23: 9,
				24: 10,
				25: 11,
				26: 12,
				11: 21,
				10: $V0,
				21: $V1,
				28: $V2,
				29: $V3,
				31: $V4,
				39: $V5,
				43: $V6,
				46: $V7
			}),
			o($V9, [2, 16], {
				14: 22,
				15: $Va,
				16: $Vb
			}),
			o($V9, [2, 17]),
			o($V9, [2, 18]),
			o($V9, [2, 19]),
			o($V9, [2, 20]),
			o($V9, [2, 21]),
			o($V9, [2, 22]),
			o($Vc, [2, 25], { 27: [1, 25] }),
			o($V9, [2, 26]),
			{
				19: 26,
				26: 12,
				31: $V4
			},
			{
				10: $V0,
				11: 27,
				13: 4,
				19: 5,
				20: 6,
				21: $V1,
				22: 8,
				23: 9,
				24: 10,
				25: 11,
				26: 12,
				28: $V2,
				29: $V3,
				31: $V4,
				39: $V5,
				43: $V6,
				46: $V7
			},
			{
				40: [1, 28],
				42: [1, 29]
			},
			{ 44: [1, 30] },
			{ 47: [1, 31] },
			o($Vd, [2, 29], {
				32: 32,
				35: [1, 33],
				37: [1, 34]
			}),
			{ 1: [2, 7] },
			o($V8, [2, 13]),
			{
				26: 35,
				31: $V4
			},
			{ 31: [2, 14] },
			{ 17: [1, 36] },
			o($Vc, [2, 24]),
			{
				10: $V0,
				11: 37,
				13: 4,
				14: 22,
				15: $Va,
				16: $Vb,
				19: 5,
				20: 6,
				21: $V1,
				22: 8,
				23: 9,
				24: 10,
				25: 11,
				26: 12,
				28: $V2,
				29: $V3,
				31: $V4,
				39: $V5,
				43: $V6,
				46: $V7
			},
			{ 30: [1, 38] },
			{ 41: [1, 39] },
			{ 41: [1, 40] },
			{ 45: [1, 41] },
			{ 48: [1, 42] },
			o($Vd, [2, 30]),
			{ 18: [1, 43] },
			{ 18: [1, 44] },
			o($Vc, [2, 23]),
			{ 18: [1, 45] },
			{ 30: [1, 46] },
			o($V9, [2, 28]),
			o($V9, [2, 35]),
			o($V9, [2, 36]),
			o($V9, [2, 37]),
			o($V9, [2, 38]),
			{ 36: [1, 47] },
			{
				33: 48,
				34: $Ve
			},
			{ 15: [1, 50] },
			o($V9, [2, 27]),
			o($Vd, [2, 33]),
			{ 38: [1, 51] },
			{
				33: 52,
				34: $Ve,
				38: [2, 31]
			},
			{ 31: [2, 15] },
			o($Vd, [2, 34]),
			{ 38: [2, 32] }
		],
		defaultActions: {
			20: [2, 7],
			23: [2, 14],
			50: [2, 15],
			52: [2, 32]
		},
		parseError: /* @__PURE__ */ __name(function parseError(str, hash) {
			if (hash.recoverable) this.trace(str);
			else {
				var error = new Error(str);
				error.hash = hash;
				throw error;
			}
		}, "parseError"),
		parse: /* @__PURE__ */ __name(function parse(input) {
			var self = this, stack = [0], tstack = [], vstack = [null], lstack = [], table = this.table, yytext = "", yylineno = 0, yyleng = 0, recovering = 0, TERROR = 2, EOF = 1;
			var args = lstack.slice.call(arguments, 1);
			var lexer2 = Object.create(this.lexer);
			var sharedState = { yy: {} };
			for (var k in this.yy) if (Object.prototype.hasOwnProperty.call(this.yy, k)) sharedState.yy[k] = this.yy[k];
			lexer2.setInput(input, sharedState.yy);
			sharedState.yy.lexer = lexer2;
			sharedState.yy.parser = this;
			if (typeof lexer2.yylloc == "undefined") lexer2.yylloc = {};
			var yyloc = lexer2.yylloc;
			lstack.push(yyloc);
			var ranges = lexer2.options && lexer2.options.ranges;
			if (typeof sharedState.yy.parseError === "function") this.parseError = sharedState.yy.parseError;
			else this.parseError = Object.getPrototypeOf(this).parseError;
			function popStack(n) {
				stack.length = stack.length - 2 * n;
				vstack.length = vstack.length - n;
				lstack.length = lstack.length - n;
			}
			__name(popStack, "popStack");
			function lex() {
				var token = tstack.pop() || lexer2.lex() || EOF;
				if (typeof token !== "number") {
					if (token instanceof Array) {
						tstack = token;
						token = tstack.pop();
					}
					token = self.symbols_[token] || token;
				}
				return token;
			}
			__name(lex, "lex");
			var symbol, preErrorSymbol, state, action, r, yyval = {}, p, len, newState, expected;
			while (true) {
				state = stack[stack.length - 1];
				if (this.defaultActions[state]) action = this.defaultActions[state];
				else {
					if (symbol === null || typeof symbol == "undefined") symbol = lex();
					action = table[state] && table[state][symbol];
				}
				if (typeof action === "undefined" || !action.length || !action[0]) {
					var errStr = "";
					expected = [];
					for (p in table[state]) if (this.terminals_[p] && p > TERROR) expected.push("'" + this.terminals_[p] + "'");
					if (lexer2.showPosition) errStr = "Parse error on line " + (yylineno + 1) + ":\n" + lexer2.showPosition() + "\nExpecting " + expected.join(", ") + ", got '" + (this.terminals_[symbol] || symbol) + "'";
					else errStr = "Parse error on line " + (yylineno + 1) + ": Unexpected " + (symbol == EOF ? "end of input" : "'" + (this.terminals_[symbol] || symbol) + "'");
					this.parseError(errStr, {
						text: lexer2.match,
						token: this.terminals_[symbol] || symbol,
						line: lexer2.yylineno,
						loc: yyloc,
						expected
					});
				}
				if (action[0] instanceof Array && action.length > 1) throw new Error("Parse Error: multiple actions possible at state: " + state + ", token: " + symbol);
				switch (action[0]) {
					case 1:
						stack.push(symbol);
						vstack.push(lexer2.yytext);
						lstack.push(lexer2.yylloc);
						stack.push(action[1]);
						symbol = null;
						if (!preErrorSymbol) {
							yyleng = lexer2.yyleng;
							yytext = lexer2.yytext;
							yylineno = lexer2.yylineno;
							yyloc = lexer2.yylloc;
							if (recovering > 0) recovering--;
						} else {
							symbol = preErrorSymbol;
							preErrorSymbol = null;
						}
						break;
					case 2:
						len = this.productions_[action[1]][1];
						yyval.$ = vstack[vstack.length - len];
						yyval._$ = {
							first_line: lstack[lstack.length - (len || 1)].first_line,
							last_line: lstack[lstack.length - 1].last_line,
							first_column: lstack[lstack.length - (len || 1)].first_column,
							last_column: lstack[lstack.length - 1].last_column
						};
						if (ranges) yyval._$.range = [lstack[lstack.length - (len || 1)].range[0], lstack[lstack.length - 1].range[1]];
						r = this.performAction.apply(yyval, [
							yytext,
							yyleng,
							yylineno,
							sharedState.yy,
							action[1],
							vstack,
							lstack
						].concat(args));
						if (typeof r !== "undefined") return r;
						if (len) {
							stack = stack.slice(0, -1 * len * 2);
							vstack = vstack.slice(0, -1 * len);
							lstack = lstack.slice(0, -1 * len);
						}
						stack.push(this.productions_[action[1]][0]);
						vstack.push(yyval.$);
						lstack.push(yyval._$);
						newState = table[stack[stack.length - 2]][stack[stack.length - 1]];
						stack.push(newState);
						break;
					case 3: return true;
				}
			}
			return true;
		}, "parse")
	};
	parser2.lexer = /* @__PURE__ */ (function() {
		return {
			EOF: 1,
			parseError: /* @__PURE__ */ __name(function parseError(str, hash) {
				if (this.yy.parser) this.yy.parser.parseError(str, hash);
				else throw new Error(str);
			}, "parseError"),
			setInput: /* @__PURE__ */ __name(function(input, yy) {
				this.yy = yy || this.yy || {};
				this._input = input;
				this._more = this._backtrack = this.done = false;
				this.yylineno = this.yyleng = 0;
				this.yytext = this.matched = this.match = "";
				this.conditionStack = ["INITIAL"];
				this.yylloc = {
					first_line: 1,
					first_column: 0,
					last_line: 1,
					last_column: 0
				};
				if (this.options.ranges) this.yylloc.range = [0, 0];
				this.offset = 0;
				return this;
			}, "setInput"),
			input: /* @__PURE__ */ __name(function() {
				var ch = this._input[0];
				this.yytext += ch;
				this.yyleng++;
				this.offset++;
				this.match += ch;
				this.matched += ch;
				if (ch.match(/(?:\r\n?|\n).*/g)) {
					this.yylineno++;
					this.yylloc.last_line++;
				} else this.yylloc.last_column++;
				if (this.options.ranges) this.yylloc.range[1]++;
				this._input = this._input.slice(1);
				return ch;
			}, "input"),
			unput: /* @__PURE__ */ __name(function(ch) {
				var len = ch.length;
				var lines = ch.split(/(?:\r\n?|\n)/g);
				this._input = ch + this._input;
				this.yytext = this.yytext.substr(0, this.yytext.length - len);
				this.offset -= len;
				var oldLines = this.match.split(/(?:\r\n?|\n)/g);
				this.match = this.match.substr(0, this.match.length - 1);
				this.matched = this.matched.substr(0, this.matched.length - 1);
				if (lines.length - 1) this.yylineno -= lines.length - 1;
				var r = this.yylloc.range;
				this.yylloc = {
					first_line: this.yylloc.first_line,
					last_line: this.yylineno + 1,
					first_column: this.yylloc.first_column,
					last_column: lines ? (lines.length === oldLines.length ? this.yylloc.first_column : 0) + oldLines[oldLines.length - lines.length].length - lines[0].length : this.yylloc.first_column - len
				};
				if (this.options.ranges) this.yylloc.range = [r[0], r[0] + this.yyleng - len];
				this.yyleng = this.yytext.length;
				return this;
			}, "unput"),
			more: /* @__PURE__ */ __name(function() {
				this._more = true;
				return this;
			}, "more"),
			reject: /* @__PURE__ */ __name(function() {
				if (this.options.backtrack_lexer) this._backtrack = true;
				else return this.parseError("Lexical error on line " + (this.yylineno + 1) + ". You can only invoke reject() in the lexer when the lexer is of the backtracking persuasion (options.backtrack_lexer = true).\n" + this.showPosition(), {
					text: "",
					token: null,
					line: this.yylineno
				});
				return this;
			}, "reject"),
			less: /* @__PURE__ */ __name(function(n) {
				this.unput(this.match.slice(n));
			}, "less"),
			pastInput: /* @__PURE__ */ __name(function() {
				var past = this.matched.substr(0, this.matched.length - this.match.length);
				return (past.length > 20 ? "..." : "") + past.substr(-20).replace(/\n/g, "");
			}, "pastInput"),
			upcomingInput: /* @__PURE__ */ __name(function() {
				var next = this.match;
				if (next.length < 20) next += this._input.substr(0, 20 - next.length);
				return (next.substr(0, 20) + (next.length > 20 ? "..." : "")).replace(/\n/g, "");
			}, "upcomingInput"),
			showPosition: /* @__PURE__ */ __name(function() {
				var pre = this.pastInput();
				var c = new Array(pre.length + 1).join("-");
				return pre + this.upcomingInput() + "\n" + c + "^";
			}, "showPosition"),
			test_match: /* @__PURE__ */ __name(function(match, indexed_rule) {
				var token, lines, backup;
				if (this.options.backtrack_lexer) {
					backup = {
						yylineno: this.yylineno,
						yylloc: {
							first_line: this.yylloc.first_line,
							last_line: this.last_line,
							first_column: this.yylloc.first_column,
							last_column: this.yylloc.last_column
						},
						yytext: this.yytext,
						match: this.match,
						matches: this.matches,
						matched: this.matched,
						yyleng: this.yyleng,
						offset: this.offset,
						_more: this._more,
						_input: this._input,
						yy: this.yy,
						conditionStack: this.conditionStack.slice(0),
						done: this.done
					};
					if (this.options.ranges) backup.yylloc.range = this.yylloc.range.slice(0);
				}
				lines = match[0].match(/(?:\r\n?|\n).*/g);
				if (lines) this.yylineno += lines.length;
				this.yylloc = {
					first_line: this.yylloc.last_line,
					last_line: this.yylineno + 1,
					first_column: this.yylloc.last_column,
					last_column: lines ? lines[lines.length - 1].length - lines[lines.length - 1].match(/\r?\n?/)[0].length : this.yylloc.last_column + match[0].length
				};
				this.yytext += match[0];
				this.match += match[0];
				this.matches = match;
				this.yyleng = this.yytext.length;
				if (this.options.ranges) this.yylloc.range = [this.offset, this.offset += this.yyleng];
				this._more = false;
				this._backtrack = false;
				this._input = this._input.slice(match[0].length);
				this.matched += match[0];
				token = this.performAction.call(this, this.yy, this, indexed_rule, this.conditionStack[this.conditionStack.length - 1]);
				if (this.done && this._input) this.done = false;
				if (token) return token;
				else if (this._backtrack) {
					for (var k in backup) this[k] = backup[k];
					return false;
				}
				return false;
			}, "test_match"),
			next: /* @__PURE__ */ __name(function() {
				if (this.done) return this.EOF;
				if (!this._input) this.done = true;
				var token, match, tempMatch, index;
				if (!this._more) {
					this.yytext = "";
					this.match = "";
				}
				var rules = this._currentRules();
				for (var i = 0; i < rules.length; i++) {
					tempMatch = this._input.match(this.rules[rules[i]]);
					if (tempMatch && (!match || tempMatch[0].length > match[0].length)) {
						match = tempMatch;
						index = i;
						if (this.options.backtrack_lexer) {
							token = this.test_match(tempMatch, rules[i]);
							if (token !== false) return token;
							else if (this._backtrack) {
								match = false;
								continue;
							} else return false;
						} else if (!this.options.flex) break;
					}
				}
				if (match) {
					token = this.test_match(match, rules[index]);
					if (token !== false) return token;
					return false;
				}
				if (this._input === "") return this.EOF;
				else return this.parseError("Lexical error on line " + (this.yylineno + 1) + ". Unrecognized text.\n" + this.showPosition(), {
					text: "",
					token: null,
					line: this.yylineno
				});
			}, "next"),
			lex: /* @__PURE__ */ __name(function lex() {
				var r = this.next();
				if (r) return r;
				else return this.lex();
			}, "lex"),
			begin: /* @__PURE__ */ __name(function begin(condition) {
				this.conditionStack.push(condition);
			}, "begin"),
			popState: /* @__PURE__ */ __name(function popState() {
				if (this.conditionStack.length - 1 > 0) return this.conditionStack.pop();
				else return this.conditionStack[0];
			}, "popState"),
			_currentRules: /* @__PURE__ */ __name(function _currentRules() {
				if (this.conditionStack.length && this.conditionStack[this.conditionStack.length - 1]) return this.conditions[this.conditionStack[this.conditionStack.length - 1]].rules;
				else return this.conditions["INITIAL"].rules;
			}, "_currentRules"),
			topState: /* @__PURE__ */ __name(function topState(n) {
				n = this.conditionStack.length - 1 - Math.abs(n || 0);
				if (n >= 0) return this.conditionStack[n];
				else return "INITIAL";
			}, "topState"),
			pushState: /* @__PURE__ */ __name(function pushState(condition) {
				this.begin(condition);
			}, "pushState"),
			stateStackSize: /* @__PURE__ */ __name(function stateStackSize() {
				return this.conditionStack.length;
			}, "stateStackSize"),
			options: {},
			performAction: /* @__PURE__ */ __name(function anonymous(yy, yy_, $avoiding_name_collisions, YY_START) {
				switch ($avoiding_name_collisions) {
					case 0:
						yy.getLogger().debug("Found block-beta");
						return 10;
					case 1:
						yy.getLogger().debug("Found id-block");
						return 29;
					case 2:
						yy.getLogger().debug("Found block");
						return 10;
					case 3:
						yy.getLogger().debug(".", yy_.yytext);
						break;
					case 4:
						yy.getLogger().debug("_", yy_.yytext);
						break;
					case 5: return 5;
					case 6:
						yy_.yytext = -1;
						return 28;
					case 7:
						yy_.yytext = yy_.yytext.replace(/columns\s+/, "");
						yy.getLogger().debug("COLUMNS (LEX)", yy_.yytext);
						return 28;
					case 8:
						this.pushState("md_string");
						break;
					case 9: return "MD_STR";
					case 10:
						this.popState();
						break;
					case 11:
						this.pushState("string");
						break;
					case 12:
						yy.getLogger().debug("LEX: POPPING STR:", yy_.yytext);
						this.popState();
						break;
					case 13:
						yy.getLogger().debug("LEX: STR end:", yy_.yytext);
						return "STR";
					case 14:
						yy_.yytext = yy_.yytext.replace(/space\:/, "");
						yy.getLogger().debug("SPACE NUM (LEX)", yy_.yytext);
						return 21;
					case 15:
						yy_.yytext = "1";
						yy.getLogger().debug("COLUMNS (LEX)", yy_.yytext);
						return 21;
					case 16: return 42;
					case 17: return "LINKSTYLE";
					case 18: return "INTERPOLATE";
					case 19:
						this.pushState("CLASSDEF");
						return 39;
					case 20:
						this.popState();
						this.pushState("CLASSDEFID");
						return "DEFAULT_CLASSDEF_ID";
					case 21:
						this.popState();
						this.pushState("CLASSDEFID");
						return 40;
					case 22:
						this.popState();
						return 41;
					case 23:
						this.pushState("CLASS");
						return 43;
					case 24:
						this.popState();
						this.pushState("CLASS_STYLE");
						return 44;
					case 25:
						this.popState();
						return 45;
					case 26:
						this.pushState("STYLE_STMNT");
						return 46;
					case 27:
						this.popState();
						this.pushState("STYLE_DEFINITION");
						return 47;
					case 28:
						this.popState();
						return 48;
					case 29:
						this.pushState("acc_title");
						return "acc_title";
					case 30:
						this.popState();
						return "acc_title_value";
					case 31:
						this.pushState("acc_descr");
						return "acc_descr";
					case 32:
						this.popState();
						return "acc_descr_value";
					case 33:
						this.pushState("acc_descr_multiline");
						break;
					case 34:
						this.popState();
						break;
					case 35: return "acc_descr_multiline_value";
					case 36: return 30;
					case 37:
						this.popState();
						yy.getLogger().debug("Lex: ((");
						return "NODE_DEND";
					case 38:
						this.popState();
						yy.getLogger().debug("Lex: ((");
						return "NODE_DEND";
					case 39:
						this.popState();
						yy.getLogger().debug("Lex: ))");
						return "NODE_DEND";
					case 40:
						this.popState();
						yy.getLogger().debug("Lex: ((");
						return "NODE_DEND";
					case 41:
						this.popState();
						yy.getLogger().debug("Lex: ((");
						return "NODE_DEND";
					case 42:
						this.popState();
						yy.getLogger().debug("Lex: (-");
						return "NODE_DEND";
					case 43:
						this.popState();
						yy.getLogger().debug("Lex: -)");
						return "NODE_DEND";
					case 44:
						this.popState();
						yy.getLogger().debug("Lex: ((");
						return "NODE_DEND";
					case 45:
						this.popState();
						yy.getLogger().debug("Lex: ]]");
						return "NODE_DEND";
					case 46:
						this.popState();
						yy.getLogger().debug("Lex: (");
						return "NODE_DEND";
					case 47:
						this.popState();
						yy.getLogger().debug("Lex: ])");
						return "NODE_DEND";
					case 48:
						this.popState();
						yy.getLogger().debug("Lex: /]");
						return "NODE_DEND";
					case 49:
						this.popState();
						yy.getLogger().debug("Lex: /]");
						return "NODE_DEND";
					case 50:
						this.popState();
						yy.getLogger().debug("Lex: )]");
						return "NODE_DEND";
					case 51:
						this.popState();
						yy.getLogger().debug("Lex: )");
						return "NODE_DEND";
					case 52:
						this.popState();
						yy.getLogger().debug("Lex: ]>");
						return "NODE_DEND";
					case 53:
						this.popState();
						yy.getLogger().debug("Lex: ]");
						return "NODE_DEND";
					case 54:
						yy.getLogger().debug("Lexa: -)");
						this.pushState("NODE");
						return 35;
					case 55:
						yy.getLogger().debug("Lexa: (-");
						this.pushState("NODE");
						return 35;
					case 56:
						yy.getLogger().debug("Lexa: ))");
						this.pushState("NODE");
						return 35;
					case 57:
						yy.getLogger().debug("Lexa: )");
						this.pushState("NODE");
						return 35;
					case 58:
						yy.getLogger().debug("Lex: (((");
						this.pushState("NODE");
						return 35;
					case 59:
						yy.getLogger().debug("Lexa: )");
						this.pushState("NODE");
						return 35;
					case 60:
						yy.getLogger().debug("Lexa: )");
						this.pushState("NODE");
						return 35;
					case 61:
						yy.getLogger().debug("Lexa: )");
						this.pushState("NODE");
						return 35;
					case 62:
						yy.getLogger().debug("Lexc: >");
						this.pushState("NODE");
						return 35;
					case 63:
						yy.getLogger().debug("Lexa: ([");
						this.pushState("NODE");
						return 35;
					case 64:
						yy.getLogger().debug("Lexa: )");
						this.pushState("NODE");
						return 35;
					case 65:
						this.pushState("NODE");
						return 35;
					case 66:
						this.pushState("NODE");
						return 35;
					case 67:
						this.pushState("NODE");
						return 35;
					case 68:
						this.pushState("NODE");
						return 35;
					case 69:
						this.pushState("NODE");
						return 35;
					case 70:
						this.pushState("NODE");
						return 35;
					case 71:
						this.pushState("NODE");
						return 35;
					case 72:
						yy.getLogger().debug("Lexa: [");
						this.pushState("NODE");
						return 35;
					case 73:
						this.pushState("BLOCK_ARROW");
						yy.getLogger().debug("LEX ARR START");
						return 37;
					case 74:
						yy.getLogger().debug("Lex: NODE_ID", yy_.yytext);
						return 31;
					case 75:
						yy.getLogger().debug("Lex: EOF", yy_.yytext);
						return 8;
					case 76:
						this.pushState("md_string");
						break;
					case 77:
						this.pushState("md_string");
						break;
					case 78: return "NODE_DESCR";
					case 79:
						this.popState();
						break;
					case 80:
						yy.getLogger().debug("Lex: Starting string");
						this.pushState("string");
						break;
					case 81:
						yy.getLogger().debug("LEX ARR: Starting string");
						this.pushState("string");
						break;
					case 82:
						yy.getLogger().debug("LEX: NODE_DESCR:", yy_.yytext);
						return "NODE_DESCR";
					case 83:
						yy.getLogger().debug("LEX POPPING");
						this.popState();
						break;
					case 84:
						yy.getLogger().debug("Lex: =>BAE");
						this.pushState("ARROW_DIR");
						break;
					case 85:
						yy_.yytext = yy_.yytext.replace(/^,\s*/, "");
						yy.getLogger().debug("Lex (right): dir:", yy_.yytext);
						return "DIR";
					case 86:
						yy_.yytext = yy_.yytext.replace(/^,\s*/, "");
						yy.getLogger().debug("Lex (left):", yy_.yytext);
						return "DIR";
					case 87:
						yy_.yytext = yy_.yytext.replace(/^,\s*/, "");
						yy.getLogger().debug("Lex (x):", yy_.yytext);
						return "DIR";
					case 88:
						yy_.yytext = yy_.yytext.replace(/^,\s*/, "");
						yy.getLogger().debug("Lex (y):", yy_.yytext);
						return "DIR";
					case 89:
						yy_.yytext = yy_.yytext.replace(/^,\s*/, "");
						yy.getLogger().debug("Lex (up):", yy_.yytext);
						return "DIR";
					case 90:
						yy_.yytext = yy_.yytext.replace(/^,\s*/, "");
						yy.getLogger().debug("Lex (down):", yy_.yytext);
						return "DIR";
					case 91:
						yy_.yytext = "]>";
						yy.getLogger().debug("Lex (ARROW_DIR end):", yy_.yytext);
						this.popState();
						this.popState();
						return "BLOCK_ARROW_END";
					case 92:
						yy.getLogger().debug("Lex: LINK", "#" + yy_.yytext + "#");
						return 15;
					case 93:
						yy.getLogger().debug("Lex: LINK", yy_.yytext);
						return 15;
					case 94:
						yy.getLogger().debug("Lex: LINK", yy_.yytext);
						return 15;
					case 95:
						yy.getLogger().debug("Lex: LINK", yy_.yytext);
						return 15;
					case 96:
						yy.getLogger().debug("Lex: START_LINK", yy_.yytext);
						this.pushState("LLABEL");
						return 16;
					case 97:
						yy.getLogger().debug("Lex: START_LINK", yy_.yytext);
						this.pushState("LLABEL");
						return 16;
					case 98:
						yy.getLogger().debug("Lex: START_LINK", yy_.yytext);
						this.pushState("LLABEL");
						return 16;
					case 99:
						this.pushState("md_string");
						break;
					case 100:
						yy.getLogger().debug("Lex: Starting string");
						this.pushState("string");
						return "LINK_LABEL";
					case 101:
						this.popState();
						yy.getLogger().debug("Lex: LINK", "#" + yy_.yytext + "#");
						return 15;
					case 102:
						this.popState();
						yy.getLogger().debug("Lex: LINK", yy_.yytext);
						return 15;
					case 103:
						this.popState();
						yy.getLogger().debug("Lex: LINK", yy_.yytext);
						return 15;
					case 104:
						yy.getLogger().debug("Lex: COLON", yy_.yytext);
						yy_.yytext = yy_.yytext.slice(1);
						return 27;
				}
			}, "anonymous"),
			rules: [
				/^(?:block-beta\b)/,
				/^(?:block:)/,
				/^(?:block\b)/,
				/^(?:[\s]+)/,
				/^(?:[\n]+)/,
				/^(?:((\u000D\u000A)|(\u000A)))/,
				/^(?:columns\s+auto\b)/,
				/^(?:columns\s+[\d]+)/,
				/^(?:["][`])/,
				/^(?:[^`"]+)/,
				/^(?:[`]["])/,
				/^(?:["])/,
				/^(?:["])/,
				/^(?:[^"]*)/,
				/^(?:space[:]\d+)/,
				/^(?:space\b)/,
				/^(?:default\b)/,
				/^(?:linkStyle\b)/,
				/^(?:interpolate\b)/,
				/^(?:classDef\s+)/,
				/^(?:DEFAULT\s+)/,
				/^(?:\w+\s+)/,
				/^(?:[^\n]*)/,
				/^(?:class\s+)/,
				/^(?:(\w+)+((,\s*\w+)*))/,
				/^(?:[^\n]*)/,
				/^(?:style\s+)/,
				/^(?:(\w+)+((,\s*\w+)*))/,
				/^(?:[^\n]*)/,
				/^(?:accTitle\s*:\s*)/,
				/^(?:(?!\n||)*[^\n]*)/,
				/^(?:accDescr\s*:\s*)/,
				/^(?:(?!\n||)*[^\n]*)/,
				/^(?:accDescr\s*\{\s*)/,
				/^(?:[\}])/,
				/^(?:[^\}]*)/,
				/^(?:end\b\s*)/,
				/^(?:\(\(\()/,
				/^(?:\)\)\))/,
				/^(?:[\)]\))/,
				/^(?:\}\})/,
				/^(?:\})/,
				/^(?:\(-)/,
				/^(?:-\))/,
				/^(?:\(\()/,
				/^(?:\]\])/,
				/^(?:\()/,
				/^(?:\]\))/,
				/^(?:\\\])/,
				/^(?:\/\])/,
				/^(?:\)\])/,
				/^(?:[\)])/,
				/^(?:\]>)/,
				/^(?:[\]])/,
				/^(?:-\))/,
				/^(?:\(-)/,
				/^(?:\)\))/,
				/^(?:\))/,
				/^(?:\(\(\()/,
				/^(?:\(\()/,
				/^(?:\{\{)/,
				/^(?:\{)/,
				/^(?:>)/,
				/^(?:\(\[)/,
				/^(?:\()/,
				/^(?:\[\[)/,
				/^(?:\[\|)/,
				/^(?:\[\()/,
				/^(?:\)\)\))/,
				/^(?:\[\\)/,
				/^(?:\[\/)/,
				/^(?:\[\\)/,
				/^(?:\[)/,
				/^(?:<\[)/,
				/^(?:[^\(\[\n\-\)\{\}\s\<\>:=]+)/,
				/^(?:$)/,
				/^(?:["][`])/,
				/^(?:["][`])/,
				/^(?:[^`"]+)/,
				/^(?:[`]["])/,
				/^(?:["])/,
				/^(?:["])/,
				/^(?:[^"]+)/,
				/^(?:["])/,
				/^(?:\]>\s*\()/,
				/^(?:,?\s*right\s*)/,
				/^(?:,?\s*left\s*)/,
				/^(?:,?\s*x\s*)/,
				/^(?:,?\s*y\s*)/,
				/^(?:,?\s*up\s*)/,
				/^(?:,?\s*down\s*)/,
				/^(?:\)\s*)/,
				/^(?:\s*[xo<]?--+[-xo>]\s*)/,
				/^(?:\s*[xo<]?==+[=xo>]\s*)/,
				/^(?:\s*[xo<]?-?\.+-[xo>]?\s*)/,
				/^(?:\s*~~[\~]+\s*)/,
				/^(?:\s*[xo<]?--\s*)/,
				/^(?:\s*[xo<]?==\s*)/,
				/^(?:\s*[xo<]?-\.\s*)/,
				/^(?:["][`])/,
				/^(?:["])/,
				/^(?:\s*[xo<]?--+[-xo>]\s*)/,
				/^(?:\s*[xo<]?==+[=xo>]\s*)/,
				/^(?:\s*[xo<]?-?\.+-[xo>]?\s*)/,
				/^(?::\d+)/
			],
			conditions: {
				"STYLE_DEFINITION": {
					"rules": [28],
					"inclusive": false
				},
				"STYLE_STMNT": {
					"rules": [27],
					"inclusive": false
				},
				"CLASSDEFID": {
					"rules": [22],
					"inclusive": false
				},
				"CLASSDEF": {
					"rules": [20, 21],
					"inclusive": false
				},
				"CLASS_STYLE": {
					"rules": [25],
					"inclusive": false
				},
				"CLASS": {
					"rules": [24],
					"inclusive": false
				},
				"LLABEL": {
					"rules": [
						99,
						100,
						101,
						102,
						103
					],
					"inclusive": false
				},
				"ARROW_DIR": {
					"rules": [
						85,
						86,
						87,
						88,
						89,
						90,
						91
					],
					"inclusive": false
				},
				"BLOCK_ARROW": {
					"rules": [
						76,
						81,
						84
					],
					"inclusive": false
				},
				"NODE": {
					"rules": [
						37,
						38,
						39,
						40,
						41,
						42,
						43,
						44,
						45,
						46,
						47,
						48,
						49,
						50,
						51,
						52,
						53,
						77,
						80
					],
					"inclusive": false
				},
				"md_string": {
					"rules": [
						9,
						10,
						78,
						79
					],
					"inclusive": false
				},
				"space": {
					"rules": [],
					"inclusive": false
				},
				"string": {
					"rules": [
						12,
						13,
						82,
						83
					],
					"inclusive": false
				},
				"acc_descr_multiline": {
					"rules": [34, 35],
					"inclusive": false
				},
				"acc_descr": {
					"rules": [32],
					"inclusive": false
				},
				"acc_title": {
					"rules": [30],
					"inclusive": false
				},
				"INITIAL": {
					"rules": [
						0,
						1,
						2,
						3,
						4,
						5,
						6,
						7,
						8,
						11,
						14,
						15,
						16,
						17,
						18,
						19,
						23,
						26,
						29,
						31,
						33,
						36,
						54,
						55,
						56,
						57,
						58,
						59,
						60,
						61,
						62,
						63,
						64,
						65,
						66,
						67,
						68,
						69,
						70,
						71,
						72,
						73,
						74,
						75,
						92,
						93,
						94,
						95,
						96,
						97,
						98,
						104
					],
					"inclusive": true
				}
			}
		};
	})();
	function Parser() {
		this.yy = {};
	}
	__name(Parser, "Parser");
	Parser.prototype = parser2;
	parser2.Parser = Parser;
	return new Parser();
})();
parser.parser = parser;
var block_default = parser;
var blockDatabase = /* @__PURE__ */ new Map();
var edgeList = [];
var edgeCount = /* @__PURE__ */ new Map();
var COLOR_KEYWORD = "color";
var FILL_KEYWORD = "fill";
var BG_FILL = "bgFill";
var STYLECLASS_SEP = ",";
var config = getConfig2();
var classes = /* @__PURE__ */ new Map();
var diagramId = "";
var sanitizeText2 = /* @__PURE__ */ __name((txt) => common_default.sanitizeText(txt, config), "sanitizeText");
var addStyleClass = /* @__PURE__ */ __name(function(id, styleAttributes = "") {
	let foundClass = classes.get(id);
	if (!foundClass) {
		foundClass = {
			id,
			styles: [],
			textStyles: []
		};
		classes.set(id, foundClass);
	}
	if (styleAttributes !== void 0 && styleAttributes !== null) styleAttributes.split(STYLECLASS_SEP).forEach((attrib) => {
		const fixedAttrib = attrib.replace(/([^;]*);/, "$1").trim();
		if (RegExp(COLOR_KEYWORD).exec(attrib)) {
			const newStyle2 = fixedAttrib.replace(FILL_KEYWORD, BG_FILL).replace(COLOR_KEYWORD, FILL_KEYWORD);
			foundClass.textStyles.push(newStyle2);
		}
		foundClass.styles.push(fixedAttrib);
	});
}, "addStyleClass");
var addStyle2Node = /* @__PURE__ */ __name(function(id, styles = "") {
	const foundBlock = blockDatabase.get(id);
	if (styles !== void 0 && styles !== null) foundBlock.styles = styles.split(STYLECLASS_SEP);
}, "addStyle2Node");
var setCssClass = /* @__PURE__ */ __name(function(itemIds, cssClassName) {
	itemIds.split(",").forEach(function(id) {
		let foundBlock = blockDatabase.get(id);
		if (foundBlock === void 0) {
			const trimmedId = id.trim();
			foundBlock = {
				id: trimmedId,
				type: "na",
				children: []
			};
			blockDatabase.set(trimmedId, foundBlock);
		}
		if (!foundBlock.classes) foundBlock.classes = [];
		foundBlock.classes.push(cssClassName);
	});
}, "setCssClass");
var populateBlockDatabase = /* @__PURE__ */ __name((_blockList, parent) => {
	const blockList = _blockList.flat();
	const children = [];
	const column = blockList.find((b) => b?.type === "column-setting")?.columns ?? -1;
	for (const block of blockList) {
		if (typeof column === "number" && column > 0 && block.type !== "column-setting" && typeof block.widthInColumns === "number" && block.widthInColumns > column) log.warn(`Block ${block.id} width ${block.widthInColumns} exceeds configured column width ${column}`);
		if (block.label) block.label = sanitizeText2(block.label);
		if (block.type === "classDef") {
			addStyleClass(block.id, block.css);
			continue;
		}
		if (block.type === "applyClass") {
			setCssClass(block.id, block?.styleClass ?? "");
			continue;
		}
		if (block.type === "applyStyles") {
			if (block?.stylesStr) addStyle2Node(block.id, block?.stylesStr);
			continue;
		}
		if (block.type === "column-setting") parent.columns = block.columns ?? -1;
		else if (block.type === "edge") {
			const count = (edgeCount.get(block.id) ?? 0) + 1;
			edgeCount.set(block.id, count);
			block.id = count + "-" + block.id;
			edgeList.push(block);
		} else {
			if (!block.label) if (block.type === "composite") block.label = "";
			else block.label = block.id;
			const existingBlock = blockDatabase.get(block.id);
			if (existingBlock === void 0) blockDatabase.set(block.id, block);
			else {
				if (block.type !== "na") existingBlock.type = block.type;
				if (block.label !== block.id) existingBlock.label = block.label;
			}
			if (block.children) populateBlockDatabase(block.children, block);
			if (block.type === "space") {
				const w = block.width ?? 1;
				for (let j = 0; j < w; j++) {
					const newBlock = clone(block);
					newBlock.id = newBlock.id + "-" + j;
					blockDatabase.set(newBlock.id, newBlock);
					children.push(newBlock);
				}
			} else if (existingBlock === void 0) children.push(block);
		}
	}
	parent.children = children;
}, "populateBlockDatabase");
var blocks = [];
var rootBlock = {
	id: "root",
	type: "composite",
	children: [],
	columns: -1
};
var clear2 = /* @__PURE__ */ __name(() => {
	log.debug("Clear called");
	clear();
	rootBlock = {
		id: "root",
		type: "composite",
		children: [],
		columns: -1
	};
	blockDatabase = /* @__PURE__ */ new Map([["root", rootBlock]]);
	blocks = [];
	classes = /* @__PURE__ */ new Map();
	edgeList = [];
	edgeCount = /* @__PURE__ */ new Map();
	diagramId = "";
}, "clear");
function typeStr2Type(typeStr) {
	log.debug("typeStr2Type", typeStr);
	switch (typeStr) {
		case "[]": return "square";
		case "()":
			log.debug("we have a round");
			return "round";
		case "(())": return "circle";
		case ">]": return "rect_left_inv_arrow";
		case "{}": return "diamond";
		case "{{}}": return "hexagon";
		case "([])": return "stadium";
		case "[[]]": return "subroutine";
		case "[()]": return "cylinder";
		case "((()))": return "doublecircle";
		case "[//]": return "lean_right";
		case "[\\\\]": return "lean_left";
		case "[/\\]": return "trapezoid";
		case "[\\/]": return "inv_trapezoid";
		case "<[]>": return "block_arrow";
		default: return "na";
	}
}
__name(typeStr2Type, "typeStr2Type");
function edgeTypeStr2Type(typeStr) {
	log.debug("typeStr2Type", typeStr);
	switch (typeStr) {
		case "==": return "thick";
		default: return "normal";
	}
}
__name(edgeTypeStr2Type, "edgeTypeStr2Type");
function edgeStrToEdgeData(typeStr) {
	switch (typeStr.trim().slice(-1)) {
		case "x": return "arrow_cross";
		case "o": return "arrow_circle";
		case ">": return "arrow_point";
		default: return "";
	}
}
__name(edgeStrToEdgeData, "edgeStrToEdgeData");
function edgeStrToEdgeStartData(typeStr) {
	switch (typeStr.trim().charAt(0)) {
		case "x": return "arrow_cross";
		case "o": return "arrow_circle";
		case "<": return "arrow_point";
		default: return "arrow_open";
	}
}
__name(edgeStrToEdgeStartData, "edgeStrToEdgeStartData");
function edgeStrToThickness(typeStr) {
	return typeStr.includes("==") ? "thick" : "normal";
}
__name(edgeStrToThickness, "edgeStrToThickness");
function edgeStrToPattern(typeStr) {
	if (typeStr.includes(".-")) return "dotted";
	return "solid";
}
__name(edgeStrToPattern, "edgeStrToPattern");
var cnt = 0;
var blockDB_default = {
	getConfig: /* @__PURE__ */ __name(() => getConfig().block, "getConfig"),
	typeStr2Type,
	edgeTypeStr2Type,
	edgeStrToEdgeData,
	edgeStrToEdgeStartData,
	edgeStrToThickness,
	edgeStrToPattern,
	getLogger: /* @__PURE__ */ __name(() => log, "getLogger"),
	getBlocksFlat: /* @__PURE__ */ __name(() => {
		return [...blockDatabase.values()];
	}, "getBlocksFlat"),
	getBlocks: /* @__PURE__ */ __name(() => {
		return blocks || [];
	}, "getBlocks"),
	getEdges: /* @__PURE__ */ __name(() => {
		return edgeList;
	}, "getEdges"),
	setHierarchy: /* @__PURE__ */ __name((block) => {
		rootBlock.children = block;
		populateBlockDatabase(block, rootBlock);
		blocks = rootBlock.children;
	}, "setHierarchy"),
	getBlock: /* @__PURE__ */ __name((id) => {
		return blockDatabase.get(id);
	}, "getBlock"),
	setBlock: /* @__PURE__ */ __name((block) => {
		blockDatabase.set(block.id, block);
	}, "setBlock"),
	getColumns: /* @__PURE__ */ __name((blockId) => {
		const block = blockDatabase.get(blockId);
		if (!block) return -1;
		if (block.columns) return block.columns;
		if (!block.children) return -1;
		return block.children.length;
	}, "getColumns"),
	getClasses: /* @__PURE__ */ __name(function() {
		return classes;
	}, "getClasses"),
	clear: clear2,
	generateId: /* @__PURE__ */ __name(() => {
		cnt++;
		return "id-" + Math.random().toString(36).substr(2, 12) + "-" + cnt;
	}, "generateId"),
	setDiagramId: /* @__PURE__ */ __name((id) => {
		diagramId = id;
	}, "setDiagramId"),
	getDiagramId: /* @__PURE__ */ __name(() => diagramId, "getDiagramId")
};
var fade = /* @__PURE__ */ __name((color, opacity) => {
	const channel2 = channel;
	return rgba(channel2(color, "r"), channel2(color, "g"), channel2(color, "b"), opacity);
}, "fade");
var styles_default = /* @__PURE__ */ __name((options) => `.label {
    font-family: ${options.fontFamily};
    color: ${options.nodeTextColor || options.textColor};
  }
  .cluster-label text {
    fill: ${options.titleColor};
  }
  .cluster-label span,p {
    color: ${options.titleColor};
  }



  .label text,span,p {
    fill: ${options.nodeTextColor || options.textColor};
    color: ${options.nodeTextColor || options.textColor};
  }

  .node rect,
  .node circle,
  .node ellipse,
  .node polygon,
  .node path {
    fill: ${options.mainBkg};
    stroke: ${options.nodeBorder};
    stroke-width: 1px;
  }
  .flowchart-label text {
    text-anchor: middle;
  }
  // .flowchart-label .text-outer-tspan {
  //   text-anchor: middle;
  // }
  // .flowchart-label .text-inner-tspan {
  //   text-anchor: start;
  // }

  .node .label {
    text-align: center;
  }
  .node.clickable {
    cursor: pointer;
  }

  .arrowheadPath {
    fill: ${options.arrowheadColor};
  }

  .edgePath .path {
    stroke: ${options.lineColor};
    stroke-width: 2.0px;
  }

  .flowchart-link {
    stroke: ${options.lineColor};
    fill: none;
  }

  .edgeLabel {
    background-color: ${options.edgeLabelBackground};
    /*
     * This is for backward compatibility with existing code that didn't
     * add a \`<p>\` around edge labels.
     *
     * TODO: We should probably remove this in a future release.
     */
    p {
      margin: 0;
      padding: 0;
      display: inline;
    }
    rect {
      opacity: 0.5;
      background-color: ${options.edgeLabelBackground};
      fill: ${options.edgeLabelBackground};
    }
    text-align: center;
  }

  /* For html labels only */
  .labelBkg {
    background-color: ${options.edgeLabelBackground};
  }

  .node .cluster {
    // fill: ${fade(options.mainBkg, .5)};
    fill: ${fade(options.clusterBkg, .5)};
    stroke: ${fade(options.clusterBorder, .2)};
    box-shadow: rgba(50, 50, 93, 0.25) 0px 13px 27px -5px, rgba(0, 0, 0, 0.3) 0px 8px 16px -8px;
    stroke-width: 1px;
  }

  .cluster text {
    fill: ${options.titleColor};
  }

  .cluster span,p {
    color: ${options.titleColor};
  }
  /* .cluster div {
    color: ${options.titleColor};
  } */

  div.mermaidTooltip {
    position: absolute;
    text-align: center;
    max-width: 200px;
    padding: 2px;
    font-family: ${options.fontFamily};
    font-size: 12px;
    background: ${options.tertiaryColor};
    border: 1px solid ${options.border2};
    border-radius: 2px;
    pointer-events: none;
    z-index: 100;
  }

  .flowchartTitleText {
    text-anchor: middle;
    font-size: 18px;
    fill: ${options.textColor};
  }
  ${getIconStyles()}
`, "getStyles");
var insertMarkers = /* @__PURE__ */ __name((elem, markerArray, type, id) => {
	markerArray.forEach((markerName) => {
		markers[markerName](elem, type, id);
	});
}, "insertMarkers");
var markers = {
	extension: /* @__PURE__ */ __name((elem, type, id) => {
		log.trace("Making markers for ", id);
		elem.append("defs").append("marker").attr("id", id + "_" + type + "-extensionStart").attr("class", "marker extension " + type).attr("refX", 18).attr("refY", 7).attr("markerWidth", 190).attr("markerHeight", 240).attr("orient", "auto").append("path").attr("d", "M 1,7 L18,13 V 1 Z");
		elem.append("defs").append("marker").attr("id", id + "_" + type + "-extensionEnd").attr("class", "marker extension " + type).attr("refX", 1).attr("refY", 7).attr("markerWidth", 20).attr("markerHeight", 28).attr("orient", "auto").append("path").attr("d", "M 1,1 V 13 L18,7 Z");
	}, "extension"),
	composition: /* @__PURE__ */ __name((elem, type, id) => {
		elem.append("defs").append("marker").attr("id", id + "_" + type + "-compositionStart").attr("class", "marker composition " + type).attr("refX", 18).attr("refY", 7).attr("markerWidth", 190).attr("markerHeight", 240).attr("orient", "auto").append("path").attr("d", "M 18,7 L9,13 L1,7 L9,1 Z");
		elem.append("defs").append("marker").attr("id", id + "_" + type + "-compositionEnd").attr("class", "marker composition " + type).attr("refX", 1).attr("refY", 7).attr("markerWidth", 20).attr("markerHeight", 28).attr("orient", "auto").append("path").attr("d", "M 18,7 L9,13 L1,7 L9,1 Z");
	}, "composition"),
	aggregation: /* @__PURE__ */ __name((elem, type, id) => {
		elem.append("defs").append("marker").attr("id", id + "_" + type + "-aggregationStart").attr("class", "marker aggregation " + type).attr("refX", 18).attr("refY", 7).attr("markerWidth", 190).attr("markerHeight", 240).attr("orient", "auto").append("path").attr("d", "M 18,7 L9,13 L1,7 L9,1 Z");
		elem.append("defs").append("marker").attr("id", id + "_" + type + "-aggregationEnd").attr("class", "marker aggregation " + type).attr("refX", 1).attr("refY", 7).attr("markerWidth", 20).attr("markerHeight", 28).attr("orient", "auto").append("path").attr("d", "M 18,7 L9,13 L1,7 L9,1 Z");
	}, "aggregation"),
	dependency: /* @__PURE__ */ __name((elem, type, id) => {
		elem.append("defs").append("marker").attr("id", id + "_" + type + "-dependencyStart").attr("class", "marker dependency " + type).attr("refX", 6).attr("refY", 7).attr("markerWidth", 190).attr("markerHeight", 240).attr("orient", "auto").append("path").attr("d", "M 5,7 L9,13 L1,7 L9,1 Z");
		elem.append("defs").append("marker").attr("id", id + "_" + type + "-dependencyEnd").attr("class", "marker dependency " + type).attr("refX", 13).attr("refY", 7).attr("markerWidth", 20).attr("markerHeight", 28).attr("orient", "auto").append("path").attr("d", "M 18,7 L9,13 L14,7 L9,1 Z");
	}, "dependency"),
	lollipop: /* @__PURE__ */ __name((elem, type, id) => {
		elem.append("defs").append("marker").attr("id", id + "_" + type + "-lollipopStart").attr("class", "marker lollipop " + type).attr("refX", 13).attr("refY", 7).attr("markerWidth", 190).attr("markerHeight", 240).attr("orient", "auto").append("circle").attr("stroke", "black").attr("fill", "transparent").attr("cx", 7).attr("cy", 7).attr("r", 6);
		elem.append("defs").append("marker").attr("id", id + "_" + type + "-lollipopEnd").attr("class", "marker lollipop " + type).attr("refX", 1).attr("refY", 7).attr("markerWidth", 190).attr("markerHeight", 240).attr("orient", "auto").append("circle").attr("stroke", "black").attr("fill", "transparent").attr("cx", 7).attr("cy", 7).attr("r", 6);
	}, "lollipop"),
	point: /* @__PURE__ */ __name((elem, type, id) => {
		elem.append("marker").attr("id", id + "_" + type + "-pointEnd").attr("class", "marker " + type).attr("viewBox", "0 0 10 10").attr("refX", 6).attr("refY", 5).attr("markerUnits", "userSpaceOnUse").attr("markerWidth", 12).attr("markerHeight", 12).attr("orient", "auto").append("path").attr("d", "M 0 0 L 10 5 L 0 10 z").attr("class", "arrowMarkerPath").style("stroke-width", 1).style("stroke-dasharray", "1,0");
		elem.append("marker").attr("id", id + "_" + type + "-pointStart").attr("class", "marker " + type).attr("viewBox", "0 0 10 10").attr("refX", 4.5).attr("refY", 5).attr("markerUnits", "userSpaceOnUse").attr("markerWidth", 12).attr("markerHeight", 12).attr("orient", "auto").append("path").attr("d", "M 0 5 L 10 10 L 10 0 z").attr("class", "arrowMarkerPath").style("stroke-width", 1).style("stroke-dasharray", "1,0");
	}, "point"),
	circle: /* @__PURE__ */ __name((elem, type, id) => {
		elem.append("marker").attr("id", id + "_" + type + "-circleEnd").attr("class", "marker " + type).attr("viewBox", "0 0 10 10").attr("refX", 11).attr("refY", 5).attr("markerUnits", "userSpaceOnUse").attr("markerWidth", 11).attr("markerHeight", 11).attr("orient", "auto").append("circle").attr("cx", "5").attr("cy", "5").attr("r", "5").attr("class", "arrowMarkerPath").style("stroke-width", 1).style("stroke-dasharray", "1,0");
		elem.append("marker").attr("id", id + "_" + type + "-circleStart").attr("class", "marker " + type).attr("viewBox", "0 0 10 10").attr("refX", -1).attr("refY", 5).attr("markerUnits", "userSpaceOnUse").attr("markerWidth", 11).attr("markerHeight", 11).attr("orient", "auto").append("circle").attr("cx", "5").attr("cy", "5").attr("r", "5").attr("class", "arrowMarkerPath").style("stroke-width", 1).style("stroke-dasharray", "1,0");
	}, "circle"),
	cross: /* @__PURE__ */ __name((elem, type, id) => {
		elem.append("marker").attr("id", id + "_" + type + "-crossEnd").attr("class", "marker cross " + type).attr("viewBox", "0 0 11 11").attr("refX", 12).attr("refY", 5.2).attr("markerUnits", "userSpaceOnUse").attr("markerWidth", 11).attr("markerHeight", 11).attr("orient", "auto").append("path").attr("d", "M 1,1 l 9,9 M 10,1 l -9,9").attr("class", "arrowMarkerPath").style("stroke-width", 2).style("stroke-dasharray", "1,0");
		elem.append("marker").attr("id", id + "_" + type + "-crossStart").attr("class", "marker cross " + type).attr("viewBox", "0 0 11 11").attr("refX", -1).attr("refY", 5.2).attr("markerUnits", "userSpaceOnUse").attr("markerWidth", 11).attr("markerHeight", 11).attr("orient", "auto").append("path").attr("d", "M 1,1 l 9,9 M 10,1 l -9,9").attr("class", "arrowMarkerPath").style("stroke-width", 2).style("stroke-dasharray", "1,0");
	}, "cross"),
	barb: /* @__PURE__ */ __name((elem, type, id) => {
		elem.append("defs").append("marker").attr("id", id + "_" + type + "-barbEnd").attr("refX", 19).attr("refY", 7).attr("markerWidth", 20).attr("markerHeight", 14).attr("markerUnits", "strokeWidth").attr("orient", "auto").append("path").attr("d", "M 19,7 L9,13 L14,7 L9,1 Z");
	}, "barb")
};
var markers_default = insertMarkers;
var padding = getConfig2()?.block?.padding ?? 8;
function calculateBlockPosition(columns, position) {
	if (columns === 0 || !Number.isInteger(columns)) throw new Error("Columns must be an integer !== 0.");
	if (position < 0 || !Number.isInteger(position)) throw new Error("Position must be a non-negative integer." + position);
	if (columns < 0) return {
		px: position,
		py: 0
	};
	if (columns === 1) return {
		px: 0,
		py: position
	};
	return {
		px: position % columns,
		py: Math.floor(position / columns)
	};
}
__name(calculateBlockPosition, "calculateBlockPosition");
var getMaxChildSize = /* @__PURE__ */ __name((block) => {
	let maxWidth = 0;
	let maxHeight = 0;
	for (const child of block.children) {
		const { width, height, x, y } = child.size ?? {
			width: 0,
			height: 0,
			x: 0,
			y: 0
		};
		log.debug("getMaxChildSize abc95 child:", child.id, "width:", width, "height:", height, "x:", x, "y:", y, child.type);
		if (child.type === "space") continue;
		const normalizedWidth = width / (child.widthInColumns ?? 1);
		if (normalizedWidth > maxWidth) maxWidth = normalizedWidth;
		if (height > maxHeight) maxHeight = height;
	}
	return {
		width: maxWidth,
		height: maxHeight
	};
}, "getMaxChildSize");
function setBlockSizes(block, db2, siblingWidth = 0, siblingHeight = 0) {
	log.debug("setBlockSizes abc95 (start)", block.id, block?.size?.x, "block width =", block?.size, "siblingWidth", siblingWidth);
	if (!block?.size?.width) block.size = {
		width: siblingWidth,
		height: siblingHeight,
		x: 0,
		y: 0
	};
	let maxWidth = 0;
	let maxHeight = 0;
	if (block.children?.length > 0) {
		for (const child of block.children) setBlockSizes(child, db2);
		const childSize = getMaxChildSize(block);
		maxWidth = childSize.width;
		maxHeight = childSize.height;
		log.debug("setBlockSizes abc95 maxWidth of", block.id, ":s children is ", maxWidth, maxHeight);
		for (const child of block.children) if (child.size) {
			log.debug(`abc95 Setting size of children of ${block.id} id=${child.id} ${maxWidth} ${maxHeight} ${JSON.stringify(child.size)}`);
			child.size.width = maxWidth * (child.widthInColumns ?? 1) + padding * ((child.widthInColumns ?? 1) - 1);
			child.size.height = maxHeight;
			child.size.x = 0;
			child.size.y = 0;
			log.debug(`abc95 updating size of ${block.id} children child:${child.id} maxWidth:${maxWidth} maxHeight:${maxHeight}`);
		}
		for (const child of block.children) setBlockSizes(child, db2, maxWidth, maxHeight);
		const columns = block.columns ?? -1;
		let numItems = 0;
		for (const child of block.children) numItems += child.widthInColumns ?? 1;
		let xSize = block.children.length;
		if (columns > 0 && columns < numItems) xSize = columns;
		const ySize = Math.ceil(numItems / xSize);
		let width = xSize * (maxWidth + padding) + padding;
		let height = ySize * (maxHeight + padding) + padding;
		if (width < siblingWidth) {
			log.debug(`Detected to small sibling: abc95 ${block.id} siblingWidth ${siblingWidth} siblingHeight ${siblingHeight} width ${width}`);
			width = siblingWidth;
			height = siblingHeight;
			const childWidth = (siblingWidth - xSize * padding - padding) / xSize;
			const childHeight = (siblingHeight - ySize * padding - padding) / ySize;
			log.debug("Size indata abc88", block.id, "childWidth", childWidth, "maxWidth", maxWidth);
			log.debug("Size indata abc88", block.id, "childHeight", childHeight, "maxHeight", maxHeight);
			log.debug("Size indata abc88 xSize", xSize, "padding", padding);
			for (const child of block.children) if (child.size) {
				child.size.width = childWidth;
				child.size.height = childHeight;
				child.size.x = 0;
				child.size.y = 0;
			}
		}
		log.debug(`abc95 (finale calc) ${block.id} xSize ${xSize} ySize ${ySize} columns ${columns}${block.children.length} width=${Math.max(width, block.size?.width || 0)}`);
		if (width < (block?.size?.width || 0)) {
			width = block?.size?.width || 0;
			const num = columns > 0 ? Math.min(block.children.length, columns) : block.children.length;
			if (num > 0) {
				const childWidth = (width - num * padding - padding) / num;
				log.debug("abc95 (growing to fit) width", block.id, width, block.size?.width, childWidth);
				for (const child of block.children) if (child.size) child.size.width = childWidth;
			}
		}
		block.size = {
			width,
			height,
			x: 0,
			y: 0
		};
	}
	log.debug("setBlockSizes abc94 (done)", block.id, block?.size?.x, block?.size?.width, block?.size?.y, block?.size?.height);
}
__name(setBlockSizes, "setBlockSizes");
function layoutBlocks(block, db2) {
	log.debug(`abc85 layout blocks (=>layoutBlocks) ${block.id} x: ${block?.size?.x} y: ${block?.size?.y} width: ${block?.size?.width}`);
	const columns = block.columns ?? -1;
	log.debug("layoutBlocks columns abc95", block.id, "=>", columns, block);
	if (block.children && block.children.length > 0) {
		const width = block?.children[0]?.size?.width ?? 0;
		const widthOfChildren = block.children.length * width + (block.children.length - 1) * padding;
		log.debug("widthOfChildren 88", widthOfChildren, "posX");
		const rowHeights = /* @__PURE__ */ new Map();
		{
			let colPos = 0;
			for (const child of block.children) {
				if (!child.size) continue;
				const { py } = calculateBlockPosition(columns, colPos);
				const currentMax = rowHeights.get(py) ?? 0;
				if (child.size.height > currentMax) rowHeights.set(py, child.size.height);
				let filled = child?.widthInColumns ?? 1;
				if (columns > 0) filled = Math.min(filled, columns - colPos % columns);
				colPos += filled;
			}
		}
		const rowYOffsets = /* @__PURE__ */ new Map();
		{
			let offset = 0;
			const rows = [...rowHeights.keys()].sort((a, b) => a - b);
			for (const row of rows) {
				rowYOffsets.set(row, offset);
				offset += (rowHeights.get(row) ?? 0) + padding;
			}
		}
		let columnPos = 0;
		log.debug("abc91 block?.size?.x", block.id, block?.size?.x);
		let startingPosX = block?.size?.x ? block?.size?.x + (-block?.size?.width / 2 || 0) : -padding;
		let rowPos = 0;
		for (const child of block.children) {
			const parent = block;
			if (!child.size) continue;
			const { width: width2, height } = child.size;
			const { px, py } = calculateBlockPosition(columns, columnPos);
			if (py != rowPos) {
				rowPos = py;
				startingPosX = block?.size?.x ? block?.size?.x + (-block?.size?.width / 2 || 0) : -padding;
				log.debug("New row in layout for block", block.id, " and child ", child.id, rowPos);
			}
			log.debug(`abc89 layout blocks (child) id: ${child.id} Pos: ${columnPos} (px, py) ${px},${py} (${parent?.size?.x},${parent?.size?.y}) parent: ${parent.id} width: ${width2}${padding}`);
			if (parent.size) {
				const halfWidth = width2 / 2;
				child.size.x = startingPosX + padding + halfWidth;
				log.debug(`abc91 layout blocks (calc) px, pyid:${child.id} startingPos=X${startingPosX} new startingPosX${child.size.x} ${halfWidth} padding=${padding} width=${width2} halfWidth=${halfWidth} => x:${child.size.x} y:${child.size.y} ${child.widthInColumns} (width * (child?.w || 1)) / 2 ${width2 * (child?.widthInColumns ?? 1) / 2}`);
				startingPosX = child.size.x + halfWidth;
				const rowYOffset = rowYOffsets.get(py) ?? 0;
				const rowHeight = rowHeights.get(py) ?? height;
				child.size.y = parent.size.y - parent.size.height / 2 + rowYOffset + rowHeight / 2 + padding;
				log.debug(`abc88 layout blocks (calc) px, pyid:${child.id}startingPosX${startingPosX}${padding}${halfWidth}=>x:${child.size.x}y:${child.size.y}${child.widthInColumns}(width * (child?.w || 1)) / 2${width2 * (child?.widthInColumns ?? 1) / 2}`);
			}
			if (child.children) layoutBlocks(child, db2);
			let columnsFilled = child?.widthInColumns ?? 1;
			if (columns > 0) columnsFilled = Math.min(columnsFilled, columns - columnPos % columns);
			columnPos += columnsFilled;
			log.debug("abc88 columnsPos", child, columnPos);
		}
	}
	log.debug(`layout blocks (<==layoutBlocks) ${block.id} x: ${block?.size?.x} y: ${block?.size?.y} width: ${block?.size?.width}`);
}
__name(layoutBlocks, "layoutBlocks");
function findBounds(block, { minX, minY, maxX, maxY } = {
	minX: 0,
	minY: 0,
	maxX: 0,
	maxY: 0
}) {
	if (block.size && block.id !== "root") {
		const { x, y, width, height } = block.size;
		if (x - width / 2 < minX) minX = x - width / 2;
		if (y - height / 2 < minY) minY = y - height / 2;
		if (x + width / 2 > maxX) maxX = x + width / 2;
		if (y + height / 2 > maxY) maxY = y + height / 2;
	}
	if (block.children) for (const child of block.children) ({minX, minY, maxX, maxY} = findBounds(child, {
		minX,
		minY,
		maxX,
		maxY
	}));
	return {
		minX,
		minY,
		maxX,
		maxY
	};
}
__name(findBounds, "findBounds");
function layout(db2) {
	const root = db2.getBlock("root");
	if (!root) return;
	setBlockSizes(root, db2, 0, 0);
	layoutBlocks(root, db2);
	log.debug("getBlocks", JSON.stringify(root, null, 2));
	const { minX, minY, maxX, maxY } = findBounds(root);
	const height = maxY - minY;
	return {
		x: minX,
		y: minY,
		width: maxX - minX,
		height
	};
}
__name(layout, "layout");
var createLabel_default = /* @__PURE__ */ __name(async (element, _vertexText, style, isTitle = false, isNode = false) => {
	let vertexText = _vertexText || "";
	if (typeof vertexText === "object") vertexText = vertexText[0];
	const config2 = getConfig2();
	const useHtmlLabels = getEffectiveHtmlLabels(config2);
	return await createText(element, vertexText, {
		style,
		isTitle,
		useHtmlLabels,
		markdown: false,
		isNode,
		width: Number.POSITIVE_INFINITY
	}, config2);
}, "createLabel");
var addEdgeMarkers = /* @__PURE__ */ __name((svgPath, edge, url, id, diagramType) => {
	if (edge.arrowTypeStart) addEdgeMarker(svgPath, "start", edge.arrowTypeStart, url, id, diagramType);
	if (edge.arrowTypeEnd) addEdgeMarker(svgPath, "end", edge.arrowTypeEnd, url, id, diagramType);
}, "addEdgeMarkers");
var arrowTypesMap = {
	arrow_cross: "cross",
	arrow_point: "point",
	arrow_barb: "barb",
	arrow_circle: "circle",
	aggregation: "aggregation",
	extension: "extension",
	composition: "composition",
	dependency: "dependency",
	lollipop: "lollipop"
};
var addEdgeMarker = /* @__PURE__ */ __name((svgPath, position, arrowType, url, id, diagramType) => {
	const endMarkerType = arrowTypesMap[arrowType];
	if (!endMarkerType) {
		log.warn(`Unknown arrow type: ${arrowType}`);
		return;
	}
	const suffix = position === "start" ? "Start" : "End";
	svgPath.attr(`marker-${position}`, `url(${url}#${id}_${diagramType}-${endMarkerType}${suffix})`);
}, "addEdgeMarker");
var edgeLabels = {};
var terminalLabels = {};
var insertEdgeLabel = /* @__PURE__ */ __name(async (elem, edge) => {
	const config2 = getConfig2();
	const useHtmlLabels = getEffectiveHtmlLabels(config2);
	const edgeLabel = elem.insert("g").attr("class", "edgeLabel");
	const label = edgeLabel.insert("g").attr("class", "label");
	const isMarkdown = edge.labelType === "markdown";
	const labelElement = await createText(elem, edge.label, {
		style: edge.labelStyle,
		useHtmlLabels,
		addSvgBackground: isMarkdown,
		isNode: false,
		markdown: isMarkdown,
		width: isMarkdown ? void 0 : Number.POSITIVE_INFINITY
	}, config2);
	label.node().appendChild(labelElement);
	let bbox = labelElement.getBBox();
	let transformBbox = bbox;
	if (useHtmlLabels) {
		const div = labelElement.children[0];
		const dv = select_default(labelElement);
		bbox = div.getBoundingClientRect();
		transformBbox = bbox;
		dv.attr("width", bbox.width);
		dv.attr("height", bbox.height);
	} else {
		const textEl = select_default(labelElement).select("text").node();
		if (textEl && typeof textEl.getBBox === "function") transformBbox = textEl.getBBox();
	}
	label.attr("transform", computeLabelTransform(transformBbox, useHtmlLabels));
	edgeLabels[edge.id] = edgeLabel;
	edge.width = bbox.width;
	edge.height = bbox.height;
	let fo;
	if (edge.startLabelLeft) {
		const startEdgeLabelLeft = elem.insert("g").attr("class", "edgeTerminals");
		const inner = startEdgeLabelLeft.insert("g").attr("class", "inner");
		const startLabelElement = await createLabel_default(inner, edge.startLabelLeft, edge.labelStyle);
		fo = startLabelElement;
		let slBox = startLabelElement.getBBox();
		if (useHtmlLabels) {
			const div = startLabelElement.children[0];
			const dv = select_default(startLabelElement);
			slBox = div.getBoundingClientRect();
			dv.attr("width", slBox.width);
			dv.attr("height", slBox.height);
		}
		inner.attr("transform", computeLabelTransform(slBox, useHtmlLabels));
		if (!terminalLabels[edge.id]) terminalLabels[edge.id] = {};
		terminalLabels[edge.id].startLeft = startEdgeLabelLeft;
		setTerminalWidth(fo, edge.startLabelLeft);
	}
	if (edge.startLabelRight) {
		const startEdgeLabelRight = elem.insert("g").attr("class", "edgeTerminals");
		const inner = startEdgeLabelRight.insert("g").attr("class", "inner");
		const startLabelElement = await createLabel_default(inner, edge.startLabelRight, edge.labelStyle);
		fo = startLabelElement;
		let slBox = startLabelElement.getBBox();
		if (useHtmlLabels) {
			const div = startLabelElement.children[0];
			const dv = select_default(startLabelElement);
			slBox = div.getBoundingClientRect();
			dv.attr("width", slBox.width);
			dv.attr("height", slBox.height);
		}
		inner.attr("transform", computeLabelTransform(slBox, useHtmlLabels));
		if (!terminalLabels[edge.id]) terminalLabels[edge.id] = {};
		terminalLabels[edge.id].startRight = startEdgeLabelRight;
		setTerminalWidth(fo, edge.startLabelRight);
	}
	if (edge.endLabelLeft) {
		const endEdgeLabelLeft = elem.insert("g").attr("class", "edgeTerminals");
		const inner = endEdgeLabelLeft.insert("g").attr("class", "inner");
		const endLabelElement = await createLabel_default(endEdgeLabelLeft, edge.endLabelLeft, edge.labelStyle);
		fo = endLabelElement;
		let slBox = endLabelElement.getBBox();
		if (useHtmlLabels) {
			const div = endLabelElement.children[0];
			const dv = select_default(endLabelElement);
			slBox = div.getBoundingClientRect();
			dv.attr("width", slBox.width);
			dv.attr("height", slBox.height);
		}
		inner.attr("transform", computeLabelTransform(slBox, useHtmlLabels));
		if (!terminalLabels[edge.id]) terminalLabels[edge.id] = {};
		terminalLabels[edge.id].endLeft = endEdgeLabelLeft;
		setTerminalWidth(fo, edge.endLabelLeft);
	}
	if (edge.endLabelRight) {
		const endEdgeLabelRight = elem.insert("g").attr("class", "edgeTerminals");
		const inner = endEdgeLabelRight.insert("g").attr("class", "inner");
		const endLabelElement = await createLabel_default(endEdgeLabelRight, edge.endLabelRight, edge.labelStyle);
		fo = endLabelElement;
		let slBox = endLabelElement.getBBox();
		if (useHtmlLabels) {
			const div = endLabelElement.children[0];
			const dv = select_default(endLabelElement);
			slBox = div.getBoundingClientRect();
			dv.attr("width", slBox.width);
			dv.attr("height", slBox.height);
		}
		inner.attr("transform", computeLabelTransform(slBox, useHtmlLabels));
		if (!terminalLabels[edge.id]) terminalLabels[edge.id] = {};
		terminalLabels[edge.id].endRight = endEdgeLabelRight;
		setTerminalWidth(fo, edge.endLabelRight);
	}
	return labelElement;
}, "insertEdgeLabel");
function setTerminalWidth(fo, value) {
	if (getEffectiveHtmlLabels(getConfig2()) && fo) {
		fo.style.width = value.length * 9 + "px";
		fo.style.height = "12px";
	}
}
__name(setTerminalWidth, "setTerminalWidth");
var positionEdgeLabel = /* @__PURE__ */ __name((edge, paths) => {
	log.debug("Moving label abc88 ", edge.id, edge.label, edgeLabels[edge.id], paths);
	let path = paths.updatedPath ? paths.updatedPath : paths.originalPath;
	const { subGraphTitleTotalMargin } = getSubGraphTitleMargins(getConfig2());
	if (edge.label) {
		const el = edgeLabels[edge.id];
		let x = edge.x;
		let y = edge.y;
		if (path) {
			const pos = utils_default.calcLabelPosition(path);
			log.debug("Moving label " + edge.label + " from (", x, ",", y, ") to (", pos.x, ",", pos.y, ") abc88");
			if (paths.updatedPath) {
				x = pos.x;
				y = pos.y;
			}
		}
		el.attr("transform", `translate(${x}, ${y + subGraphTitleTotalMargin / 2})`);
	}
	if (edge.startLabelLeft) {
		const el = terminalLabels[edge.id].startLeft;
		let x = edge.x;
		let y = edge.y;
		if (path) {
			const pos = utils_default.calcTerminalLabelPosition(edge.arrowTypeStart ? 10 : 0, "start_left", path);
			x = pos.x;
			y = pos.y;
		}
		el.attr("transform", `translate(${x}, ${y})`);
	}
	if (edge.startLabelRight) {
		const el = terminalLabels[edge.id].startRight;
		let x = edge.x;
		let y = edge.y;
		if (path) {
			const pos = utils_default.calcTerminalLabelPosition(edge.arrowTypeStart ? 10 : 0, "start_right", path);
			x = pos.x;
			y = pos.y;
		}
		el.attr("transform", `translate(${x}, ${y})`);
	}
	if (edge.endLabelLeft) {
		const el = terminalLabels[edge.id].endLeft;
		let x = edge.x;
		let y = edge.y;
		if (path) {
			const pos = utils_default.calcTerminalLabelPosition(edge.arrowTypeEnd ? 10 : 0, "end_left", path);
			x = pos.x;
			y = pos.y;
		}
		el.attr("transform", `translate(${x}, ${y})`);
	}
	if (edge.endLabelRight) {
		const el = terminalLabels[edge.id].endRight;
		let x = edge.x;
		let y = edge.y;
		if (path) {
			const pos = utils_default.calcTerminalLabelPosition(edge.arrowTypeEnd ? 10 : 0, "end_right", path);
			x = pos.x;
			y = pos.y;
		}
		el.attr("transform", `translate(${x}, ${y})`);
	}
}, "positionEdgeLabel");
var outsideNode = /* @__PURE__ */ __name((node, point2) => {
	const x = node.x;
	const y = node.y;
	const dx = Math.abs(point2.x - x);
	const dy = Math.abs(point2.y - y);
	const w = node.width / 2;
	const h = node.height / 2;
	if (dx >= w || dy >= h) return true;
	return false;
}, "outsideNode");
var intersection = /* @__PURE__ */ __name((node, outsidePoint, insidePoint) => {
	log.debug(`intersection calc abc89:
  outsidePoint: ${JSON.stringify(outsidePoint)}
  insidePoint : ${JSON.stringify(insidePoint)}
  node        : x:${node.x} y:${node.y} w:${node.width} h:${node.height}`);
	const x = node.x;
	const y = node.y;
	const dx = Math.abs(x - insidePoint.x);
	const w = node.width / 2;
	let r = insidePoint.x < outsidePoint.x ? w - dx : w + dx;
	const h = node.height / 2;
	const Q = Math.abs(outsidePoint.y - insidePoint.y);
	const R = Math.abs(outsidePoint.x - insidePoint.x);
	if (Math.abs(y - outsidePoint.y) * w > Math.abs(x - outsidePoint.x) * h) {
		let q = insidePoint.y < outsidePoint.y ? outsidePoint.y - h - y : y - h - outsidePoint.y;
		r = R * q / Q;
		const res = {
			x: insidePoint.x < outsidePoint.x ? insidePoint.x + r : insidePoint.x - R + r,
			y: insidePoint.y < outsidePoint.y ? insidePoint.y + Q - q : insidePoint.y - Q + q
		};
		if (r === 0) {
			res.x = outsidePoint.x;
			res.y = outsidePoint.y;
		}
		if (R === 0) res.x = outsidePoint.x;
		if (Q === 0) res.y = outsidePoint.y;
		log.debug(`abc89 topp/bott calc, Q ${Q}, q ${q}, R ${R}, r ${r}`, res);
		return res;
	} else {
		if (insidePoint.x < outsidePoint.x) r = outsidePoint.x - w - x;
		else r = x - w - outsidePoint.x;
		let q = Q * r / R;
		let _x = insidePoint.x < outsidePoint.x ? insidePoint.x + R - r : insidePoint.x - R + r;
		let _y = insidePoint.y < outsidePoint.y ? insidePoint.y + q : insidePoint.y - q;
		log.debug(`sides calc abc89, Q ${Q}, q ${q}, R ${R}, r ${r}`, {
			_x,
			_y
		});
		if (r === 0) {
			_x = outsidePoint.x;
			_y = outsidePoint.y;
		}
		if (R === 0) _x = outsidePoint.x;
		if (Q === 0) _y = outsidePoint.y;
		return {
			x: _x,
			y: _y
		};
	}
}, "intersection");
var cutPathAtIntersect = /* @__PURE__ */ __name((_points, boundaryNode) => {
	log.debug("abc88 cutPathAtIntersect", _points, boundaryNode);
	let points = [];
	let lastPointOutside = _points[0];
	let isInside = false;
	_points.forEach((point2) => {
		if (!outsideNode(boundaryNode, point2) && !isInside) {
			const inter = intersection(boundaryNode, lastPointOutside, point2);
			let pointPresent = false;
			points.forEach((p) => {
				pointPresent = pointPresent || p.x === inter.x && p.y === inter.y;
			});
			if (!points.some((e) => e.x === inter.x && e.y === inter.y)) points.push(inter);
			isInside = true;
		} else {
			lastPointOutside = point2;
			if (!isInside) points.push(point2);
		}
	});
	return points;
}, "cutPathAtIntersect");
var insertEdge = /* @__PURE__ */ __name(function(elem, e, edge, clusterDb, diagramType, graph, id) {
	let points = edge.points;
	log.debug("abc88 InsertEdge: edge=", edge, "e=", e);
	let pointsHasChanged = false;
	const tail = graph.node(e.v);
	var head = graph.node(e.w);
	if (head?.intersect && tail?.intersect) {
		points = points.slice(1, edge.points.length - 1);
		points.unshift(tail.intersect(points[0]));
		points.push(head.intersect(points[points.length - 1]));
	}
	if (edge.toCluster) {
		log.debug("to cluster abc88", clusterDb[edge.toCluster]);
		points = cutPathAtIntersect(edge.points, clusterDb[edge.toCluster].node);
		pointsHasChanged = true;
	}
	if (edge.fromCluster) {
		log.debug("from cluster abc88", clusterDb[edge.fromCluster]);
		points = cutPathAtIntersect(points.reverse(), clusterDb[edge.fromCluster].node).reverse();
		pointsHasChanged = true;
	}
	const lineData = points.filter((p) => !Number.isNaN(p.y));
	let curve = basis_default;
	if (edge.curve && (diagramType === "graph" || diagramType === "flowchart")) curve = edge.curve;
	const { x, y } = getLineFunctionsWithOffset(edge);
	const lineFunction = line_default().x(x).y(y).curve(curve);
	let strokeClasses;
	switch (edge.thickness) {
		case "normal":
			strokeClasses = "edge-thickness-normal";
			break;
		case "thick":
			strokeClasses = "edge-thickness-thick";
			break;
		case "invisible":
			strokeClasses = "edge-thickness-thick";
			break;
		default: strokeClasses = "";
	}
	switch (edge.pattern) {
		case "solid":
			strokeClasses += " edge-pattern-solid";
			break;
		case "dotted":
			strokeClasses += " edge-pattern-dotted";
			break;
		case "dashed":
			strokeClasses += " edge-pattern-dashed";
			break;
	}
	const svgPath = elem.append("path").attr("d", lineFunction(lineData)).attr("id", edge.id).attr("class", " " + strokeClasses + (edge.classes ? " " + edge.classes : "")).attr("style", edge.style);
	let url = "";
	if (getConfig2().flowchart.arrowMarkerAbsolute || getConfig2().state.arrowMarkerAbsolute) url = getUrl(true);
	addEdgeMarkers(svgPath, edge, url, id, diagramType);
	let paths = {};
	if (pointsHasChanged) paths.updatedPath = points;
	paths.originalPath = edge.points;
	return paths;
}, "insertEdge");
var expandAndDeduplicateDirections = /* @__PURE__ */ __name((directions) => {
	const uniqueDirections = /* @__PURE__ */ new Set();
	for (const direction of directions) switch (direction) {
		case "x":
			uniqueDirections.add("right");
			uniqueDirections.add("left");
			break;
		case "y":
			uniqueDirections.add("up");
			uniqueDirections.add("down");
			break;
		default:
			uniqueDirections.add(direction);
			break;
	}
	return uniqueDirections;
}, "expandAndDeduplicateDirections");
var getArrowPoints = /* @__PURE__ */ __name((duplicatedDirections, bbox, node, totalWidth) => {
	const directions = expandAndDeduplicateDirections(duplicatedDirections);
	const f = 2;
	const height = bbox.height + 2 * node.padding;
	const midpoint = height / f;
	const width = totalWidth ?? bbox.width + 2 * midpoint + node.padding;
	const padding2 = node.padding / 2;
	if (directions.has("right") && directions.has("left") && directions.has("up") && directions.has("down")) return [
		{
			x: 0,
			y: 0
		},
		{
			x: midpoint,
			y: 0
		},
		{
			x: width / 2,
			y: 2 * padding2
		},
		{
			x: width - midpoint,
			y: 0
		},
		{
			x: width,
			y: 0
		},
		{
			x: width,
			y: -height / 3
		},
		{
			x: width + 2 * padding2,
			y: -height / 2
		},
		{
			x: width,
			y: -2 * height / 3
		},
		{
			x: width,
			y: -height
		},
		{
			x: width - midpoint,
			y: -height
		},
		{
			x: width / 2,
			y: -height - 2 * padding2
		},
		{
			x: midpoint,
			y: -height
		},
		{
			x: 0,
			y: -height
		},
		{
			x: 0,
			y: -2 * height / 3
		},
		{
			x: -2 * padding2,
			y: -height / 2
		},
		{
			x: 0,
			y: -height / 3
		}
	];
	if (directions.has("right") && directions.has("left") && directions.has("up")) return [
		{
			x: midpoint,
			y: 0
		},
		{
			x: width - midpoint,
			y: 0
		},
		{
			x: width,
			y: -height / 2
		},
		{
			x: width - midpoint,
			y: -height
		},
		{
			x: midpoint,
			y: -height
		},
		{
			x: 0,
			y: -height / 2
		}
	];
	if (directions.has("right") && directions.has("left") && directions.has("down")) return [
		{
			x: 0,
			y: 0
		},
		{
			x: midpoint,
			y: -height
		},
		{
			x: width - midpoint,
			y: -height
		},
		{
			x: width,
			y: 0
		}
	];
	if (directions.has("right") && directions.has("up") && directions.has("down")) return [
		{
			x: 0,
			y: 0
		},
		{
			x: width,
			y: -midpoint
		},
		{
			x: width,
			y: -height + midpoint
		},
		{
			x: 0,
			y: -height
		}
	];
	if (directions.has("left") && directions.has("up") && directions.has("down")) return [
		{
			x: width,
			y: 0
		},
		{
			x: 0,
			y: -midpoint
		},
		{
			x: 0,
			y: -height + midpoint
		},
		{
			x: width,
			y: -height
		}
	];
	if (directions.has("right") && directions.has("left")) return [
		{
			x: midpoint,
			y: 0
		},
		{
			x: midpoint,
			y: -padding2
		},
		{
			x: width - midpoint,
			y: -padding2
		},
		{
			x: width - midpoint,
			y: 0
		},
		{
			x: width,
			y: -height / 2
		},
		{
			x: width - midpoint,
			y: -height
		},
		{
			x: width - midpoint,
			y: -height + padding2
		},
		{
			x: midpoint,
			y: -height + padding2
		},
		{
			x: midpoint,
			y: -height
		},
		{
			x: 0,
			y: -height / 2
		}
	];
	if (directions.has("up") && directions.has("down")) return [
		{
			x: width / 2,
			y: 0
		},
		{
			x: 0,
			y: -padding2
		},
		{
			x: midpoint,
			y: -padding2
		},
		{
			x: midpoint,
			y: -height + padding2
		},
		{
			x: 0,
			y: -height + padding2
		},
		{
			x: width / 2,
			y: -height
		},
		{
			x: width,
			y: -height + padding2
		},
		{
			x: width - midpoint,
			y: -height + padding2
		},
		{
			x: width - midpoint,
			y: -padding2
		},
		{
			x: width,
			y: -padding2
		}
	];
	if (directions.has("right") && directions.has("up")) return [
		{
			x: 0,
			y: 0
		},
		{
			x: width,
			y: -midpoint
		},
		{
			x: 0,
			y: -height
		}
	];
	if (directions.has("right") && directions.has("down")) return [
		{
			x: 0,
			y: 0
		},
		{
			x: width,
			y: 0
		},
		{
			x: 0,
			y: -height
		}
	];
	if (directions.has("left") && directions.has("up")) return [
		{
			x: width,
			y: 0
		},
		{
			x: 0,
			y: -midpoint
		},
		{
			x: width,
			y: -height
		}
	];
	if (directions.has("left") && directions.has("down")) return [
		{
			x: width,
			y: 0
		},
		{
			x: 0,
			y: 0
		},
		{
			x: width,
			y: -height
		}
	];
	if (directions.has("right")) return [
		{
			x: midpoint,
			y: -padding2
		},
		{
			x: midpoint,
			y: -padding2
		},
		{
			x: width - midpoint,
			y: -padding2
		},
		{
			x: width - midpoint,
			y: 0
		},
		{
			x: width,
			y: -height / 2
		},
		{
			x: width - midpoint,
			y: -height
		},
		{
			x: width - midpoint,
			y: -height + padding2
		},
		{
			x: midpoint,
			y: -height + padding2
		},
		{
			x: midpoint,
			y: -height + padding2
		}
	];
	if (directions.has("left")) return [
		{
			x: midpoint,
			y: 0
		},
		{
			x: midpoint,
			y: -padding2
		},
		{
			x: width - midpoint,
			y: -padding2
		},
		{
			x: width - midpoint,
			y: -height + padding2
		},
		{
			x: midpoint,
			y: -height + padding2
		},
		{
			x: midpoint,
			y: -height
		},
		{
			x: 0,
			y: -height / 2
		}
	];
	if (directions.has("up")) return [
		{
			x: midpoint,
			y: -padding2
		},
		{
			x: midpoint,
			y: -height + padding2
		},
		{
			x: 0,
			y: -height + padding2
		},
		{
			x: width / 2,
			y: -height
		},
		{
			x: width,
			y: -height + padding2
		},
		{
			x: width - midpoint,
			y: -height + padding2
		},
		{
			x: width - midpoint,
			y: -padding2
		}
	];
	if (directions.has("down")) return [
		{
			x: width / 2,
			y: 0
		},
		{
			x: 0,
			y: -padding2
		},
		{
			x: midpoint,
			y: -padding2
		},
		{
			x: midpoint,
			y: -height + padding2
		},
		{
			x: width - midpoint,
			y: -height + padding2
		},
		{
			x: width - midpoint,
			y: -padding2
		},
		{
			x: width,
			y: -padding2
		}
	];
	return [{
		x: 0,
		y: 0
	}];
}, "getArrowPoints");
function intersectNode(node, point2) {
	return node.intersect(point2);
}
__name(intersectNode, "intersectNode");
var intersect_node_default = intersectNode;
function intersectEllipse(node, rx, ry, point2) {
	var cx = node.x;
	var cy = node.y;
	var px = cx - point2.x;
	var py = cy - point2.y;
	var det = Math.sqrt(rx * rx * py * py + ry * ry * px * px);
	var dx = Math.abs(rx * ry * px / det);
	if (point2.x < cx) dx = -dx;
	var dy = Math.abs(rx * ry * py / det);
	if (point2.y < cy) dy = -dy;
	return {
		x: cx + dx,
		y: cy + dy
	};
}
__name(intersectEllipse, "intersectEllipse");
var intersect_ellipse_default = intersectEllipse;
function intersectCircle(node, rx, point2) {
	return intersect_ellipse_default(node, rx, rx, point2);
}
__name(intersectCircle, "intersectCircle");
var intersect_circle_default = intersectCircle;
function intersectLine(p1, p2, q1, q2) {
	var a1, a2, b1, b2, c1, c2;
	var r1, r2, r3, r4;
	var denom, offset, num;
	var x, y;
	a1 = p2.y - p1.y;
	b1 = p1.x - p2.x;
	c1 = p2.x * p1.y - p1.x * p2.y;
	r3 = a1 * q1.x + b1 * q1.y + c1;
	r4 = a1 * q2.x + b1 * q2.y + c1;
	if (r3 !== 0 && r4 !== 0 && sameSign(r3, r4)) return;
	a2 = q2.y - q1.y;
	b2 = q1.x - q2.x;
	c2 = q2.x * q1.y - q1.x * q2.y;
	r1 = a2 * p1.x + b2 * p1.y + c2;
	r2 = a2 * p2.x + b2 * p2.y + c2;
	if (r1 !== 0 && r2 !== 0 && sameSign(r1, r2)) return;
	denom = a1 * b2 - a2 * b1;
	if (denom === 0) return;
	offset = Math.abs(denom / 2);
	num = b1 * c2 - b2 * c1;
	x = num < 0 ? (num - offset) / denom : (num + offset) / denom;
	num = a2 * c1 - a1 * c2;
	y = num < 0 ? (num - offset) / denom : (num + offset) / denom;
	return {
		x,
		y
	};
}
__name(intersectLine, "intersectLine");
function sameSign(r1, r2) {
	return r1 * r2 > 0;
}
__name(sameSign, "sameSign");
var intersect_line_default = intersectLine;
var intersect_polygon_default = intersectPolygon;
function intersectPolygon(node, polyPoints, point2) {
	var x1 = node.x;
	var y1 = node.y;
	var intersections = [];
	var minX = Number.POSITIVE_INFINITY;
	var minY = Number.POSITIVE_INFINITY;
	if (typeof polyPoints.forEach === "function") polyPoints.forEach(function(entry) {
		minX = Math.min(minX, entry.x);
		minY = Math.min(minY, entry.y);
	});
	else {
		minX = Math.min(minX, polyPoints.x);
		minY = Math.min(minY, polyPoints.y);
	}
	var left = x1 - node.width / 2 - minX;
	var top = y1 - node.height / 2 - minY;
	for (var i = 0; i < polyPoints.length; i++) {
		var p1 = polyPoints[i];
		var p2 = polyPoints[i < polyPoints.length - 1 ? i + 1 : 0];
		var intersect = intersect_line_default(node, point2, {
			x: left + p1.x,
			y: top + p1.y
		}, {
			x: left + p2.x,
			y: top + p2.y
		});
		if (intersect) intersections.push(intersect);
	}
	if (!intersections.length) return node;
	if (intersections.length > 1) intersections.sort(function(p, q) {
		var pdx = p.x - point2.x;
		var pdy = p.y - point2.y;
		var distp = Math.sqrt(pdx * pdx + pdy * pdy);
		var qdx = q.x - point2.x;
		var qdy = q.y - point2.y;
		var distq = Math.sqrt(qdx * qdx + qdy * qdy);
		return distp < distq ? -1 : distp === distq ? 0 : 1;
	});
	return intersections[0];
}
__name(intersectPolygon, "intersectPolygon");
var intersect_default = {
	node: intersect_node_default,
	circle: intersect_circle_default,
	ellipse: intersect_ellipse_default,
	polygon: intersect_polygon_default,
	rect: /* @__PURE__ */ __name((node, point2) => {
		var x = node.x;
		var y = node.y;
		var dx = point2.x - x;
		var dy = point2.y - y;
		var w = node.width / 2;
		var h = node.height / 2;
		var sx, sy;
		if (Math.abs(dy) * w > Math.abs(dx) * h) {
			if (dy < 0) h = -h;
			sx = dy === 0 ? 0 : h * dx / dy;
			sy = h;
		} else {
			if (dx < 0) w = -w;
			sx = w;
			sy = dx === 0 ? 0 : w * dy / dx;
		}
		return {
			x: x + sx,
			y: y + sy
		};
	}, "intersectRect")
};
var labelHelper = /* @__PURE__ */ __name(async (parent, node, _classes, isNode) => {
	const config2 = getConfig2();
	let classes2;
	const useHtmlLabels = node.useHtmlLabels || getEffectiveHtmlLabels(config2);
	if (!_classes) classes2 = "node default";
	else classes2 = _classes;
	const shapeSvg = parent.insert("g").attr("class", classes2).attr("id", node.domId || node.id);
	const label = shapeSvg.insert("g").attr("class", "label").attr("style", node.labelStyle);
	let labelText;
	if (node.labelText === void 0) labelText = "";
	else labelText = typeof node.labelText === "string" ? node.labelText : node.labelText[0];
	let text;
	if (node.labelType === "markdown") text = createText(label, sanitizeText(decodeEntities(labelText), config2), {
		useHtmlLabels,
		width: node.width || config2.flowchart.wrappingWidth,
		classes: "markdown-node-label"
	}, config2);
	else text = await createLabel_default(label, sanitizeText(decodeEntities(labelText), config2), node.labelStyle, false, isNode);
	let bbox = text.getBBox();
	const halfPadding = node.padding / 2;
	if (getEffectiveHtmlLabels(config2)) {
		const div = text.children[0];
		const dv = select_default(text);
		await configureLabelImages(div, labelText);
		bbox = div.getBoundingClientRect();
		dv.attr("width", bbox.width);
		dv.attr("height", bbox.height);
	}
	if (useHtmlLabels) label.attr("transform", "translate(" + -bbox.width / 2 + ", " + -bbox.height / 2 + ")");
	else label.attr("transform", "translate(0, " + -bbox.height / 2 + ")");
	if (node.centerLabel) label.attr("transform", "translate(" + -bbox.width / 2 + ", " + -bbox.height / 2 + ")");
	label.insert("rect", ":first-child");
	return {
		shapeSvg,
		bbox,
		halfPadding,
		label
	};
}, "labelHelper");
var updateNodeBounds = /* @__PURE__ */ __name((node, element) => {
	const bbox = element.node().getBBox();
	node.width = bbox.width;
	node.height = bbox.height;
}, "updateNodeBounds");
function insertPolygonShape(parent, w, h, points) {
	return parent.insert("polygon", ":first-child").attr("points", points.map(function(d) {
		return d.x + "," + d.y;
	}).join(" ")).attr("class", "label-container").attr("transform", "translate(" + -w / 2 + "," + h / 2 + ")");
}
__name(insertPolygonShape, "insertPolygonShape");
var note_default = /* @__PURE__ */ __name(async (parent, node) => {
	if (!(node.useHtmlLabels || getEffectiveHtmlLabels(getConfig2()))) node.centerLabel = true;
	const { shapeSvg, bbox, halfPadding } = await labelHelper(parent, node, "node " + node.classes, true);
	log.info("Classes = ", node.classes);
	const rect2 = shapeSvg.insert("rect", ":first-child");
	rect2.attr("rx", node.rx).attr("ry", node.ry).attr("x", -bbox.width / 2 - halfPadding).attr("y", -bbox.height / 2 - halfPadding).attr("width", bbox.width + node.padding).attr("height", bbox.height + node.padding);
	updateNodeBounds(node, rect2);
	node.intersect = function(point2) {
		return intersect_default.rect(node, point2);
	};
	return shapeSvg;
}, "note");
var formatClass = /* @__PURE__ */ __name((str) => {
	if (str) return " " + str;
	return "";
}, "formatClass");
var getClassesFromNode = /* @__PURE__ */ __name((node, otherClasses) => {
	return `${otherClasses ? otherClasses : "node default"}${formatClass(node.classes)} ${formatClass(node.class)}`;
}, "getClassesFromNode");
var question = /* @__PURE__ */ __name(async (parent, node) => {
	const { shapeSvg, bbox } = await labelHelper(parent, node, getClassesFromNode(node, void 0), true);
	const s = bbox.width + node.padding + (bbox.height + node.padding);
	const points = [
		{
			x: s / 2,
			y: 0
		},
		{
			x: s,
			y: -s / 2
		},
		{
			x: s / 2,
			y: -s
		},
		{
			x: 0,
			y: -s / 2
		}
	];
	log.info("Question main (Circle)");
	const questionElem = insertPolygonShape(shapeSvg, s, s, points);
	questionElem.attr("style", node.style);
	updateNodeBounds(node, questionElem);
	node.intersect = function(point2) {
		log.warn("Intersect called");
		return intersect_default.polygon(node, points, point2);
	};
	return shapeSvg;
}, "question");
var choice = /* @__PURE__ */ __name((parent, node) => {
	const shapeSvg = parent.insert("g").attr("class", "node default").attr("id", node.domId || node.id);
	const s = 28;
	const points = [
		{
			x: 0,
			y: s / 2
		},
		{
			x: s / 2,
			y: 0
		},
		{
			x: 0,
			y: -28 / 2
		},
		{
			x: -28 / 2,
			y: 0
		}
	];
	shapeSvg.insert("polygon", ":first-child").attr("points", points.map(function(d) {
		return d.x + "," + d.y;
	}).join(" ")).attr("class", "state-start").attr("r", 7).attr("width", 28).attr("height", 28);
	node.width = 28;
	node.height = 28;
	node.intersect = function(point2) {
		return intersect_default.circle(node, 14, point2);
	};
	return shapeSvg;
}, "choice");
var hexagon = /* @__PURE__ */ __name(async (parent, node) => {
	const { shapeSvg, bbox } = await labelHelper(parent, node, getClassesFromNode(node, void 0), true);
	const f = 4;
	const h = node.positioned ? node.height : bbox.height + node.padding;
	const m = h / f;
	const w = node.positioned ? node.width : bbox.width + 2 * m + node.padding;
	const points = [
		{
			x: m,
			y: 0
		},
		{
			x: w - m,
			y: 0
		},
		{
			x: w,
			y: -h / 2
		},
		{
			x: w - m,
			y: -h
		},
		{
			x: m,
			y: -h
		},
		{
			x: 0,
			y: -h / 2
		}
	];
	const hex = insertPolygonShape(shapeSvg, w, h, points);
	hex.attr("style", node.style);
	updateNodeBounds(node, hex);
	node.intersect = function(point2) {
		return intersect_default.polygon(node, points, point2);
	};
	return shapeSvg;
}, "hexagon");
var block_arrow = /* @__PURE__ */ __name(async (parent, node) => {
	const { shapeSvg, bbox } = await labelHelper(parent, node, void 0, true);
	const f = 2;
	const h = bbox.height + 2 * node.padding;
	const m = h / f;
	const naturalW = bbox.width + 2 * m + node.padding;
	const w = node.positioned && (node.widthInColumns ?? 1) > 1 && node.width > naturalW ? node.width : naturalW;
	const points = getArrowPoints(node.directions, bbox, node, w);
	const blockArrow = insertPolygonShape(shapeSvg, w, h, points);
	blockArrow.attr("style", node.style);
	updateNodeBounds(node, blockArrow);
	node.intersect = function(point2) {
		return intersect_default.polygon(node, points, point2);
	};
	return shapeSvg;
}, "block_arrow");
var rect_left_inv_arrow = /* @__PURE__ */ __name(async (parent, node) => {
	const { shapeSvg, bbox } = await labelHelper(parent, node, getClassesFromNode(node, void 0), true);
	const w = bbox.width + node.padding;
	const h = bbox.height + node.padding;
	const points = [
		{
			x: -h / 2,
			y: 0
		},
		{
			x: w,
			y: 0
		},
		{
			x: w,
			y: -h
		},
		{
			x: -h / 2,
			y: -h
		},
		{
			x: 0,
			y: -h / 2
		}
	];
	insertPolygonShape(shapeSvg, w, h, points).attr("style", node.style);
	node.width = w + h;
	node.height = h;
	node.intersect = function(point2) {
		return intersect_default.polygon(node, points, point2);
	};
	return shapeSvg;
}, "rect_left_inv_arrow");
var lean_right = /* @__PURE__ */ __name(async (parent, node) => {
	const { shapeSvg, bbox } = await labelHelper(parent, node, getClassesFromNode(node), true);
	const w = bbox.width + node.padding;
	const h = bbox.height + node.padding;
	const points = [
		{
			x: -2 * h / 6,
			y: 0
		},
		{
			x: w - h / 6,
			y: 0
		},
		{
			x: w + 2 * h / 6,
			y: -h
		},
		{
			x: h / 6,
			y: -h
		}
	];
	const el = insertPolygonShape(shapeSvg, w, h, points);
	el.attr("style", node.style);
	updateNodeBounds(node, el);
	node.intersect = function(point2) {
		return intersect_default.polygon(node, points, point2);
	};
	return shapeSvg;
}, "lean_right");
var lean_left = /* @__PURE__ */ __name(async (parent, node) => {
	const { shapeSvg, bbox } = await labelHelper(parent, node, getClassesFromNode(node, void 0), true);
	const w = bbox.width + node.padding;
	const h = bbox.height + node.padding;
	const points = [
		{
			x: 2 * h / 6,
			y: 0
		},
		{
			x: w + h / 6,
			y: 0
		},
		{
			x: w - 2 * h / 6,
			y: -h
		},
		{
			x: -h / 6,
			y: -h
		}
	];
	const el = insertPolygonShape(shapeSvg, w, h, points);
	el.attr("style", node.style);
	updateNodeBounds(node, el);
	node.intersect = function(point2) {
		return intersect_default.polygon(node, points, point2);
	};
	return shapeSvg;
}, "lean_left");
var trapezoid = /* @__PURE__ */ __name(async (parent, node) => {
	const { shapeSvg, bbox } = await labelHelper(parent, node, getClassesFromNode(node, void 0), true);
	const w = bbox.width + node.padding;
	const h = bbox.height + node.padding;
	const points = [
		{
			x: -2 * h / 6,
			y: 0
		},
		{
			x: w + 2 * h / 6,
			y: 0
		},
		{
			x: w - h / 6,
			y: -h
		},
		{
			x: h / 6,
			y: -h
		}
	];
	const el = insertPolygonShape(shapeSvg, w, h, points);
	el.attr("style", node.style);
	updateNodeBounds(node, el);
	node.intersect = function(point2) {
		return intersect_default.polygon(node, points, point2);
	};
	return shapeSvg;
}, "trapezoid");
var inv_trapezoid = /* @__PURE__ */ __name(async (parent, node) => {
	const { shapeSvg, bbox } = await labelHelper(parent, node, getClassesFromNode(node, void 0), true);
	const w = bbox.width + node.padding;
	const h = bbox.height + node.padding;
	const points = [
		{
			x: h / 6,
			y: 0
		},
		{
			x: w - h / 6,
			y: 0
		},
		{
			x: w + 2 * h / 6,
			y: -h
		},
		{
			x: -2 * h / 6,
			y: -h
		}
	];
	const el = insertPolygonShape(shapeSvg, w, h, points);
	el.attr("style", node.style);
	updateNodeBounds(node, el);
	node.intersect = function(point2) {
		return intersect_default.polygon(node, points, point2);
	};
	return shapeSvg;
}, "inv_trapezoid");
var rect_right_inv_arrow = /* @__PURE__ */ __name(async (parent, node) => {
	const { shapeSvg, bbox } = await labelHelper(parent, node, getClassesFromNode(node, void 0), true);
	const w = bbox.width + node.padding;
	const h = bbox.height + node.padding;
	const points = [
		{
			x: 0,
			y: 0
		},
		{
			x: w + h / 2,
			y: 0
		},
		{
			x: w,
			y: -h / 2
		},
		{
			x: w + h / 2,
			y: -h
		},
		{
			x: 0,
			y: -h
		}
	];
	const el = insertPolygonShape(shapeSvg, w, h, points);
	el.attr("style", node.style);
	updateNodeBounds(node, el);
	node.intersect = function(point2) {
		return intersect_default.polygon(node, points, point2);
	};
	return shapeSvg;
}, "rect_right_inv_arrow");
var cylinder = /* @__PURE__ */ __name(async (parent, node) => {
	const { shapeSvg, bbox } = await labelHelper(parent, node, getClassesFromNode(node, void 0), true);
	const w = bbox.width + node.padding;
	const rx = w / 2;
	const ry = rx / (2.5 + w / 50);
	const h = bbox.height + ry + node.padding;
	const shape = "M 0," + ry + " a " + rx + "," + ry + " 0,0,0 " + w + " 0 a " + rx + "," + ry + " 0,0,0 " + -w + " 0 l 0," + h + " a " + rx + "," + ry + " 0,0,0 " + w + " 0 l 0," + -h;
	updateNodeBounds(node, shapeSvg.attr("label-offset-y", ry).insert("path", ":first-child").attr("style", node.style).attr("d", shape).attr("transform", "translate(" + -w / 2 + "," + -(h / 2 + ry) + ")"));
	node.intersect = function(point2) {
		const pos = intersect_default.rect(node, point2);
		const x = pos.x - node.x;
		if (rx != 0 && (Math.abs(x) < node.width / 2 || Math.abs(x) == node.width / 2 && Math.abs(pos.y - node.y) > node.height / 2 - ry)) {
			let y = ry * ry * (1 - x * x / (rx * rx));
			if (y != 0) y = Math.sqrt(y);
			y = ry - y;
			if (point2.y - node.y > 0) y = -y;
			pos.y += y;
		}
		return pos;
	};
	return shapeSvg;
}, "cylinder");
var rect = /* @__PURE__ */ __name(async (parent, node) => {
	const { shapeSvg, bbox, halfPadding } = await labelHelper(parent, node, "node " + node.classes + " " + node.class, true);
	const rect2 = shapeSvg.insert("rect", ":first-child");
	const totalWidth = node.positioned ? node.width : bbox.width + node.padding;
	const totalHeight = node.positioned ? node.height : bbox.height + node.padding;
	const x = node.positioned ? -totalWidth / 2 : -bbox.width / 2 - halfPadding;
	const y = node.positioned ? -totalHeight / 2 : -bbox.height / 2 - halfPadding;
	rect2.attr("class", "basic label-container").attr("style", node.style).attr("rx", node.rx).attr("ry", node.ry).attr("x", x).attr("y", y).attr("width", totalWidth).attr("height", totalHeight);
	if (node.props) {
		const propKeys = new Set(Object.keys(node.props));
		if (node.props.borders) {
			applyNodePropertyBorders(rect2, node.props.borders, totalWidth, totalHeight);
			propKeys.delete("borders");
		}
		propKeys.forEach((propKey) => {
			log.warn(`Unknown node property ${propKey}`);
		});
	}
	updateNodeBounds(node, rect2);
	node.intersect = function(point2) {
		return intersect_default.rect(node, point2);
	};
	return shapeSvg;
}, "rect");
var composite = /* @__PURE__ */ __name(async (parent, node) => {
	const { shapeSvg, bbox, halfPadding } = await labelHelper(parent, node, "node " + node.classes, true);
	const rect2 = shapeSvg.insert("rect", ":first-child");
	const totalWidth = node.positioned ? node.width : bbox.width + node.padding;
	const totalHeight = node.positioned ? node.height : bbox.height + node.padding;
	const x = node.positioned ? -totalWidth / 2 : -bbox.width / 2 - halfPadding;
	const y = node.positioned ? -totalHeight / 2 : -bbox.height / 2 - halfPadding;
	rect2.attr("class", "basic cluster composite label-container").attr("style", node.style).attr("rx", node.rx).attr("ry", node.ry).attr("x", x).attr("y", y).attr("width", totalWidth).attr("height", totalHeight);
	if (node.props) {
		const propKeys = new Set(Object.keys(node.props));
		if (node.props.borders) {
			applyNodePropertyBorders(rect2, node.props.borders, totalWidth, totalHeight);
			propKeys.delete("borders");
		}
		propKeys.forEach((propKey) => {
			log.warn(`Unknown node property ${propKey}`);
		});
	}
	updateNodeBounds(node, rect2);
	node.intersect = function(point2) {
		return intersect_default.rect(node, point2);
	};
	return shapeSvg;
}, "composite");
var labelRect = /* @__PURE__ */ __name(async (parent, node) => {
	const { shapeSvg } = await labelHelper(parent, node, "label", true);
	log.trace("Classes = ", node.class);
	const rect2 = shapeSvg.insert("rect", ":first-child");
	const totalWidth = 0;
	const totalHeight = 0;
	rect2.attr("width", totalWidth).attr("height", totalHeight);
	shapeSvg.attr("class", "label edgeLabel");
	if (node.props) {
		const propKeys = new Set(Object.keys(node.props));
		if (node.props.borders) {
			applyNodePropertyBorders(rect2, node.props.borders, totalWidth, totalHeight);
			propKeys.delete("borders");
		}
		propKeys.forEach((propKey) => {
			log.warn(`Unknown node property ${propKey}`);
		});
	}
	updateNodeBounds(node, rect2);
	node.intersect = function(point2) {
		return intersect_default.rect(node, point2);
	};
	return shapeSvg;
}, "labelRect");
function applyNodePropertyBorders(rect2, borders, totalWidth, totalHeight) {
	const strokeDashArray = [];
	const addBorder = /* @__PURE__ */ __name((length) => {
		strokeDashArray.push(length, 0);
	}, "addBorder");
	const skipBorder = /* @__PURE__ */ __name((length) => {
		strokeDashArray.push(0, length);
	}, "skipBorder");
	if (borders.includes("t")) {
		log.debug("add top border");
		addBorder(totalWidth);
	} else skipBorder(totalWidth);
	if (borders.includes("r")) {
		log.debug("add right border");
		addBorder(totalHeight);
	} else skipBorder(totalHeight);
	if (borders.includes("b")) {
		log.debug("add bottom border");
		addBorder(totalWidth);
	} else skipBorder(totalWidth);
	if (borders.includes("l")) {
		log.debug("add left border");
		addBorder(totalHeight);
	} else skipBorder(totalHeight);
	rect2.attr("stroke-dasharray", strokeDashArray.join(" "));
}
__name(applyNodePropertyBorders, "applyNodePropertyBorders");
var rectWithTitle = /* @__PURE__ */ __name(async (parent, node) => {
	let classes2;
	if (!node.classes) classes2 = "node default";
	else classes2 = "node " + node.classes;
	const shapeSvg = parent.insert("g").attr("class", classes2).attr("id", node.domId || node.id);
	const rect2 = shapeSvg.insert("rect", ":first-child");
	const innerLine = shapeSvg.insert("line");
	const label = shapeSvg.insert("g").attr("class", "label");
	const text2 = node.labelText.flat ? node.labelText.flat() : node.labelText;
	let title = "";
	if (typeof text2 === "object") title = text2[0];
	else title = text2;
	log.info("Label text abc79", title, text2, typeof text2 === "object");
	const text = await createLabel_default(label, title, node.labelStyle, true, true);
	let bbox = {
		width: 0,
		height: 0
	};
	if (getEffectiveHtmlLabels(getConfig2())) {
		const div = text.children[0];
		const dv = select_default(text);
		bbox = div.getBoundingClientRect();
		dv.attr("width", bbox.width);
		dv.attr("height", bbox.height);
	}
	log.info("Text 2", text2);
	const textRows = text2.slice(1, text2.length);
	let titleBox = text.getBBox();
	const descr = await createLabel_default(label, textRows.join ? textRows.join("<br/>") : textRows, node.labelStyle, true, true);
	if (getEffectiveHtmlLabels(getConfig2())) {
		const div = descr.children[0];
		const dv = select_default(descr);
		bbox = div.getBoundingClientRect();
		dv.attr("width", bbox.width);
		dv.attr("height", bbox.height);
	}
	const halfPadding = node.padding / 2;
	select_default(descr).attr("transform", "translate( " + (bbox.width > titleBox.width ? 0 : (titleBox.width - bbox.width) / 2) + ", " + (titleBox.height + halfPadding + 5) + ")");
	select_default(text).attr("transform", "translate( " + (bbox.width < titleBox.width ? 0 : -(titleBox.width - bbox.width) / 2) + ", 0)");
	bbox = label.node().getBBox();
	label.attr("transform", "translate(" + -bbox.width / 2 + ", " + (-bbox.height / 2 - halfPadding + 3) + ")");
	rect2.attr("class", "outer title-state").attr("x", -bbox.width / 2 - halfPadding).attr("y", -bbox.height / 2 - halfPadding).attr("width", bbox.width + node.padding).attr("height", bbox.height + node.padding);
	innerLine.attr("class", "divider").attr("x1", -bbox.width / 2 - halfPadding).attr("x2", bbox.width / 2 + halfPadding).attr("y1", -bbox.height / 2 - halfPadding + titleBox.height + halfPadding).attr("y2", -bbox.height / 2 - halfPadding + titleBox.height + halfPadding);
	updateNodeBounds(node, rect2);
	node.intersect = function(point2) {
		return intersect_default.rect(node, point2);
	};
	return shapeSvg;
}, "rectWithTitle");
var stadium = /* @__PURE__ */ __name(async (parent, node) => {
	const { shapeSvg, bbox } = await labelHelper(parent, node, getClassesFromNode(node, void 0), true);
	const h = bbox.height + node.padding;
	const w = bbox.width + h / 4 + node.padding;
	updateNodeBounds(node, shapeSvg.insert("rect", ":first-child").attr("style", node.style).attr("rx", h / 2).attr("ry", h / 2).attr("x", -w / 2).attr("y", -h / 2).attr("width", w).attr("height", h));
	node.intersect = function(point2) {
		return intersect_default.rect(node, point2);
	};
	return shapeSvg;
}, "stadium");
var circle2 = /* @__PURE__ */ __name(async (parent, node) => {
	const { shapeSvg, bbox, halfPadding } = await labelHelper(parent, node, getClassesFromNode(node, void 0), true);
	const circle3 = shapeSvg.insert("circle", ":first-child");
	circle3.attr("style", node.style).attr("rx", node.rx).attr("ry", node.ry).attr("r", bbox.width / 2 + halfPadding).attr("width", bbox.width + node.padding).attr("height", bbox.height + node.padding);
	log.info("Circle main");
	updateNodeBounds(node, circle3);
	node.intersect = function(point2) {
		log.info("Circle intersect", node, bbox.width / 2 + halfPadding, point2);
		return intersect_default.circle(node, bbox.width / 2 + halfPadding, point2);
	};
	return shapeSvg;
}, "circle");
var doublecircle = /* @__PURE__ */ __name(async (parent, node) => {
	const { shapeSvg, bbox, halfPadding } = await labelHelper(parent, node, getClassesFromNode(node, void 0), true);
	const gap = 5;
	const circleGroup = shapeSvg.insert("g", ":first-child");
	const outerCircle = circleGroup.insert("circle");
	const innerCircle = circleGroup.insert("circle");
	circleGroup.attr("class", node.class);
	outerCircle.attr("style", node.style).attr("rx", node.rx).attr("ry", node.ry).attr("r", bbox.width / 2 + halfPadding + gap).attr("width", bbox.width + node.padding + gap * 2).attr("height", bbox.height + node.padding + gap * 2);
	innerCircle.attr("style", node.style).attr("rx", node.rx).attr("ry", node.ry).attr("r", bbox.width / 2 + halfPadding).attr("width", bbox.width + node.padding).attr("height", bbox.height + node.padding);
	log.info("DoubleCircle main");
	updateNodeBounds(node, outerCircle);
	node.intersect = function(point2) {
		log.info("DoubleCircle intersect", node, bbox.width / 2 + halfPadding + gap, point2);
		return intersect_default.circle(node, bbox.width / 2 + halfPadding + gap, point2);
	};
	return shapeSvg;
}, "doublecircle");
var subroutine = /* @__PURE__ */ __name(async (parent, node) => {
	const { shapeSvg, bbox } = await labelHelper(parent, node, getClassesFromNode(node, void 0), true);
	const w = bbox.width + node.padding;
	const h = bbox.height + node.padding;
	const points = [
		{
			x: 0,
			y: 0
		},
		{
			x: w,
			y: 0
		},
		{
			x: w,
			y: -h
		},
		{
			x: 0,
			y: -h
		},
		{
			x: 0,
			y: 0
		},
		{
			x: -8,
			y: 0
		},
		{
			x: w + 8,
			y: 0
		},
		{
			x: w + 8,
			y: -h
		},
		{
			x: -8,
			y: -h
		},
		{
			x: -8,
			y: 0
		}
	];
	const el = insertPolygonShape(shapeSvg, w, h, points);
	el.attr("style", node.style);
	updateNodeBounds(node, el);
	node.intersect = function(point2) {
		return intersect_default.polygon(node, points, point2);
	};
	return shapeSvg;
}, "subroutine");
var start = /* @__PURE__ */ __name((parent, node) => {
	const shapeSvg = parent.insert("g").attr("class", "node default").attr("id", node.domId || node.id);
	const circle3 = shapeSvg.insert("circle", ":first-child");
	circle3.attr("class", "state-start").attr("r", 7).attr("width", 14).attr("height", 14);
	updateNodeBounds(node, circle3);
	node.intersect = function(point2) {
		return intersect_default.circle(node, 7, point2);
	};
	return shapeSvg;
}, "start");
var forkJoin = /* @__PURE__ */ __name((parent, node, dir) => {
	const shapeSvg = parent.insert("g").attr("class", "node default").attr("id", node.domId || node.id);
	let width = 70;
	let height = 10;
	if (dir === "LR") {
		width = 10;
		height = 70;
	}
	updateNodeBounds(node, shapeSvg.append("rect").attr("x", -1 * width / 2).attr("y", -1 * height / 2).attr("width", width).attr("height", height).attr("class", "fork-join"));
	node.height = node.height + node.padding / 2;
	node.width = node.width + node.padding / 2;
	node.intersect = function(point2) {
		return intersect_default.rect(node, point2);
	};
	return shapeSvg;
}, "forkJoin");
var shapes = {
	rhombus: question,
	composite,
	question,
	rect,
	labelRect,
	rectWithTitle,
	choice,
	circle: circle2,
	doublecircle,
	stadium,
	hexagon,
	block_arrow,
	rect_left_inv_arrow,
	lean_right,
	lean_left,
	trapezoid,
	inv_trapezoid,
	rect_right_inv_arrow,
	cylinder,
	start,
	end: /* @__PURE__ */ __name((parent, node) => {
		const shapeSvg = parent.insert("g").attr("class", "node default").attr("id", node.domId || node.id);
		const innerCircle = shapeSvg.insert("circle", ":first-child");
		const circle3 = shapeSvg.insert("circle", ":first-child");
		circle3.attr("class", "state-start").attr("r", 7).attr("width", 14).attr("height", 14);
		innerCircle.attr("class", "state-end").attr("r", 5).attr("width", 10).attr("height", 10);
		updateNodeBounds(node, circle3);
		node.intersect = function(point2) {
			return intersect_default.circle(node, 7, point2);
		};
		return shapeSvg;
	}, "end"),
	note: note_default,
	subroutine,
	fork: forkJoin,
	join: forkJoin,
	class_box: /* @__PURE__ */ __name(async (parent, node) => {
		const halfPadding = node.padding / 2;
		const rowPadding = 4;
		const lineHeight = 8;
		let classes2;
		if (!node.classes) classes2 = "node default";
		else classes2 = "node " + node.classes;
		const shapeSvg = parent.insert("g").attr("class", classes2).attr("id", node.domId || node.id);
		const rect2 = shapeSvg.insert("rect", ":first-child");
		const topLine = shapeSvg.insert("line");
		const bottomLine = shapeSvg.insert("line");
		let maxWidth = 0;
		let maxHeight = rowPadding;
		const labelContainer = shapeSvg.insert("g").attr("class", "label");
		let verticalPos = 0;
		const hasInterface = node.classData.annotations?.[0];
		const interfaceLabel = await createLabel_default(labelContainer, node.classData.annotations[0] ? "«" + node.classData.annotations[0] + "»" : "", node.labelStyle, true, true);
		let interfaceBBox = interfaceLabel.getBBox();
		if (getEffectiveHtmlLabels(getConfig2())) {
			const div = interfaceLabel.children[0];
			const dv = select_default(interfaceLabel);
			interfaceBBox = div.getBoundingClientRect();
			dv.attr("width", interfaceBBox.width);
			dv.attr("height", interfaceBBox.height);
		}
		if (node.classData.annotations[0]) {
			maxHeight += interfaceBBox.height + rowPadding;
			maxWidth += interfaceBBox.width;
		}
		let classTitleString = node.classData.label;
		if (node.classData.type !== void 0 && node.classData.type !== "") if (getEffectiveHtmlLabels(getConfig2())) classTitleString += "&lt;" + node.classData.type + "&gt;";
		else classTitleString += "<" + node.classData.type + ">";
		const classTitleLabel = await createLabel_default(labelContainer, classTitleString, node.labelStyle, true, true);
		select_default(classTitleLabel).attr("class", "classTitle");
		let classTitleBBox = classTitleLabel.getBBox();
		if (getEffectiveHtmlLabels(getConfig2())) {
			const div = classTitleLabel.children[0];
			const dv = select_default(classTitleLabel);
			classTitleBBox = div.getBoundingClientRect();
			dv.attr("width", classTitleBBox.width);
			dv.attr("height", classTitleBBox.height);
		}
		maxHeight += classTitleBBox.height + rowPadding;
		if (classTitleBBox.width > maxWidth) maxWidth = classTitleBBox.width;
		const classAttributes = [];
		node.classData.members.forEach(async (member) => {
			const parsedInfo = member.getDisplayDetails();
			let parsedText = parsedInfo.displayText;
			if (getEffectiveHtmlLabels(getConfig2())) parsedText = parsedText.replace(/</g, "&lt;").replace(/>/g, "&gt;");
			const lbl = await createLabel_default(labelContainer, parsedText, parsedInfo.cssStyle ? parsedInfo.cssStyle : node.labelStyle, true, true);
			let bbox = lbl.getBBox();
			if (getEffectiveHtmlLabels(getConfig2())) {
				const div = lbl.children[0];
				const dv = select_default(lbl);
				bbox = div.getBoundingClientRect();
				dv.attr("width", bbox.width);
				dv.attr("height", bbox.height);
			}
			if (bbox.width > maxWidth) maxWidth = bbox.width;
			maxHeight += bbox.height + rowPadding;
			classAttributes.push(lbl);
		});
		maxHeight += lineHeight;
		const classMethods = [];
		node.classData.methods.forEach(async (member) => {
			const parsedInfo = member.getDisplayDetails();
			let displayText = parsedInfo.displayText;
			if (getEffectiveHtmlLabels(getConfig2())) displayText = displayText.replace(/</g, "&lt;").replace(/>/g, "&gt;");
			const lbl = await createLabel_default(labelContainer, displayText, parsedInfo.cssStyle ? parsedInfo.cssStyle : node.labelStyle, true, true);
			let bbox = lbl.getBBox();
			if (getEffectiveHtmlLabels(getConfig2())) {
				const div = lbl.children[0];
				const dv = select_default(lbl);
				bbox = div.getBoundingClientRect();
				dv.attr("width", bbox.width);
				dv.attr("height", bbox.height);
			}
			if (bbox.width > maxWidth) maxWidth = bbox.width;
			maxHeight += bbox.height + rowPadding;
			classMethods.push(lbl);
		});
		maxHeight += lineHeight;
		if (hasInterface) {
			let diffX2 = (maxWidth - interfaceBBox.width) / 2;
			select_default(interfaceLabel).attr("transform", "translate( " + (-1 * maxWidth / 2 + diffX2) + ", " + -1 * maxHeight / 2 + ")");
			verticalPos = interfaceBBox.height + rowPadding;
		}
		let diffX = (maxWidth - classTitleBBox.width) / 2;
		select_default(classTitleLabel).attr("transform", "translate( " + (-1 * maxWidth / 2 + diffX) + ", " + (-1 * maxHeight / 2 + verticalPos) + ")");
		verticalPos += classTitleBBox.height + rowPadding;
		topLine.attr("class", "divider").attr("x1", -maxWidth / 2 - halfPadding).attr("x2", maxWidth / 2 + halfPadding).attr("y1", -maxHeight / 2 - halfPadding + lineHeight + verticalPos).attr("y2", -maxHeight / 2 - halfPadding + lineHeight + verticalPos);
		verticalPos += lineHeight;
		classAttributes.forEach((lbl) => {
			select_default(lbl).attr("transform", "translate( " + -maxWidth / 2 + ", " + (-1 * maxHeight / 2 + verticalPos + lineHeight / 2) + ")");
			const memberBBox = lbl?.getBBox();
			verticalPos += (memberBBox?.height ?? 0) + rowPadding;
		});
		verticalPos += lineHeight;
		bottomLine.attr("class", "divider").attr("x1", -maxWidth / 2 - halfPadding).attr("x2", maxWidth / 2 + halfPadding).attr("y1", -maxHeight / 2 - halfPadding + lineHeight + verticalPos).attr("y2", -maxHeight / 2 - halfPadding + lineHeight + verticalPos);
		verticalPos += lineHeight;
		classMethods.forEach((lbl) => {
			select_default(lbl).attr("transform", "translate( " + -maxWidth / 2 + ", " + (-1 * maxHeight / 2 + verticalPos) + ")");
			const memberBBox = lbl?.getBBox();
			verticalPos += (memberBBox?.height ?? 0) + rowPadding;
		});
		rect2.attr("style", node.style).attr("class", "outer title-state").attr("x", -maxWidth / 2 - halfPadding).attr("y", -(maxHeight / 2) - halfPadding).attr("width", maxWidth + node.padding).attr("height", maxHeight + node.padding);
		updateNodeBounds(node, rect2);
		node.intersect = function(point2) {
			return intersect_default.rect(node, point2);
		};
		return shapeSvg;
	}, "class_box")
};
var nodeElems = {};
var insertNode = /* @__PURE__ */ __name(async (elem, node, renderOptions) => {
	let newEl;
	let el;
	if (node.link) {
		let target;
		if (getConfig2().securityLevel === "sandbox") target = "_top";
		else if (node.linkTarget) target = node.linkTarget || "_blank";
		newEl = elem.insert("svg:a").attr("xlink:href", node.link).attr("target", target);
		el = await shapes[node.shape](newEl, node, renderOptions);
	} else {
		el = await shapes[node.shape](elem, node, renderOptions);
		newEl = el;
	}
	if (node.tooltip) el.attr("title", node.tooltip);
	if (node.class) el.attr("class", "node default " + node.class);
	nodeElems[node.id] = newEl;
	if (node.haveCallback) nodeElems[node.id].attr("class", nodeElems[node.id].attr("class") + " clickable");
	return newEl;
}, "insertNode");
var positionNode = /* @__PURE__ */ __name((node) => {
	const el = nodeElems[node.id];
	log.trace("Transforming node", node.diff, node, "translate(" + (node.x - node.width / 2 - 5) + ", " + node.width / 2 + ")");
	const padding2 = 8;
	const diff = node.diff || 0;
	if (node.clusterNode) el.attr("transform", "translate(" + (node.x + diff - node.width / 2) + ", " + (node.y - node.height / 2 - padding2) + ")");
	else el.attr("transform", "translate(" + node.x + ", " + node.y + ")");
	return diff;
}, "positionNode");
function getNodeFromBlock(block, db2, positioned = false) {
	const vertex = block;
	let classStr = "default";
	if ((vertex?.classes?.length || 0) > 0) classStr = (vertex?.classes ?? []).join(" ");
	classStr = classStr + " flowchart-label";
	let radius = 0;
	let shape = "";
	let padding2;
	switch (vertex.type) {
		case "round":
			radius = 5;
			shape = "rect";
			break;
		case "composite":
			radius = 0;
			shape = "composite";
			padding2 = 0;
			break;
		case "square":
			shape = "rect";
			break;
		case "diamond":
			shape = "question";
			break;
		case "hexagon":
			shape = "hexagon";
			break;
		case "block_arrow":
			shape = "block_arrow";
			break;
		case "odd":
			shape = "rect_left_inv_arrow";
			break;
		case "lean_right":
			shape = "lean_right";
			break;
		case "lean_left":
			shape = "lean_left";
			break;
		case "trapezoid":
			shape = "trapezoid";
			break;
		case "inv_trapezoid":
			shape = "inv_trapezoid";
			break;
		case "rect_left_inv_arrow":
			shape = "rect_left_inv_arrow";
			break;
		case "circle":
			shape = "circle";
			break;
		case "ellipse":
			shape = "ellipse";
			break;
		case "stadium":
			shape = "stadium";
			break;
		case "subroutine":
			shape = "subroutine";
			break;
		case "cylinder":
			shape = "cylinder";
			break;
		case "group":
			shape = "rect";
			break;
		case "doublecircle":
			shape = "doublecircle";
			break;
		default: shape = "rect";
	}
	const styles = getStylesFromArray(vertex?.styles ?? []);
	const vertexText = vertex.label;
	const bounds = vertex.size ?? {
		width: 0,
		height: 0,
		x: 0,
		y: 0
	};
	const dbDiagramId = db2.getDiagramId();
	return {
		labelStyle: styles.labelStyle,
		shape,
		labelText: vertexText,
		rx: radius,
		ry: radius,
		class: classStr,
		style: styles.style,
		id: vertex.id,
		domId: dbDiagramId ? `${dbDiagramId}-${vertex.id}` : vertex.id,
		directions: vertex.directions,
		width: bounds.width,
		height: bounds.height,
		x: bounds.x,
		y: bounds.y,
		positioned,
		intersect: void 0,
		type: vertex.type,
		padding: padding2 ?? getConfig()?.block?.padding ?? 0,
		widthInColumns: vertex.widthInColumns ?? 1
	};
}
__name(getNodeFromBlock, "getNodeFromBlock");
async function calculateBlockSize(elem, block, db2) {
	const node = getNodeFromBlock(block, db2, false);
	if (node.type === "group") return;
	const nodeEl = await insertNode(elem, node, { config: getConfig() });
	const boundingBox = nodeEl.node().getBBox();
	const obj = db2.getBlock(node.id);
	obj.size = {
		width: boundingBox.width,
		height: boundingBox.height,
		x: 0,
		y: 0,
		node: nodeEl
	};
	db2.setBlock(obj);
	nodeEl.remove();
}
__name(calculateBlockSize, "calculateBlockSize");
async function insertBlockPositioned(elem, block, db2) {
	const node = getNodeFromBlock(block, db2, true);
	if (db2.getBlock(node.id).type !== "space") {
		await insertNode(elem, node, { config: getConfig() });
		block.intersect = node?.intersect;
		positionNode(node);
	}
}
__name(insertBlockPositioned, "insertBlockPositioned");
async function performOperations(elem, blocks2, db2, operation) {
	for (const block of blocks2) {
		await operation(elem, block, db2);
		if (block.children) await performOperations(elem, block.children, db2, operation);
	}
}
__name(performOperations, "performOperations");
async function calculateBlockSizes(elem, blocks2, db2) {
	await performOperations(elem, blocks2, db2, calculateBlockSize);
}
__name(calculateBlockSizes, "calculateBlockSizes");
async function insertBlocks(elem, blocks2, db2) {
	await performOperations(elem, blocks2, db2, insertBlockPositioned);
}
__name(insertBlocks, "insertBlocks");
async function insertEdges(elem, edges, blocks2, db2, id) {
	const g = new Graph({
		multigraph: true,
		compound: true
	});
	g.setGraph({
		rankdir: "TB",
		nodesep: 10,
		ranksep: 10,
		marginx: 8,
		marginy: 8
	});
	for (const block of blocks2) if (block.size) g.setNode(block.id, {
		width: block.size.width,
		height: block.size.height,
		intersect: block.intersect
	});
	for (const edge of edges) if (edge.start && edge.end) {
		const startBlock = db2.getBlock(edge.start);
		const endBlock = db2.getBlock(edge.end);
		if (startBlock?.size && endBlock?.size) {
			const start2 = startBlock.size;
			const end2 = endBlock.size;
			const points = [
				{
					x: start2.x,
					y: start2.y
				},
				{
					x: start2.x + (end2.x - start2.x) / 2,
					y: start2.y + (end2.y - start2.y) / 2
				},
				{
					x: end2.x,
					y: end2.y
				}
			];
			const prefixedEdgeId = id ? `${id}-${edge.id}` : edge.id;
			const dynamicClasses = `${edge.thickness === "thick" ? "edge-thickness-thick" : "edge-thickness-normal"} ${edge.pattern === "dotted" ? "edge-pattern-dotted" : "edge-pattern-solid"} flowchart-link LS-a1 LE-b1`;
			insertEdge(elem, {
				v: edge.start,
				w: edge.end,
				name: prefixedEdgeId
			}, {
				...edge,
				id: prefixedEdgeId,
				arrowTypeEnd: edge.arrowTypeEnd,
				arrowTypeStart: edge.arrowTypeStart,
				points,
				classes: dynamicClasses
			}, void 0, "block", g, id);
			if (edge.label) {
				await insertEdgeLabel(elem, {
					...edge,
					label: edge.label,
					labelStyle: "stroke: #333; stroke-width: 1.5px;fill:none;",
					arrowTypeEnd: edge.arrowTypeEnd,
					arrowTypeStart: edge.arrowTypeStart,
					points,
					classes: dynamicClasses
				});
				positionEdgeLabel({
					...edge,
					x: points[1].x,
					y: points[1].y
				}, { originalPath: points });
			}
		}
	}
}
__name(insertEdges, "insertEdges");
var diagram = {
	parser: block_default,
	db: blockDB_default,
	renderer: {
		draw: /* @__PURE__ */ __name(async function(text, id, _version, diagObj) {
			const { securityLevel, block: conf } = getConfig();
			const db2 = diagObj.db;
			db2.setDiagramId(id);
			let sandboxElement;
			if (securityLevel === "sandbox") sandboxElement = select_default("#i" + id);
			const root = securityLevel === "sandbox" ? select_default(sandboxElement.nodes()[0].contentDocument.body) : select_default("body");
			const svg = securityLevel === "sandbox" ? root.select(`[id="${id}"]`) : select_default(`[id="${id}"]`);
			markers_default(svg, [
				"point",
				"circle",
				"cross"
			], diagObj.type, id);
			const bl = db2.getBlocks();
			const blArr = db2.getBlocksFlat();
			const edges = db2.getEdges();
			const nodes = svg.insert("g").attr("class", "block");
			await calculateBlockSizes(nodes, bl, db2);
			const bounds = layout(db2);
			await insertBlocks(nodes, bl, db2);
			await insertEdges(nodes, edges, blArr, db2, id);
			if (bounds) {
				const bounds2 = bounds;
				const magicFactor = Math.max(1, Math.round(.125 * (bounds2.width / bounds2.height)));
				const height = bounds2.height + magicFactor + 10;
				const width = bounds2.width + 10;
				const { useMaxWidth } = conf;
				configureSvgSize(svg, height, width, !!useMaxWidth);
				log.debug("Here Bounds", bounds, bounds2);
				svg.attr("viewBox", `${bounds2.x - 5} ${bounds2.y - 5} ${bounds2.width + 10} ${bounds2.height + 10}`);
			}
		}, "draw"),
		getClasses: /* @__PURE__ */ __name(function(text, diagObj) {
			return diagObj.db.getClasses();
		}, "getClasses")
	},
	styles: styles_default
};
//#endregion
export { diagram };

//# sourceMappingURL=blockDiagram-GPEHLZMM-D1afzhEg.js.map