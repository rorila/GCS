import { H as __name, U as log, V as __export, W as setLogLevel } from "./src-BFTritsu.js";
import purify from "./dompurify.js";
//#region node_modules/khroma/dist/utils/channel.js
var Channel = {
	min: {
		r: 0,
		g: 0,
		b: 0,
		s: 0,
		l: 0,
		a: 0
	},
	max: {
		r: 255,
		g: 255,
		b: 255,
		h: 360,
		s: 100,
		l: 100,
		a: 1
	},
	clamp: {
		r: (r) => r >= 255 ? 255 : r < 0 ? 0 : r,
		g: (g) => g >= 255 ? 255 : g < 0 ? 0 : g,
		b: (b) => b >= 255 ? 255 : b < 0 ? 0 : b,
		h: (h) => h % 360,
		s: (s) => s >= 100 ? 100 : s < 0 ? 0 : s,
		l: (l) => l >= 100 ? 100 : l < 0 ? 0 : l,
		a: (a) => a >= 1 ? 1 : a < 0 ? 0 : a
	},
	toLinear: (c) => {
		const n = c / 255;
		return c > .03928 ? Math.pow((n + .055) / 1.055, 2.4) : n / 12.92;
	},
	hue2rgb: (p, q, t) => {
		if (t < 0) t += 1;
		if (t > 1) t -= 1;
		if (t < 1 / 6) return p + (q - p) * 6 * t;
		if (t < 1 / 2) return q;
		if (t < 2 / 3) return p + (q - p) * (2 / 3 - t) * 6;
		return p;
	},
	hsl2rgb: ({ h, s, l }, channel) => {
		if (!s) return l * 2.55;
		h /= 360;
		s /= 100;
		l /= 100;
		const q = l < .5 ? l * (1 + s) : l + s - l * s;
		const p = 2 * l - q;
		switch (channel) {
			case "r": return Channel.hue2rgb(p, q, h + 1 / 3) * 255;
			case "g": return Channel.hue2rgb(p, q, h) * 255;
			case "b": return Channel.hue2rgb(p, q, h - 1 / 3) * 255;
		}
	},
	rgb2hsl: ({ r, g, b }, channel) => {
		r /= 255;
		g /= 255;
		b /= 255;
		const max = Math.max(r, g, b);
		const min = Math.min(r, g, b);
		const l = (max + min) / 2;
		if (channel === "l") return l * 100;
		if (max === min) return 0;
		const d = max - min;
		const s = l > .5 ? d / (2 - max - min) : d / (max + min);
		if (channel === "s") return s * 100;
		switch (max) {
			case r: return ((g - b) / d + (g < b ? 6 : 0)) * 60;
			case g: return ((b - r) / d + 2) * 60;
			case b: return ((r - g) / d + 4) * 60;
			default: return -1;
		}
	}
};
//#endregion
//#region node_modules/khroma/dist/utils/index.js
var Utils = {
	channel: Channel,
	lang: {
		clamp: (number, lower, upper) => {
			if (lower > upper) return Math.min(lower, Math.max(upper, number));
			return Math.min(upper, Math.max(lower, number));
		},
		round: (number) => {
			return Math.round(number * 1e10) / 1e10;
		}
	},
	unit: { dec2hex: (dec) => {
		const hex = Math.round(dec).toString(16);
		return hex.length > 1 ? hex : `0${hex}`;
	} }
};
//#endregion
//#region node_modules/khroma/dist/constants.js
var DEC2HEX = {};
for (let i = 0; i <= 255; i++) DEC2HEX[i] = Utils.unit.dec2hex(i);
var TYPE = {
	ALL: 0,
	RGB: 1,
	HSL: 2
};
//#endregion
//#region node_modules/khroma/dist/channels/type.js
var Type = class {
	constructor() {
		this.type = TYPE.ALL;
	}
	get() {
		return this.type;
	}
	set(type) {
		if (this.type && this.type !== type) throw new Error("Cannot change both RGB and HSL channels at the same time");
		this.type = type;
	}
	reset() {
		this.type = TYPE.ALL;
	}
	is(type) {
		return this.type === type;
	}
};
//#endregion
//#region node_modules/khroma/dist/channels/index.js
var Channels = class {
	constructor(data, color) {
		this.color = color;
		this.changed = false;
		this.data = data;
		this.type = new Type();
	}
	set(data, color) {
		this.color = color;
		this.changed = false;
		this.data = data;
		this.type.type = TYPE.ALL;
		return this;
	}
	_ensureHSL() {
		const data = this.data;
		const { h, s, l } = data;
		if (h === void 0) data.h = Utils.channel.rgb2hsl(data, "h");
		if (s === void 0) data.s = Utils.channel.rgb2hsl(data, "s");
		if (l === void 0) data.l = Utils.channel.rgb2hsl(data, "l");
	}
	_ensureRGB() {
		const data = this.data;
		const { r, g, b } = data;
		if (r === void 0) data.r = Utils.channel.hsl2rgb(data, "r");
		if (g === void 0) data.g = Utils.channel.hsl2rgb(data, "g");
		if (b === void 0) data.b = Utils.channel.hsl2rgb(data, "b");
	}
	get r() {
		const data = this.data;
		const r = data.r;
		if (!this.type.is(TYPE.HSL) && r !== void 0) return r;
		this._ensureHSL();
		return Utils.channel.hsl2rgb(data, "r");
	}
	get g() {
		const data = this.data;
		const g = data.g;
		if (!this.type.is(TYPE.HSL) && g !== void 0) return g;
		this._ensureHSL();
		return Utils.channel.hsl2rgb(data, "g");
	}
	get b() {
		const data = this.data;
		const b = data.b;
		if (!this.type.is(TYPE.HSL) && b !== void 0) return b;
		this._ensureHSL();
		return Utils.channel.hsl2rgb(data, "b");
	}
	get h() {
		const data = this.data;
		const h = data.h;
		if (!this.type.is(TYPE.RGB) && h !== void 0) return h;
		this._ensureRGB();
		return Utils.channel.rgb2hsl(data, "h");
	}
	get s() {
		const data = this.data;
		const s = data.s;
		if (!this.type.is(TYPE.RGB) && s !== void 0) return s;
		this._ensureRGB();
		return Utils.channel.rgb2hsl(data, "s");
	}
	get l() {
		const data = this.data;
		const l = data.l;
		if (!this.type.is(TYPE.RGB) && l !== void 0) return l;
		this._ensureRGB();
		return Utils.channel.rgb2hsl(data, "l");
	}
	get a() {
		return this.data.a;
	}
	set r(r) {
		this.type.set(TYPE.RGB);
		this.changed = true;
		this.data.r = r;
	}
	set g(g) {
		this.type.set(TYPE.RGB);
		this.changed = true;
		this.data.g = g;
	}
	set b(b) {
		this.type.set(TYPE.RGB);
		this.changed = true;
		this.data.b = b;
	}
	set h(h) {
		this.type.set(TYPE.HSL);
		this.changed = true;
		this.data.h = h;
	}
	set s(s) {
		this.type.set(TYPE.HSL);
		this.changed = true;
		this.data.s = s;
	}
	set l(l) {
		this.type.set(TYPE.HSL);
		this.changed = true;
		this.data.l = l;
	}
	set a(a) {
		this.changed = true;
		this.data.a = a;
	}
};
//#endregion
//#region node_modules/khroma/dist/channels/reusable.js
var channels = new Channels({
	r: 0,
	g: 0,
	b: 0,
	a: 0
}, "transparent");
//#endregion
//#region node_modules/khroma/dist/color/hex.js
var Hex = {
	re: /^#((?:[a-f0-9]{2}){2,4}|[a-f0-9]{3})$/i,
	parse: (color) => {
		if (color.charCodeAt(0) !== 35) return;
		const match = color.match(Hex.re);
		if (!match) return;
		const hex = match[1];
		const dec = parseInt(hex, 16);
		const length = hex.length;
		const hasAlpha = length % 4 === 0;
		const isFullLength = length > 4;
		const multiplier = isFullLength ? 1 : 17;
		const bits = isFullLength ? 8 : 4;
		const bitsOffset = hasAlpha ? 0 : -1;
		const mask = isFullLength ? 255 : 15;
		return channels.set({
			r: (dec >> bits * (bitsOffset + 3) & mask) * multiplier,
			g: (dec >> bits * (bitsOffset + 2) & mask) * multiplier,
			b: (dec >> bits * (bitsOffset + 1) & mask) * multiplier,
			a: hasAlpha ? (dec & mask) * multiplier / 255 : 1
		}, color);
	},
	stringify: (channels) => {
		const { r, g, b, a } = channels;
		if (a < 1) return `#${DEC2HEX[Math.round(r)]}${DEC2HEX[Math.round(g)]}${DEC2HEX[Math.round(b)]}${DEC2HEX[Math.round(a * 255)]}`;
		else return `#${DEC2HEX[Math.round(r)]}${DEC2HEX[Math.round(g)]}${DEC2HEX[Math.round(b)]}`;
	}
};
//#endregion
//#region node_modules/khroma/dist/color/hsl.js
var HSL = {
	re: /^hsla?\(\s*?(-?(?:\d+(?:\.\d+)?|(?:\.\d+))(?:e-?\d+)?(?:deg|grad|rad|turn)?)\s*?(?:,|\s)\s*?(-?(?:\d+(?:\.\d+)?|(?:\.\d+))(?:e-?\d+)?%)\s*?(?:,|\s)\s*?(-?(?:\d+(?:\.\d+)?|(?:\.\d+))(?:e-?\d+)?%)(?:\s*?(?:,|\/)\s*?\+?(-?(?:\d+(?:\.\d+)?|(?:\.\d+))(?:e-?\d+)?(%)?))?\s*?\)$/i,
	hueRe: /^(.+?)(deg|grad|rad|turn)$/i,
	_hue2deg: (hue) => {
		const match = hue.match(HSL.hueRe);
		if (match) {
			const [, number, unit] = match;
			switch (unit) {
				case "grad": return Utils.channel.clamp.h(parseFloat(number) * .9);
				case "rad": return Utils.channel.clamp.h(parseFloat(number) * 180 / Math.PI);
				case "turn": return Utils.channel.clamp.h(parseFloat(number) * 360);
			}
		}
		return Utils.channel.clamp.h(parseFloat(hue));
	},
	parse: (color) => {
		const charCode = color.charCodeAt(0);
		if (charCode !== 104 && charCode !== 72) return;
		const match = color.match(HSL.re);
		if (!match) return;
		const [, h, s, l, a, isAlphaPercentage] = match;
		return channels.set({
			h: HSL._hue2deg(h),
			s: Utils.channel.clamp.s(parseFloat(s)),
			l: Utils.channel.clamp.l(parseFloat(l)),
			a: a ? Utils.channel.clamp.a(isAlphaPercentage ? parseFloat(a) / 100 : parseFloat(a)) : 1
		}, color);
	},
	stringify: (channels) => {
		const { h, s, l, a } = channels;
		if (a < 1) return `hsla(${Utils.lang.round(h)}, ${Utils.lang.round(s)}%, ${Utils.lang.round(l)}%, ${a})`;
		else return `hsl(${Utils.lang.round(h)}, ${Utils.lang.round(s)}%, ${Utils.lang.round(l)}%)`;
	}
};
//#endregion
//#region node_modules/khroma/dist/color/keyword.js
var Keyword = {
	colors: {
		aliceblue: "#f0f8ff",
		antiquewhite: "#faebd7",
		aqua: "#00ffff",
		aquamarine: "#7fffd4",
		azure: "#f0ffff",
		beige: "#f5f5dc",
		bisque: "#ffe4c4",
		black: "#000000",
		blanchedalmond: "#ffebcd",
		blue: "#0000ff",
		blueviolet: "#8a2be2",
		brown: "#a52a2a",
		burlywood: "#deb887",
		cadetblue: "#5f9ea0",
		chartreuse: "#7fff00",
		chocolate: "#d2691e",
		coral: "#ff7f50",
		cornflowerblue: "#6495ed",
		cornsilk: "#fff8dc",
		crimson: "#dc143c",
		cyanaqua: "#00ffff",
		darkblue: "#00008b",
		darkcyan: "#008b8b",
		darkgoldenrod: "#b8860b",
		darkgray: "#a9a9a9",
		darkgreen: "#006400",
		darkgrey: "#a9a9a9",
		darkkhaki: "#bdb76b",
		darkmagenta: "#8b008b",
		darkolivegreen: "#556b2f",
		darkorange: "#ff8c00",
		darkorchid: "#9932cc",
		darkred: "#8b0000",
		darksalmon: "#e9967a",
		darkseagreen: "#8fbc8f",
		darkslateblue: "#483d8b",
		darkslategray: "#2f4f4f",
		darkslategrey: "#2f4f4f",
		darkturquoise: "#00ced1",
		darkviolet: "#9400d3",
		deeppink: "#ff1493",
		deepskyblue: "#00bfff",
		dimgray: "#696969",
		dimgrey: "#696969",
		dodgerblue: "#1e90ff",
		firebrick: "#b22222",
		floralwhite: "#fffaf0",
		forestgreen: "#228b22",
		fuchsia: "#ff00ff",
		gainsboro: "#dcdcdc",
		ghostwhite: "#f8f8ff",
		gold: "#ffd700",
		goldenrod: "#daa520",
		gray: "#808080",
		green: "#008000",
		greenyellow: "#adff2f",
		grey: "#808080",
		honeydew: "#f0fff0",
		hotpink: "#ff69b4",
		indianred: "#cd5c5c",
		indigo: "#4b0082",
		ivory: "#fffff0",
		khaki: "#f0e68c",
		lavender: "#e6e6fa",
		lavenderblush: "#fff0f5",
		lawngreen: "#7cfc00",
		lemonchiffon: "#fffacd",
		lightblue: "#add8e6",
		lightcoral: "#f08080",
		lightcyan: "#e0ffff",
		lightgoldenrodyellow: "#fafad2",
		lightgray: "#d3d3d3",
		lightgreen: "#90ee90",
		lightgrey: "#d3d3d3",
		lightpink: "#ffb6c1",
		lightsalmon: "#ffa07a",
		lightseagreen: "#20b2aa",
		lightskyblue: "#87cefa",
		lightslategray: "#778899",
		lightslategrey: "#778899",
		lightsteelblue: "#b0c4de",
		lightyellow: "#ffffe0",
		lime: "#00ff00",
		limegreen: "#32cd32",
		linen: "#faf0e6",
		magenta: "#ff00ff",
		maroon: "#800000",
		mediumaquamarine: "#66cdaa",
		mediumblue: "#0000cd",
		mediumorchid: "#ba55d3",
		mediumpurple: "#9370db",
		mediumseagreen: "#3cb371",
		mediumslateblue: "#7b68ee",
		mediumspringgreen: "#00fa9a",
		mediumturquoise: "#48d1cc",
		mediumvioletred: "#c71585",
		midnightblue: "#191970",
		mintcream: "#f5fffa",
		mistyrose: "#ffe4e1",
		moccasin: "#ffe4b5",
		navajowhite: "#ffdead",
		navy: "#000080",
		oldlace: "#fdf5e6",
		olive: "#808000",
		olivedrab: "#6b8e23",
		orange: "#ffa500",
		orangered: "#ff4500",
		orchid: "#da70d6",
		palegoldenrod: "#eee8aa",
		palegreen: "#98fb98",
		paleturquoise: "#afeeee",
		palevioletred: "#db7093",
		papayawhip: "#ffefd5",
		peachpuff: "#ffdab9",
		peru: "#cd853f",
		pink: "#ffc0cb",
		plum: "#dda0dd",
		powderblue: "#b0e0e6",
		purple: "#800080",
		rebeccapurple: "#663399",
		red: "#ff0000",
		rosybrown: "#bc8f8f",
		royalblue: "#4169e1",
		saddlebrown: "#8b4513",
		salmon: "#fa8072",
		sandybrown: "#f4a460",
		seagreen: "#2e8b57",
		seashell: "#fff5ee",
		sienna: "#a0522d",
		silver: "#c0c0c0",
		skyblue: "#87ceeb",
		slateblue: "#6a5acd",
		slategray: "#708090",
		slategrey: "#708090",
		snow: "#fffafa",
		springgreen: "#00ff7f",
		tan: "#d2b48c",
		teal: "#008080",
		thistle: "#d8bfd8",
		transparent: "#00000000",
		turquoise: "#40e0d0",
		violet: "#ee82ee",
		wheat: "#f5deb3",
		white: "#ffffff",
		whitesmoke: "#f5f5f5",
		yellow: "#ffff00",
		yellowgreen: "#9acd32"
	},
	parse: (color) => {
		color = color.toLowerCase();
		const hex = Keyword.colors[color];
		if (!hex) return;
		return Hex.parse(hex);
	},
	stringify: (channels) => {
		const hex = Hex.stringify(channels);
		for (const name in Keyword.colors) if (Keyword.colors[name] === hex) return name;
	}
};
//#endregion
//#region node_modules/khroma/dist/color/rgb.js
var RGB = {
	re: /^rgba?\(\s*?(-?(?:\d+(?:\.\d+)?|(?:\.\d+))(?:e\d+)?(%?))\s*?(?:,|\s)\s*?(-?(?:\d+(?:\.\d+)?|(?:\.\d+))(?:e\d+)?(%?))\s*?(?:,|\s)\s*?(-?(?:\d+(?:\.\d+)?|(?:\.\d+))(?:e\d+)?(%?))(?:\s*?(?:,|\/)\s*?\+?(-?(?:\d+(?:\.\d+)?|(?:\.\d+))(?:e\d+)?(%?)))?\s*?\)$/i,
	parse: (color) => {
		const charCode = color.charCodeAt(0);
		if (charCode !== 114 && charCode !== 82) return;
		const match = color.match(RGB.re);
		if (!match) return;
		const [, r, isRedPercentage, g, isGreenPercentage, b, isBluePercentage, a, isAlphaPercentage] = match;
		return channels.set({
			r: Utils.channel.clamp.r(isRedPercentage ? parseFloat(r) * 2.55 : parseFloat(r)),
			g: Utils.channel.clamp.g(isGreenPercentage ? parseFloat(g) * 2.55 : parseFloat(g)),
			b: Utils.channel.clamp.b(isBluePercentage ? parseFloat(b) * 2.55 : parseFloat(b)),
			a: a ? Utils.channel.clamp.a(isAlphaPercentage ? parseFloat(a) / 100 : parseFloat(a)) : 1
		}, color);
	},
	stringify: (channels) => {
		const { r, g, b, a } = channels;
		if (a < 1) return `rgba(${Utils.lang.round(r)}, ${Utils.lang.round(g)}, ${Utils.lang.round(b)}, ${Utils.lang.round(a)})`;
		else return `rgb(${Utils.lang.round(r)}, ${Utils.lang.round(g)}, ${Utils.lang.round(b)})`;
	}
};
//#endregion
//#region node_modules/khroma/dist/color/index.js
var Color = {
	format: {
		keyword: Keyword,
		hex: Hex,
		rgb: RGB,
		rgba: RGB,
		hsl: HSL,
		hsla: HSL
	},
	parse: (color) => {
		if (typeof color !== "string") return color;
		const channels = Hex.parse(color) || RGB.parse(color) || HSL.parse(color) || Keyword.parse(color);
		if (channels) return channels;
		throw new Error(`Unsupported color format: "${color}"`);
	},
	stringify: (channels) => {
		if (!channels.changed && channels.color) return channels.color;
		if (channels.type.is(TYPE.HSL) || channels.data.r === void 0) return HSL.stringify(channels);
		else if (channels.a < 1 || !Number.isInteger(channels.r) || !Number.isInteger(channels.g) || !Number.isInteger(channels.b)) return RGB.stringify(channels);
		else return Hex.stringify(channels);
	}
};
//#endregion
//#region node_modules/khroma/dist/methods/change.js
var change = (color, channels) => {
	const ch = Color.parse(color);
	for (const c in channels) ch[c] = Utils.channel.clamp[c](channels[c]);
	return Color.stringify(ch);
};
//#endregion
//#region node_modules/khroma/dist/methods/rgba.js
var rgba = (r, g, b = 0, a = 1) => {
	if (typeof r !== "number") return change(r, { a: g });
	const channels$1 = channels.set({
		r: Utils.channel.clamp.r(r),
		g: Utils.channel.clamp.g(g),
		b: Utils.channel.clamp.b(b),
		a: Utils.channel.clamp.a(a)
	});
	return Color.stringify(channels$1);
};
//#endregion
//#region node_modules/khroma/dist/methods/luminance.js
var luminance = (color) => {
	const { r, g, b } = Color.parse(color);
	const luminance = .2126 * Utils.channel.toLinear(r) + .7152 * Utils.channel.toLinear(g) + .0722 * Utils.channel.toLinear(b);
	return Utils.lang.round(luminance);
};
//#endregion
//#region node_modules/khroma/dist/methods/is_light.js
var isLight = (color) => {
	return luminance(color) >= .5;
};
//#endregion
//#region node_modules/khroma/dist/methods/is_dark.js
var isDark = (color) => {
	return !isLight(color);
};
//#endregion
//#region node_modules/khroma/dist/methods/adjust_channel.js
var adjustChannel = (color, channel, amount) => {
	const channels = Color.parse(color);
	const amountCurrent = channels[channel];
	const amountNext = Utils.channel.clamp[channel](amountCurrent + amount);
	if (amountCurrent !== amountNext) channels[channel] = amountNext;
	return Color.stringify(channels);
};
//#endregion
//#region node_modules/khroma/dist/methods/lighten.js
var lighten = (color, amount) => {
	return adjustChannel(color, "l", amount);
};
//#endregion
//#region node_modules/khroma/dist/methods/darken.js
var darken = (color, amount) => {
	return adjustChannel(color, "l", -amount);
};
//#endregion
//#region node_modules/khroma/dist/methods/adjust.js
var adjust = (color, channels) => {
	const ch = Color.parse(color);
	const changes = {};
	for (const c in channels) {
		if (!channels[c]) continue;
		changes[c] = ch[c] + channels[c];
	}
	return change(color, changes);
};
//#endregion
//#region node_modules/khroma/dist/methods/mix.js
var mix = (color1, color2, weight = 50) => {
	const { r: r1, g: g1, b: b1, a: a1 } = Color.parse(color1);
	const { r: r2, g: g2, b: b2, a: a2 } = Color.parse(color2);
	const weightScale = weight / 100;
	const weightNormalized = weightScale * 2 - 1;
	const alphaDelta = a1 - a2;
	const weight1 = ((weightNormalized * alphaDelta === -1 ? weightNormalized : (weightNormalized + alphaDelta) / (1 + weightNormalized * alphaDelta)) + 1) / 2;
	const weight2 = 1 - weight1;
	return rgba(r1 * weight1 + r2 * weight2, g1 * weight1 + g2 * weight2, b1 * weight1 + b2 * weight2, a1 * weightScale + a2 * (1 - weightScale));
};
//#endregion
//#region node_modules/khroma/dist/methods/invert.js
var invert = (color, weight = 100) => {
	const inverse = Color.parse(color);
	inverse.r = 255 - inverse.r;
	inverse.g = 255 - inverse.g;
	inverse.b = 255 - inverse.b;
	return mix(inverse, color, weight);
};
//#endregion
//#region node_modules/mermaid/dist/chunks/mermaid.core/chunk-CSCIHK7Q.mjs
var frontMatterRegex = /^-{3}\s*[\n\r](.*?)[\n\r]-{3}\s*[\n\r]+/s;
var directiveRegex = /%{2}{\s*(?:(\w+)\s*:|(\w+))\s*(?:(\w+)|((?:(?!}%{2}).|\r?\n)*))?\s*(?:}%{2})?/gi;
var anyCommentRegex = /\s*%%.*\n/gm;
var UnknownDiagramError = class extends Error {
	static {
		__name(this, "UnknownDiagramError");
	}
	constructor(message) {
		super(message);
		this.name = "UnknownDiagramError";
	}
};
var detectors = {};
var detectType = /* @__PURE__ */ __name(function(text, config2) {
	text = text.replace(frontMatterRegex, "").replace(directiveRegex, "").replace(anyCommentRegex, "\n");
	for (const [key, { detector }] of Object.entries(detectors)) if (detector(text, config2)) return key;
	throw new UnknownDiagramError(`No diagram type detected matching given configuration for text: ${text}`);
}, "detectType");
var registerLazyLoadedDiagrams = /* @__PURE__ */ __name((...diagrams2) => {
	for (const { id, detector, loader } of diagrams2) addDetector(id, detector, loader);
}, "registerLazyLoadedDiagrams");
var addDetector = /* @__PURE__ */ __name((key, detector, loader) => {
	if (detectors[key]) log.warn(`Detector with key ${key} already exists. Overwriting.`);
	detectors[key] = {
		detector,
		loader
	};
	log.debug(`Detector with key ${key} added${loader ? " with loader" : ""}`);
}, "addDetector");
var getDiagramLoader = /* @__PURE__ */ __name((key) => {
	return detectors[key].loader;
}, "getDiagramLoader");
var assignWithDepth = /* @__PURE__ */ __name((dst, src, { depth = 2, clobber = false } = {}) => {
	const config2 = {
		depth,
		clobber
	};
	if (Array.isArray(src) && !Array.isArray(dst)) {
		src.forEach((s) => assignWithDepth(dst, s, config2));
		return dst;
	} else if (Array.isArray(src) && Array.isArray(dst)) {
		src.forEach((s) => {
			if (!dst.includes(s)) dst.push(s);
		});
		return dst;
	}
	if (dst === void 0 || depth <= 0) if (dst !== void 0 && dst !== null && typeof dst === "object" && typeof src === "object") return Object.assign(dst, src);
	else return src;
	if (src !== void 0 && typeof dst === "object" && typeof src === "object") Object.keys(src).forEach((key) => {
		if (typeof src[key] === "object" && src[key] !== null && (dst[key] === void 0 || typeof dst[key] === "object")) {
			if (dst[key] === void 0) dst[key] = Array.isArray(src[key]) ? [] : {};
			dst[key] = assignWithDepth(dst[key], src[key], {
				depth: depth - 1,
				clobber
			});
		} else if (clobber || typeof dst[key] !== "object" && typeof src[key] !== "object") dst[key] = src[key];
	});
	return dst;
}, "assignWithDepth");
var assignWithDepth_default = assignWithDepth;
var oldAttributeBackgroundColorOdd = "#ffffff";
var oldAttributeBackgroundColorEven = "#f2f2f2";
var mkBorder = /* @__PURE__ */ __name((col, darkMode) => darkMode ? adjust(col, {
	s: -40,
	l: 10
}) : adjust(col, {
	s: -40,
	l: -10
}), "mkBorder");
var Theme = class {
	static {
		__name(this, "Theme");
	}
	constructor() {
		this.background = "#f4f4f4";
		this.primaryColor = "#fff4dd";
		this.noteBkgColor = "#fff5ad";
		this.noteTextColor = "#333";
		this.THEME_COLOR_LIMIT = 12;
		this.radius = 5;
		this.strokeWidth = 1;
		this.fontFamily = "\"trebuchet ms\", verdana, arial, sans-serif";
		this.fontSize = "16px";
		this.useGradient = true;
		this.dropShadow = "drop-shadow( 1px 2px 2px rgba(185,185,185,1))";
	}
	updateColors() {
		this.primaryTextColor = this.primaryTextColor || (this.darkMode ? "#eee" : "#333");
		this.secondaryColor = this.secondaryColor || adjust(this.primaryColor, { h: -120 });
		this.tertiaryColor = this.tertiaryColor || adjust(this.primaryColor, {
			h: 180,
			l: 5
		});
		this.primaryBorderColor = this.primaryBorderColor || mkBorder(this.primaryColor, this.darkMode);
		this.secondaryBorderColor = this.secondaryBorderColor || mkBorder(this.secondaryColor, this.darkMode);
		this.tertiaryBorderColor = this.tertiaryBorderColor || mkBorder(this.tertiaryColor, this.darkMode);
		this.noteBorderColor = this.noteBorderColor || mkBorder(this.noteBkgColor, this.darkMode);
		this.noteBkgColor = this.noteBkgColor || "#fff5ad";
		this.noteTextColor = this.noteTextColor || "#333";
		this.secondaryTextColor = this.secondaryTextColor || invert(this.secondaryColor);
		this.tertiaryTextColor = this.tertiaryTextColor || invert(this.tertiaryColor);
		this.lineColor = this.lineColor || invert(this.background);
		this.arrowheadColor = this.arrowheadColor || invert(this.background);
		this.textColor = this.textColor || this.primaryTextColor;
		this.border2 = this.border2 || this.tertiaryBorderColor;
		this.nodeBkg = this.nodeBkg || this.primaryColor;
		this.mainBkg = this.mainBkg || this.primaryColor;
		this.nodeBorder = this.nodeBorder || this.primaryBorderColor;
		this.clusterBkg = this.clusterBkg || this.tertiaryColor;
		this.clusterBorder = this.clusterBorder || this.tertiaryBorderColor;
		this.defaultLinkColor = this.defaultLinkColor || this.lineColor;
		this.titleColor = this.titleColor || this.tertiaryTextColor;
		this.edgeLabelBackground = this.edgeLabelBackground || (this.darkMode ? darken(this.secondaryColor, 30) : this.secondaryColor);
		this.nodeTextColor = this.nodeTextColor || this.primaryTextColor;
		this.actorBorder = this.actorBorder || this.primaryBorderColor;
		this.actorBkg = this.actorBkg || this.mainBkg;
		this.actorTextColor = this.actorTextColor || this.primaryTextColor;
		this.actorLineColor = this.actorLineColor || this.actorBorder;
		this.labelBoxBkgColor = this.labelBoxBkgColor || this.actorBkg;
		this.signalColor = this.signalColor || this.textColor;
		this.signalTextColor = this.signalTextColor || this.textColor;
		this.labelBoxBorderColor = this.labelBoxBorderColor || this.actorBorder;
		this.labelTextColor = this.labelTextColor || this.actorTextColor;
		this.loopTextColor = this.loopTextColor || this.actorTextColor;
		this.activationBorderColor = this.activationBorderColor || darken(this.secondaryColor, 10);
		this.activationBkgColor = this.activationBkgColor || this.secondaryColor;
		this.sequenceNumberColor = this.sequenceNumberColor || invert(this.lineColor);
		this.sectionBkgColor = this.sectionBkgColor || this.tertiaryColor;
		this.altSectionBkgColor = this.altSectionBkgColor || "white";
		this.sectionBkgColor = this.sectionBkgColor || this.secondaryColor;
		this.sectionBkgColor2 = this.sectionBkgColor2 || this.primaryColor;
		this.excludeBkgColor = this.excludeBkgColor || "#eeeeee";
		this.taskBorderColor = this.taskBorderColor || this.primaryBorderColor;
		this.taskBkgColor = this.taskBkgColor || this.primaryColor;
		this.activeTaskBorderColor = this.activeTaskBorderColor || this.primaryColor;
		this.activeTaskBkgColor = this.activeTaskBkgColor || lighten(this.primaryColor, 23);
		this.gridColor = this.gridColor || "lightgrey";
		this.doneTaskBkgColor = this.doneTaskBkgColor || "lightgrey";
		this.doneTaskBorderColor = this.doneTaskBorderColor || "grey";
		this.critBorderColor = this.critBorderColor || "#ff8888";
		this.critBkgColor = this.critBkgColor || "red";
		this.todayLineColor = this.todayLineColor || "red";
		this.vertLineColor = this.vertLineColor || "navy";
		this.taskTextColor = this.taskTextColor || this.textColor;
		this.taskTextOutsideColor = this.taskTextOutsideColor || this.textColor;
		this.taskTextLightColor = this.taskTextLightColor || this.textColor;
		this.taskTextColor = this.taskTextColor || this.primaryTextColor;
		this.taskTextDarkColor = this.taskTextDarkColor || this.textColor;
		this.taskTextClickableColor = this.taskTextClickableColor || "#003163";
		this.noteFontWeight = this.noteFontWeight || "normal";
		this.fontWeight = this.fontWeight || "normal";
		this.personBorder = this.personBorder || this.primaryBorderColor;
		this.personBkg = this.personBkg || this.mainBkg;
		if (this.darkMode) {
			this.rowOdd = this.rowOdd || darken(this.mainBkg, 5) || "#ffffff";
			this.rowEven = this.rowEven || darken(this.mainBkg, 10);
		} else {
			this.rowOdd = this.rowOdd || lighten(this.mainBkg, 75) || "#ffffff";
			this.rowEven = this.rowEven || lighten(this.mainBkg, 5);
		}
		this.transitionColor = this.transitionColor || this.lineColor;
		this.transitionLabelColor = this.transitionLabelColor || this.textColor;
		this.stateLabelColor = this.stateLabelColor || this.stateBkg || this.primaryTextColor;
		this.stateBkg = this.stateBkg || this.mainBkg;
		this.labelBackgroundColor = this.labelBackgroundColor || this.stateBkg;
		this.compositeBackground = this.compositeBackground || this.background || this.tertiaryColor;
		this.altBackground = this.altBackground || this.tertiaryColor;
		this.compositeTitleBackground = this.compositeTitleBackground || this.mainBkg;
		this.compositeBorder = this.compositeBorder || this.nodeBorder;
		this.innerEndBackground = this.nodeBorder;
		this.errorBkgColor = this.errorBkgColor || this.tertiaryColor;
		this.errorTextColor = this.errorTextColor || this.tertiaryTextColor;
		this.transitionColor = this.transitionColor || this.lineColor;
		this.specialStateColor = this.lineColor;
		this.cScale0 = this.cScale0 || this.primaryColor;
		this.cScale1 = this.cScale1 || this.secondaryColor;
		this.cScale2 = this.cScale2 || this.tertiaryColor;
		this.cScale3 = this.cScale3 || adjust(this.primaryColor, { h: 30 });
		this.cScale4 = this.cScale4 || adjust(this.primaryColor, { h: 60 });
		this.cScale5 = this.cScale5 || adjust(this.primaryColor, { h: 90 });
		this.cScale6 = this.cScale6 || adjust(this.primaryColor, { h: 120 });
		this.cScale7 = this.cScale7 || adjust(this.primaryColor, { h: 150 });
		this.cScale8 = this.cScale8 || adjust(this.primaryColor, {
			h: 210,
			l: 150
		});
		this.cScale9 = this.cScale9 || adjust(this.primaryColor, { h: 270 });
		this.cScale10 = this.cScale10 || adjust(this.primaryColor, { h: 300 });
		this.cScale11 = this.cScale11 || adjust(this.primaryColor, { h: 330 });
		if (this.darkMode) for (let i = 0; i < this.THEME_COLOR_LIMIT; i++) this["cScale" + i] = darken(this["cScale" + i], 75);
		else for (let i = 0; i < this.THEME_COLOR_LIMIT; i++) this["cScale" + i] = darken(this["cScale" + i], 25);
		for (let i = 0; i < this.THEME_COLOR_LIMIT; i++) this["cScaleInv" + i] = this["cScaleInv" + i] || invert(this["cScale" + i]);
		for (let i = 0; i < this.THEME_COLOR_LIMIT; i++) if (this.darkMode) this["cScalePeer" + i] = this["cScalePeer" + i] || lighten(this["cScale" + i], 10);
		else this["cScalePeer" + i] = this["cScalePeer" + i] || darken(this["cScale" + i], 10);
		this.scaleLabelColor = this.scaleLabelColor || this.labelTextColor;
		for (let i = 0; i < this.THEME_COLOR_LIMIT; i++) this["cScaleLabel" + i] = this["cScaleLabel" + i] || this.scaleLabelColor;
		const multiplier = this.darkMode ? -4 : -1;
		for (let i = 0; i < 5; i++) {
			this["surface" + i] = this["surface" + i] || adjust(this.mainBkg, {
				h: 180,
				s: -15,
				l: multiplier * (5 + i * 3)
			});
			this["surfacePeer" + i] = this["surfacePeer" + i] || adjust(this.mainBkg, {
				h: 180,
				s: -15,
				l: multiplier * (8 + i * 3)
			});
		}
		this.classText = this.classText || this.textColor;
		this.fillType0 = this.fillType0 || this.primaryColor;
		this.fillType1 = this.fillType1 || this.secondaryColor;
		this.fillType2 = this.fillType2 || adjust(this.primaryColor, { h: 64 });
		this.fillType3 = this.fillType3 || adjust(this.secondaryColor, { h: 64 });
		this.fillType4 = this.fillType4 || adjust(this.primaryColor, { h: -64 });
		this.fillType5 = this.fillType5 || adjust(this.secondaryColor, { h: -64 });
		this.fillType6 = this.fillType6 || adjust(this.primaryColor, { h: 128 });
		this.fillType7 = this.fillType7 || adjust(this.secondaryColor, { h: 128 });
		this.pie1 = this.pie1 || this.primaryColor;
		this.pie2 = this.pie2 || this.secondaryColor;
		this.pie3 = this.pie3 || this.tertiaryColor;
		this.pie4 = this.pie4 || adjust(this.primaryColor, { l: -10 });
		this.pie5 = this.pie5 || adjust(this.secondaryColor, { l: -10 });
		this.pie6 = this.pie6 || adjust(this.tertiaryColor, { l: -10 });
		this.pie7 = this.pie7 || adjust(this.primaryColor, {
			h: 60,
			l: -10
		});
		this.pie8 = this.pie8 || adjust(this.primaryColor, {
			h: -60,
			l: -10
		});
		this.pie9 = this.pie9 || adjust(this.primaryColor, {
			h: 120,
			l: 0
		});
		this.pie10 = this.pie10 || adjust(this.primaryColor, {
			h: 60,
			l: -20
		});
		this.pie11 = this.pie11 || adjust(this.primaryColor, {
			h: -60,
			l: -20
		});
		this.pie12 = this.pie12 || adjust(this.primaryColor, {
			h: 120,
			l: -10
		});
		this.pieTitleTextSize = this.pieTitleTextSize || "25px";
		this.pieTitleTextColor = this.pieTitleTextColor || this.taskTextDarkColor;
		this.pieSectionTextSize = this.pieSectionTextSize || "17px";
		this.pieSectionTextColor = this.pieSectionTextColor || this.textColor;
		this.pieLegendTextSize = this.pieLegendTextSize || "17px";
		this.pieLegendTextColor = this.pieLegendTextColor || this.taskTextDarkColor;
		this.pieStrokeColor = this.pieStrokeColor || "black";
		this.pieStrokeWidth = this.pieStrokeWidth || "2px";
		this.pieOuterStrokeWidth = this.pieOuterStrokeWidth || "2px";
		this.pieOuterStrokeColor = this.pieOuterStrokeColor || "black";
		this.pieOpacity = this.pieOpacity || "0.7";
		this.venn1 = this.venn1 ?? adjust(this.primaryColor, { l: -30 });
		this.venn2 = this.venn2 ?? adjust(this.secondaryColor, { l: -30 });
		this.venn3 = this.venn3 ?? adjust(this.tertiaryColor, { l: -30 });
		this.venn4 = this.venn4 ?? adjust(this.primaryColor, {
			h: 60,
			l: -30
		});
		this.venn5 = this.venn5 ?? adjust(this.primaryColor, {
			h: -60,
			l: -30
		});
		this.venn6 = this.venn6 ?? adjust(this.secondaryColor, {
			h: 60,
			l: -30
		});
		this.venn7 = this.venn7 ?? adjust(this.primaryColor, {
			h: 120,
			l: -30
		});
		this.venn8 = this.venn8 ?? adjust(this.secondaryColor, {
			h: 120,
			l: -30
		});
		this.vennTitleTextColor = this.vennTitleTextColor ?? this.titleColor;
		this.vennSetTextColor = this.vennSetTextColor ?? this.textColor;
		this.radar = {
			axisColor: this.radar?.axisColor || this.lineColor,
			axisStrokeWidth: this.radar?.axisStrokeWidth || 2,
			axisLabelFontSize: this.radar?.axisLabelFontSize || 12,
			curveOpacity: this.radar?.curveOpacity || .5,
			curveStrokeWidth: this.radar?.curveStrokeWidth || 2,
			graticuleColor: this.radar?.graticuleColor || "#DEDEDE",
			graticuleStrokeWidth: this.radar?.graticuleStrokeWidth || 1,
			graticuleOpacity: this.radar?.graticuleOpacity || .3,
			legendBoxSize: this.radar?.legendBoxSize || 12,
			legendFontSize: this.radar?.legendFontSize || 12
		};
		this.wardleyEvolutionColor = this.wardleyEvolutionColor || "#dc3545";
		this.wardley = {
			backgroundColor: this.wardley?.backgroundColor || this.background,
			axisColor: this.wardley?.axisColor || this.lineColor,
			axisTextColor: this.wardley?.axisTextColor || this.primaryTextColor,
			gridColor: this.wardley?.gridColor || this.gridColor,
			componentFill: this.wardley?.componentFill || this.background,
			componentStroke: this.wardley?.componentStroke || this.lineColor,
			componentLabelColor: this.wardley?.componentLabelColor || this.primaryTextColor,
			linkStroke: this.wardley?.linkStroke || this.lineColor,
			evolutionStroke: this.wardley?.evolutionStroke || this.wardleyEvolutionColor,
			annotationStroke: this.wardley?.annotationStroke || this.lineColor,
			annotationTextColor: this.wardley?.annotationTextColor || this.primaryTextColor,
			annotationFill: this.wardley?.annotationFill || this.background
		};
		this.archEdgeColor = this.archEdgeColor || "#777";
		this.archEdgeArrowColor = this.archEdgeArrowColor || "#777";
		this.archEdgeWidth = this.archEdgeWidth || "3";
		this.archGroupBorderColor = this.archGroupBorderColor || "#000";
		this.archGroupBorderWidth = this.archGroupBorderWidth || "2px";
		this.quadrant1Fill = this.quadrant1Fill || this.primaryColor;
		this.quadrant2Fill = this.quadrant2Fill || adjust(this.primaryColor, {
			r: 5,
			g: 5,
			b: 5
		});
		this.quadrant3Fill = this.quadrant3Fill || adjust(this.primaryColor, {
			r: 10,
			g: 10,
			b: 10
		});
		this.quadrant4Fill = this.quadrant4Fill || adjust(this.primaryColor, {
			r: 15,
			g: 15,
			b: 15
		});
		this.quadrant1TextFill = this.quadrant1TextFill || this.primaryTextColor;
		this.quadrant2TextFill = this.quadrant2TextFill || adjust(this.primaryTextColor, {
			r: -5,
			g: -5,
			b: -5
		});
		this.quadrant3TextFill = this.quadrant3TextFill || adjust(this.primaryTextColor, {
			r: -10,
			g: -10,
			b: -10
		});
		this.quadrant4TextFill = this.quadrant4TextFill || adjust(this.primaryTextColor, {
			r: -15,
			g: -15,
			b: -15
		});
		this.quadrantPointFill = this.quadrantPointFill || isDark(this.quadrant1Fill) ? lighten(this.quadrant1Fill) : darken(this.quadrant1Fill);
		this.quadrantPointTextFill = this.quadrantPointTextFill || this.primaryTextColor;
		this.quadrantXAxisTextFill = this.quadrantXAxisTextFill || this.primaryTextColor;
		this.quadrantYAxisTextFill = this.quadrantYAxisTextFill || this.primaryTextColor;
		this.quadrantInternalBorderStrokeFill = this.quadrantInternalBorderStrokeFill || this.primaryBorderColor;
		this.quadrantExternalBorderStrokeFill = this.quadrantExternalBorderStrokeFill || this.primaryBorderColor;
		this.quadrantTitleFill = this.quadrantTitleFill || this.primaryTextColor;
		this.xyChart = {
			backgroundColor: this.xyChart?.backgroundColor || this.background,
			titleColor: this.xyChart?.titleColor || this.primaryTextColor,
			dataLabelColor: this.xyChart?.dataLabelColor || this.primaryTextColor,
			xAxisTitleColor: this.xyChart?.xAxisTitleColor || this.primaryTextColor,
			xAxisLabelColor: this.xyChart?.xAxisLabelColor || this.primaryTextColor,
			xAxisTickColor: this.xyChart?.xAxisTickColor || this.primaryTextColor,
			xAxisLineColor: this.xyChart?.xAxisLineColor || this.primaryTextColor,
			yAxisTitleColor: this.xyChart?.yAxisTitleColor || this.primaryTextColor,
			yAxisLabelColor: this.xyChart?.yAxisLabelColor || this.primaryTextColor,
			yAxisTickColor: this.xyChart?.yAxisTickColor || this.primaryTextColor,
			yAxisLineColor: this.xyChart?.yAxisLineColor || this.primaryTextColor,
			plotColorPalette: this.xyChart?.plotColorPalette || "#FFF4DD,#FFD8B1,#FFA07A,#ECEFF1,#D6DBDF,#C3E0A8,#FFB6A4,#FFD74D,#738FA7,#FFFFF0"
		};
		this.requirementBackground = this.requirementBackground || this.primaryColor;
		this.requirementBorderColor = this.requirementBorderColor || this.primaryBorderColor;
		this.requirementBorderSize = this.requirementBorderSize || "1";
		this.requirementTextColor = this.requirementTextColor || this.primaryTextColor;
		this.relationColor = this.relationColor || this.lineColor;
		this.relationLabelBackground = this.relationLabelBackground || (this.darkMode ? darken(this.secondaryColor, 30) : this.secondaryColor);
		this.relationLabelColor = this.relationLabelColor || this.actorTextColor;
		this.git0 = this.git0 || this.primaryColor;
		this.git1 = this.git1 || this.secondaryColor;
		this.git2 = this.git2 || this.tertiaryColor;
		this.git3 = this.git3 || adjust(this.primaryColor, { h: -30 });
		this.git4 = this.git4 || adjust(this.primaryColor, { h: -60 });
		this.git5 = this.git5 || adjust(this.primaryColor, { h: -90 });
		this.git6 = this.git6 || adjust(this.primaryColor, { h: 60 });
		this.git7 = this.git7 || adjust(this.primaryColor, { h: 120 });
		if (this.darkMode) {
			this.git0 = lighten(this.git0, 25);
			this.git1 = lighten(this.git1, 25);
			this.git2 = lighten(this.git2, 25);
			this.git3 = lighten(this.git3, 25);
			this.git4 = lighten(this.git4, 25);
			this.git5 = lighten(this.git5, 25);
			this.git6 = lighten(this.git6, 25);
			this.git7 = lighten(this.git7, 25);
		} else {
			this.git0 = darken(this.git0, 25);
			this.git1 = darken(this.git1, 25);
			this.git2 = darken(this.git2, 25);
			this.git3 = darken(this.git3, 25);
			this.git4 = darken(this.git4, 25);
			this.git5 = darken(this.git5, 25);
			this.git6 = darken(this.git6, 25);
			this.git7 = darken(this.git7, 25);
		}
		this.gitInv0 = this.gitInv0 || invert(this.git0);
		this.gitInv1 = this.gitInv1 || invert(this.git1);
		this.gitInv2 = this.gitInv2 || invert(this.git2);
		this.gitInv3 = this.gitInv3 || invert(this.git3);
		this.gitInv4 = this.gitInv4 || invert(this.git4);
		this.gitInv5 = this.gitInv5 || invert(this.git5);
		this.gitInv6 = this.gitInv6 || invert(this.git6);
		this.gitInv7 = this.gitInv7 || invert(this.git7);
		this.branchLabelColor = this.branchLabelColor || (this.darkMode ? "black" : this.labelTextColor);
		this.gitBranchLabel0 = this.gitBranchLabel0 || this.branchLabelColor;
		this.gitBranchLabel1 = this.gitBranchLabel1 || this.branchLabelColor;
		this.gitBranchLabel2 = this.gitBranchLabel2 || this.branchLabelColor;
		this.gitBranchLabel3 = this.gitBranchLabel3 || this.branchLabelColor;
		this.gitBranchLabel4 = this.gitBranchLabel4 || this.branchLabelColor;
		this.gitBranchLabel5 = this.gitBranchLabel5 || this.branchLabelColor;
		this.gitBranchLabel6 = this.gitBranchLabel6 || this.branchLabelColor;
		this.gitBranchLabel7 = this.gitBranchLabel7 || this.branchLabelColor;
		this.tagLabelColor = this.tagLabelColor || this.primaryTextColor;
		this.tagLabelBackground = this.tagLabelBackground || this.primaryColor;
		this.tagLabelBorder = this.tagBorder || this.primaryBorderColor;
		this.tagLabelFontSize = this.tagLabelFontSize || "10px";
		this.commitLabelColor = this.commitLabelColor || this.secondaryTextColor;
		this.commitLabelBackground = this.commitLabelBackground || this.secondaryColor;
		this.commitLabelFontSize = this.commitLabelFontSize || "10px";
		this.emUiFill = this.emUiFill || "white";
		this.emUiStroke = this.emUiStroke || "#dbdada";
		this.emProcessorFill = this.emProcessorFill || "#edb3f6";
		this.emProcessorStroke = this.emProcessorStroke || "#b88cbf";
		this.emReadModelFill = this.emReadModelFill || "#d3f1a2";
		this.emReadModelStroke = this.emReadModelStroke || "#a3b732";
		this.emCommandFill = this.emCommandFill || "#bcd6fe";
		this.emCommandStroke = this.emCommandStroke || "#679ac3";
		this.emEventFill = this.emEventFill || "#ffb778";
		this.emEventStroke = this.emEventStroke || "#c19a0f";
		this.emSwimlaneBackgroundOdd = this.emSwimlaneBackgroundOdd || "rgb(250,250,250)";
		this.emSwimlaneBackgroundStroke = this.emSwimlaneBackgroundStroke || "rgb(240,240,240)";
		this.emArrowhead = this.emArrowhead || this.lineColor;
		this.emRelationStroke = this.emRelationStroke || this.lineColor;
		this.attributeBackgroundColorOdd = this.attributeBackgroundColorOdd || oldAttributeBackgroundColorOdd;
		this.attributeBackgroundColorEven = this.attributeBackgroundColorEven || oldAttributeBackgroundColorEven;
		this.gradientStart = this.primaryBorderColor;
		this.gradientStop = this.secondaryBorderColor;
	}
	calculate(overrides) {
		if (typeof overrides !== "object") {
			this.updateColors();
			return;
		}
		const keys = Object.keys(overrides);
		keys.forEach((k) => {
			this[k] = overrides[k];
		});
		this.updateColors();
		keys.forEach((k) => {
			this[k] = overrides[k];
		});
	}
};
var getThemeVariables = /* @__PURE__ */ __name((userOverrides) => {
	const theme = new Theme();
	theme.calculate(userOverrides);
	return theme;
}, "getThemeVariables");
var Theme2 = class {
	static {
		__name(this, "Theme");
	}
	constructor() {
		this.background = "#333";
		this.primaryColor = "#1f2020";
		this.secondaryColor = lighten(this.primaryColor, 16);
		this.tertiaryColor = adjust(this.primaryColor, { h: -160 });
		this.primaryBorderColor = invert(this.background);
		this.secondaryBorderColor = mkBorder(this.secondaryColor, this.darkMode);
		this.tertiaryBorderColor = mkBorder(this.tertiaryColor, this.darkMode);
		this.primaryTextColor = invert(this.primaryColor);
		this.secondaryTextColor = invert(this.secondaryColor);
		this.tertiaryTextColor = invert(this.tertiaryColor);
		this.lineColor = invert(this.background);
		this.textColor = invert(this.background);
		this.mainBkg = "#1f2020";
		this.secondBkg = "calculated";
		this.mainContrastColor = "lightgrey";
		this.darkTextColor = lighten(invert("#323D47"), 10);
		this.lineColor = "calculated";
		this.border1 = "#ccc";
		this.border2 = rgba(255, 255, 255, .25);
		this.arrowheadColor = "calculated";
		this.fontFamily = "\"trebuchet ms\", verdana, arial, sans-serif";
		this.fontSize = "16px";
		this.labelBackground = "#181818";
		this.textColor = "#ccc";
		this.THEME_COLOR_LIMIT = 12;
		this.radius = 5;
		this.strokeWidth = 1;
		this.nodeBkg = "calculated";
		this.nodeBorder = "calculated";
		this.clusterBkg = "calculated";
		this.clusterBorder = "calculated";
		this.defaultLinkColor = "calculated";
		this.titleColor = "#F9FFFE";
		this.edgeLabelBackground = "calculated";
		this.actorBorder = "calculated";
		this.actorBkg = "calculated";
		this.actorTextColor = "calculated";
		this.actorLineColor = "calculated";
		this.signalColor = "calculated";
		this.signalTextColor = "calculated";
		this.labelBoxBkgColor = "calculated";
		this.labelBoxBorderColor = "calculated";
		this.labelTextColor = "calculated";
		this.loopTextColor = "calculated";
		this.noteBorderColor = "calculated";
		this.noteBkgColor = "#fff5ad";
		this.noteTextColor = "calculated";
		this.activationBorderColor = "calculated";
		this.activationBkgColor = "calculated";
		this.sequenceNumberColor = "black";
		this.clusterBkg = "#302F3D";
		this.sectionBkgColor = darken("#EAE8D9", 30);
		this.altSectionBkgColor = "calculated";
		this.sectionBkgColor2 = "#EAE8D9";
		this.excludeBkgColor = darken(this.sectionBkgColor, 10);
		this.taskBorderColor = rgba(255, 255, 255, 70);
		this.taskBkgColor = "calculated";
		this.taskTextColor = "calculated";
		this.taskTextLightColor = "calculated";
		this.taskTextOutsideColor = "calculated";
		this.taskTextClickableColor = "#003163";
		this.activeTaskBorderColor = rgba(255, 255, 255, 50);
		this.activeTaskBkgColor = "#81B1DB";
		this.gridColor = "calculated";
		this.doneTaskBkgColor = "calculated";
		this.doneTaskBorderColor = "grey";
		this.critBorderColor = "#E83737";
		this.critBkgColor = "#E83737";
		this.taskTextDarkColor = "calculated";
		this.todayLineColor = "#DB5757";
		this.vertLineColor = "#00BFFF";
		this.personBorder = this.primaryBorderColor;
		this.personBkg = this.mainBkg;
		this.archEdgeColor = "calculated";
		this.archEdgeArrowColor = "calculated";
		this.archEdgeWidth = "3";
		this.archGroupBorderColor = this.primaryBorderColor;
		this.archGroupBorderWidth = "2px";
		this.rowOdd = this.rowOdd || lighten(this.mainBkg, 5) || "#ffffff";
		this.rowEven = this.rowEven || darken(this.mainBkg, 10);
		this.labelColor = "calculated";
		this.errorBkgColor = "#a44141";
		this.errorTextColor = "#ddd";
		this.useGradient = true;
		this.gradientStart = this.primaryBorderColor;
		this.gradientStop = this.secondaryBorderColor;
		this.dropShadow = "drop-shadow( 1px 2px 2px rgba(185,185,185,1))";
		this.noteFontWeight = this.noteFontWeight || "normal";
		this.fontWeight = this.fontWeight || "normal";
	}
	updateColors() {
		this.secondBkg = lighten(this.mainBkg, 16);
		this.lineColor = this.mainContrastColor;
		this.arrowheadColor = this.mainContrastColor;
		this.nodeBkg = this.mainBkg;
		this.nodeBorder = this.border1;
		this.clusterBkg = this.secondBkg;
		this.clusterBorder = this.border2;
		this.defaultLinkColor = this.lineColor;
		this.edgeLabelBackground = lighten(this.labelBackground, 25);
		this.actorBorder = this.border1;
		this.actorBkg = this.mainBkg;
		this.actorTextColor = this.mainContrastColor;
		this.actorLineColor = this.actorBorder;
		this.signalColor = this.mainContrastColor;
		this.signalTextColor = this.mainContrastColor;
		this.labelBoxBkgColor = this.actorBkg;
		this.labelBoxBorderColor = this.actorBorder;
		this.labelTextColor = this.mainContrastColor;
		this.loopTextColor = this.mainContrastColor;
		this.noteBorderColor = this.secondaryBorderColor;
		this.noteBkgColor = this.secondBkg;
		this.noteTextColor = this.secondaryTextColor;
		this.activationBorderColor = this.border1;
		this.activationBkgColor = this.secondBkg;
		this.altSectionBkgColor = this.background;
		this.taskBkgColor = lighten(this.mainBkg, 23);
		this.taskTextColor = this.darkTextColor;
		this.taskTextLightColor = this.mainContrastColor;
		this.taskTextOutsideColor = this.taskTextLightColor;
		this.gridColor = this.mainContrastColor;
		this.doneTaskBkgColor = this.mainContrastColor;
		this.taskTextDarkColor = invert(this.doneTaskBkgColor);
		this.archEdgeColor = this.lineColor;
		this.archEdgeArrowColor = this.lineColor;
		this.transitionColor = this.transitionColor || this.lineColor;
		this.transitionLabelColor = this.transitionLabelColor || this.textColor;
		this.stateLabelColor = this.stateLabelColor || this.stateBkg || this.primaryTextColor;
		this.stateBkg = this.stateBkg || this.mainBkg;
		this.labelBackgroundColor = this.labelBackgroundColor || this.stateBkg;
		this.compositeBackground = this.compositeBackground || this.background || this.tertiaryColor;
		this.altBackground = this.altBackground || "#555";
		this.compositeTitleBackground = this.compositeTitleBackground || this.mainBkg;
		this.compositeBorder = this.compositeBorder || this.nodeBorder;
		this.innerEndBackground = this.primaryBorderColor;
		this.specialStateColor = "#f4f4f4";
		this.errorBkgColor = this.errorBkgColor || this.tertiaryColor;
		this.errorTextColor = this.errorTextColor || this.tertiaryTextColor;
		this.fillType0 = this.primaryColor;
		this.fillType1 = this.secondaryColor;
		this.fillType2 = adjust(this.primaryColor, { h: 64 });
		this.fillType3 = adjust(this.secondaryColor, { h: 64 });
		this.fillType4 = adjust(this.primaryColor, { h: -64 });
		this.fillType5 = adjust(this.secondaryColor, { h: -64 });
		this.fillType6 = adjust(this.primaryColor, { h: 128 });
		this.fillType7 = adjust(this.secondaryColor, { h: 128 });
		this.cScale1 = this.cScale1 || "#0b0000";
		this.cScale2 = this.cScale2 || "#4d1037";
		this.cScale3 = this.cScale3 || "#3f5258";
		this.cScale4 = this.cScale4 || "#4f2f1b";
		this.cScale5 = this.cScale5 || "#6e0a0a";
		this.cScale6 = this.cScale6 || "#3b0048";
		this.cScale7 = this.cScale7 || "#995a01";
		this.cScale8 = this.cScale8 || "#154706";
		this.cScale9 = this.cScale9 || "#161722";
		this.cScale10 = this.cScale10 || "#00296f";
		this.cScale11 = this.cScale11 || "#01629c";
		this.cScale12 = this.cScale12 || "#010029";
		this.cScale0 = this.cScale0 || this.primaryColor;
		this.cScale1 = this.cScale1 || this.secondaryColor;
		this.cScale2 = this.cScale2 || this.tertiaryColor;
		this.cScale3 = this.cScale3 || adjust(this.primaryColor, { h: 30 });
		this.cScale4 = this.cScale4 || adjust(this.primaryColor, { h: 60 });
		this.cScale5 = this.cScale5 || adjust(this.primaryColor, { h: 90 });
		this.cScale6 = this.cScale6 || adjust(this.primaryColor, { h: 120 });
		this.cScale7 = this.cScale7 || adjust(this.primaryColor, { h: 150 });
		this.cScale8 = this.cScale8 || adjust(this.primaryColor, { h: 210 });
		this.cScale9 = this.cScale9 || adjust(this.primaryColor, { h: 270 });
		this.cScale10 = this.cScale10 || adjust(this.primaryColor, { h: 300 });
		this.cScale11 = this.cScale11 || adjust(this.primaryColor, { h: 330 });
		for (let i = 0; i < this.THEME_COLOR_LIMIT; i++) this["cScaleInv" + i] = this["cScaleInv" + i] || invert(this["cScale" + i]);
		for (let i = 0; i < this.THEME_COLOR_LIMIT; i++) this["cScalePeer" + i] = this["cScalePeer" + i] || lighten(this["cScale" + i], 10);
		for (let i = 0; i < 5; i++) {
			this["surface" + i] = this["surface" + i] || adjust(this.mainBkg, {
				h: 30,
				s: -30,
				l: -(-10 + i * 4)
			});
			this["surfacePeer" + i] = this["surfacePeer" + i] || adjust(this.mainBkg, {
				h: 30,
				s: -30,
				l: -(-7 + i * 4)
			});
		}
		this.scaleLabelColor = this.scaleLabelColor || (this.darkMode ? "black" : this.labelTextColor);
		for (let i = 0; i < this.THEME_COLOR_LIMIT; i++) this["cScaleLabel" + i] = this["cScaleLabel" + i] || this.scaleLabelColor;
		for (let i = 0; i < this.THEME_COLOR_LIMIT; i++) this["pie" + i] = this["cScale" + i];
		this.pieTitleTextSize = this.pieTitleTextSize || "25px";
		this.pieTitleTextColor = this.pieTitleTextColor || this.mainContrastColor;
		this.pieSectionTextSize = this.pieSectionTextSize || "17px";
		this.pieSectionTextColor = this.pieSectionTextColor || this.textColor;
		this.pieLegendTextSize = this.pieLegendTextSize || "17px";
		this.pieLegendTextColor = this.pieLegendTextColor || this.mainContrastColor;
		this.pieStrokeColor = this.pieStrokeColor || "black";
		this.pieStrokeWidth = this.pieStrokeWidth || "2px";
		this.pieOuterStrokeWidth = this.pieOuterStrokeWidth || "2px";
		this.pieOuterStrokeColor = this.pieOuterStrokeColor || "black";
		this.pieOpacity = this.pieOpacity || "0.7";
		for (let i = 0; i < 8; i++) this["venn" + (i + 1)] = this["venn" + (i + 1)] ?? lighten(this["cScale" + i], 30);
		this.vennTitleTextColor = this.vennTitleTextColor ?? this.titleColor;
		this.vennSetTextColor = this.vennSetTextColor ?? this.textColor;
		this.quadrant1Fill = this.quadrant1Fill || this.primaryColor;
		this.quadrant2Fill = this.quadrant2Fill || adjust(this.primaryColor, {
			r: 5,
			g: 5,
			b: 5
		});
		this.quadrant3Fill = this.quadrant3Fill || adjust(this.primaryColor, {
			r: 10,
			g: 10,
			b: 10
		});
		this.quadrant4Fill = this.quadrant4Fill || adjust(this.primaryColor, {
			r: 15,
			g: 15,
			b: 15
		});
		this.quadrant1TextFill = this.quadrant1TextFill || this.primaryTextColor;
		this.quadrant2TextFill = this.quadrant2TextFill || adjust(this.primaryTextColor, {
			r: -5,
			g: -5,
			b: -5
		});
		this.quadrant3TextFill = this.quadrant3TextFill || adjust(this.primaryTextColor, {
			r: -10,
			g: -10,
			b: -10
		});
		this.quadrant4TextFill = this.quadrant4TextFill || adjust(this.primaryTextColor, {
			r: -15,
			g: -15,
			b: -15
		});
		this.quadrantPointFill = this.quadrantPointFill || isDark(this.quadrant1Fill) ? lighten(this.quadrant1Fill) : darken(this.quadrant1Fill);
		this.quadrantPointTextFill = this.quadrantPointTextFill || this.primaryTextColor;
		this.quadrantXAxisTextFill = this.quadrantXAxisTextFill || this.primaryTextColor;
		this.quadrantYAxisTextFill = this.quadrantYAxisTextFill || this.primaryTextColor;
		this.quadrantInternalBorderStrokeFill = this.quadrantInternalBorderStrokeFill || this.primaryBorderColor;
		this.quadrantExternalBorderStrokeFill = this.quadrantExternalBorderStrokeFill || this.primaryBorderColor;
		this.quadrantTitleFill = this.quadrantTitleFill || this.primaryTextColor;
		this.xyChart = {
			backgroundColor: this.xyChart?.backgroundColor || this.background,
			titleColor: this.xyChart?.titleColor || this.primaryTextColor,
			dataLabelColor: this.xyChart?.dataLabelColor || this.primaryTextColor,
			xAxisTitleColor: this.xyChart?.xAxisTitleColor || this.primaryTextColor,
			xAxisLabelColor: this.xyChart?.xAxisLabelColor || this.primaryTextColor,
			xAxisTickColor: this.xyChart?.xAxisTickColor || this.primaryTextColor,
			xAxisLineColor: this.xyChart?.xAxisLineColor || this.primaryTextColor,
			yAxisTitleColor: this.xyChart?.yAxisTitleColor || this.primaryTextColor,
			yAxisLabelColor: this.xyChart?.yAxisLabelColor || this.primaryTextColor,
			yAxisTickColor: this.xyChart?.yAxisTickColor || this.primaryTextColor,
			yAxisLineColor: this.xyChart?.yAxisLineColor || this.primaryTextColor,
			plotColorPalette: this.xyChart?.plotColorPalette || "#3498db,#2ecc71,#e74c3c,#f1c40f,#bdc3c7,#ffffff,#34495e,#9b59b6,#1abc9c,#e67e22"
		};
		this.packet = {
			startByteColor: this.primaryTextColor,
			endByteColor: this.primaryTextColor,
			labelColor: this.primaryTextColor,
			titleColor: this.primaryTextColor,
			blockStrokeColor: this.primaryTextColor,
			blockFillColor: this.background
		};
		this.radar = {
			axisColor: this.radar?.axisColor || this.lineColor,
			axisStrokeWidth: this.radar?.axisStrokeWidth || 2,
			axisLabelFontSize: this.radar?.axisLabelFontSize || 12,
			curveOpacity: this.radar?.curveOpacity || .5,
			curveStrokeWidth: this.radar?.curveStrokeWidth || 2,
			graticuleColor: this.radar?.graticuleColor || "#DEDEDE",
			graticuleStrokeWidth: this.radar?.graticuleStrokeWidth || 1,
			graticuleOpacity: this.radar?.graticuleOpacity || .3,
			legendBoxSize: this.radar?.legendBoxSize || 12,
			legendFontSize: this.radar?.legendFontSize || 12
		};
		this.wardleyEvolutionColor = this.wardleyEvolutionColor || "#ff6b6b";
		this.wardley = {
			backgroundColor: this.wardley?.backgroundColor || this.background,
			axisColor: this.wardley?.axisColor || this.lineColor,
			axisTextColor: this.wardley?.axisTextColor || this.primaryTextColor,
			gridColor: this.wardley?.gridColor || this.gridColor,
			componentFill: this.wardley?.componentFill || this.mainBkg,
			componentStroke: this.wardley?.componentStroke || this.lineColor,
			componentLabelColor: this.wardley?.componentLabelColor || this.primaryTextColor,
			linkStroke: this.wardley?.linkStroke || this.lineColor,
			evolutionStroke: this.wardley?.evolutionStroke || this.wardleyEvolutionColor,
			annotationStroke: this.wardley?.annotationStroke || this.lineColor,
			annotationTextColor: this.wardley?.annotationTextColor || this.primaryTextColor,
			annotationFill: this.wardley?.annotationFill || this.mainBkg
		};
		this.classText = this.primaryTextColor;
		this.requirementBackground = this.requirementBackground || this.primaryColor;
		this.requirementBorderColor = this.requirementBorderColor || this.primaryBorderColor;
		this.requirementBorderSize = this.requirementBorderSize || "1";
		this.requirementTextColor = this.requirementTextColor || this.primaryTextColor;
		this.relationColor = this.relationColor || this.lineColor;
		this.relationLabelBackground = this.relationLabelBackground || (this.darkMode ? darken(this.secondaryColor, 30) : this.secondaryColor);
		this.relationLabelColor = this.relationLabelColor || this.actorTextColor;
		this.git0 = lighten(this.secondaryColor, 20);
		this.git1 = lighten(this.pie2 || this.secondaryColor, 20);
		this.git2 = lighten(this.pie3 || this.tertiaryColor, 20);
		this.git3 = lighten(this.pie4 || adjust(this.primaryColor, { h: -30 }), 20);
		this.git4 = lighten(this.pie5 || adjust(this.primaryColor, { h: -60 }), 20);
		this.git5 = lighten(this.pie6 || adjust(this.primaryColor, { h: -90 }), 10);
		this.git6 = lighten(this.pie7 || adjust(this.primaryColor, { h: 60 }), 10);
		this.git7 = lighten(this.pie8 || adjust(this.primaryColor, { h: 120 }), 20);
		this.gitInv0 = this.gitInv0 || invert(this.git0);
		this.gitInv1 = this.gitInv1 || invert(this.git1);
		this.gitInv2 = this.gitInv2 || invert(this.git2);
		this.gitInv3 = this.gitInv3 || invert(this.git3);
		this.gitInv4 = this.gitInv4 || invert(this.git4);
		this.gitInv5 = this.gitInv5 || invert(this.git5);
		this.gitInv6 = this.gitInv6 || invert(this.git6);
		this.gitInv7 = this.gitInv7 || invert(this.git7);
		this.gitBranchLabel0 = this.gitBranchLabel0 || invert(this.labelTextColor);
		this.gitBranchLabel1 = this.gitBranchLabel1 || this.labelTextColor;
		this.gitBranchLabel2 = this.gitBranchLabel2 || this.labelTextColor;
		this.gitBranchLabel3 = this.gitBranchLabel3 || invert(this.labelTextColor);
		this.gitBranchLabel4 = this.gitBranchLabel4 || this.labelTextColor;
		this.gitBranchLabel5 = this.gitBranchLabel5 || this.labelTextColor;
		this.gitBranchLabel6 = this.gitBranchLabel6 || this.labelTextColor;
		this.gitBranchLabel7 = this.gitBranchLabel7 || this.labelTextColor;
		this.tagLabelColor = this.tagLabelColor || this.primaryTextColor;
		this.tagLabelBackground = this.tagLabelBackground || this.primaryColor;
		this.tagLabelBorder = this.tagBorder || this.primaryBorderColor;
		this.tagLabelFontSize = this.tagLabelFontSize || "10px";
		this.commitLabelColor = this.commitLabelColor || this.secondaryTextColor;
		this.commitLabelBackground = this.commitLabelBackground || this.secondaryColor;
		this.commitLabelFontSize = this.commitLabelFontSize || "10px";
		this.emUiFill = this.emUiFill || "#2d2d2d";
		this.emUiStroke = this.emUiStroke || "#555";
		this.emProcessorFill = this.emProcessorFill || lighten("#5a3d5c", 10);
		this.emProcessorStroke = this.emProcessorStroke || "#8a6d8c";
		this.emReadModelFill = this.emReadModelFill || lighten("#3d5a2d", 10);
		this.emReadModelStroke = this.emReadModelStroke || "#6d8c5c";
		this.emCommandFill = this.emCommandFill || lighten("#2d3d5a", 10);
		this.emCommandStroke = this.emCommandStroke || "#5c6d8c";
		this.emEventFill = this.emEventFill || lighten("#5a452d", 10);
		this.emEventStroke = this.emEventStroke || "#8c755c";
		this.emSwimlaneBackgroundOdd = this.emSwimlaneBackgroundOdd || lighten(this.background, 5);
		this.emSwimlaneBackgroundStroke = this.emSwimlaneBackgroundStroke || lighten(this.background, 12);
		this.emArrowhead = this.emArrowhead || this.lineColor;
		this.emRelationStroke = this.emRelationStroke || this.lineColor;
		this.attributeBackgroundColorOdd = this.attributeBackgroundColorOdd || lighten(this.background, 12);
		this.attributeBackgroundColorEven = this.attributeBackgroundColorEven || lighten(this.background, 2);
		this.nodeBorder = this.nodeBorder || "#999";
	}
	calculate(overrides) {
		if (typeof overrides !== "object") {
			this.updateColors();
			return;
		}
		const keys = Object.keys(overrides);
		keys.forEach((k) => {
			this[k] = overrides[k];
		});
		this.updateColors();
		keys.forEach((k) => {
			this[k] = overrides[k];
		});
	}
};
var getThemeVariables2 = /* @__PURE__ */ __name((userOverrides) => {
	const theme = new Theme2();
	theme.calculate(userOverrides);
	return theme;
}, "getThemeVariables");
var Theme3 = class {
	static {
		__name(this, "Theme");
	}
	constructor() {
		this.background = "#f4f4f4";
		this.primaryColor = "#ECECFF";
		this.secondaryColor = adjust(this.primaryColor, { h: 120 });
		this.secondaryColor = "#ffffde";
		this.tertiaryColor = adjust(this.primaryColor, { h: -160 });
		this.primaryBorderColor = mkBorder(this.primaryColor, this.darkMode);
		this.secondaryBorderColor = mkBorder(this.secondaryColor, this.darkMode);
		this.tertiaryBorderColor = mkBorder(this.tertiaryColor, this.darkMode);
		this.primaryTextColor = invert(this.primaryColor);
		this.secondaryTextColor = invert(this.secondaryColor);
		this.tertiaryTextColor = invert(this.tertiaryColor);
		this.lineColor = invert(this.background);
		this.textColor = invert(this.background);
		this.background = "white";
		this.mainBkg = "#ECECFF";
		this.secondBkg = "#ffffde";
		this.lineColor = "#333333";
		this.border1 = "#9370DB";
		this.primaryBorderColor = mkBorder(this.primaryColor, this.darkMode);
		this.border2 = "#aaaa33";
		this.arrowheadColor = "#333333";
		this.fontFamily = "\"trebuchet ms\", verdana, arial, sans-serif";
		this.fontSize = "16px";
		this.labelBackground = "rgba(232,232,232, 0.8)";
		this.textColor = "#333";
		this.THEME_COLOR_LIMIT = 12;
		this.radius = 5;
		this.strokeWidth = 1;
		this.nodeBkg = "calculated";
		this.nodeBorder = "calculated";
		this.clusterBkg = "calculated";
		this.clusterBorder = "calculated";
		this.defaultLinkColor = "calculated";
		this.titleColor = "calculated";
		this.edgeLabelBackground = "calculated";
		this.actorBorder = "calculated";
		this.actorBkg = "calculated";
		this.actorTextColor = "black";
		this.actorLineColor = "calculated";
		this.signalColor = "calculated";
		this.signalTextColor = "calculated";
		this.labelBoxBkgColor = "calculated";
		this.labelBoxBorderColor = "calculated";
		this.labelTextColor = "calculated";
		this.loopTextColor = "calculated";
		this.noteBorderColor = "calculated";
		this.noteBkgColor = "#fff5ad";
		this.noteTextColor = "calculated";
		this.activationBorderColor = "#666";
		this.activationBkgColor = "#f4f4f4";
		this.sequenceNumberColor = "white";
		this.clusterBkg = "#FBFBFF";
		this.sectionBkgColor = "calculated";
		this.altSectionBkgColor = "calculated";
		this.sectionBkgColor2 = "calculated";
		this.excludeBkgColor = "#eeeeee";
		this.taskBorderColor = "calculated";
		this.taskBkgColor = "calculated";
		this.taskTextLightColor = "calculated";
		this.taskTextColor = this.taskTextLightColor;
		this.taskTextDarkColor = "calculated";
		this.taskTextOutsideColor = this.taskTextDarkColor;
		this.taskTextClickableColor = "calculated";
		this.activeTaskBorderColor = "calculated";
		this.activeTaskBkgColor = "calculated";
		this.gridColor = "calculated";
		this.doneTaskBkgColor = "calculated";
		this.doneTaskBorderColor = "calculated";
		this.critBorderColor = "calculated";
		this.critBkgColor = "calculated";
		this.todayLineColor = "calculated";
		this.vertLineColor = "calculated";
		this.sectionBkgColor = rgba(102, 102, 255, .49);
		this.altSectionBkgColor = "white";
		this.sectionBkgColor2 = "#fff400";
		this.taskBorderColor = "#534fbc";
		this.taskBkgColor = "#8a90dd";
		this.taskTextLightColor = "white";
		this.taskTextColor = "calculated";
		this.taskTextDarkColor = "black";
		this.taskTextOutsideColor = "calculated";
		this.taskTextClickableColor = "#003163";
		this.activeTaskBorderColor = "#534fbc";
		this.activeTaskBkgColor = "#bfc7ff";
		this.gridColor = "lightgrey";
		this.doneTaskBkgColor = "lightgrey";
		this.doneTaskBorderColor = "grey";
		this.critBorderColor = "#ff8888";
		this.critBkgColor = "red";
		this.todayLineColor = "red";
		this.vertLineColor = "navy";
		this.noteFontWeight = this.noteFontWeight || "normal";
		this.fontWeight = this.fontWeight || "normal";
		this.personBorder = this.primaryBorderColor;
		this.personBkg = this.mainBkg;
		this.archEdgeColor = "calculated";
		this.archEdgeArrowColor = "calculated";
		this.archEdgeWidth = "3";
		this.archGroupBorderColor = this.primaryBorderColor;
		this.archGroupBorderWidth = "2px";
		this.rowOdd = "calculated";
		this.rowEven = "calculated";
		this.labelColor = "black";
		this.errorBkgColor = "#552222";
		this.errorTextColor = "#552222";
		this.useGradient = false;
		this.gradientStart = this.primaryBorderColor;
		this.gradientStop = this.secondaryBorderColor;
		this.dropShadow = "drop-shadow(1px 2px 2px rgba(185, 185, 185, 1))";
		this.updateColors();
	}
	updateColors() {
		this.cScale0 = this.cScale0 || this.primaryColor;
		this.cScale1 = this.cScale1 || this.secondaryColor;
		this.cScale2 = this.cScale2 || this.tertiaryColor;
		this.cScale3 = this.cScale3 || adjust(this.primaryColor, { h: 30 });
		this.cScale4 = this.cScale4 || adjust(this.primaryColor, { h: 60 });
		this.cScale5 = this.cScale5 || adjust(this.primaryColor, { h: 90 });
		this.cScale6 = this.cScale6 || adjust(this.primaryColor, { h: 120 });
		this.cScale7 = this.cScale7 || adjust(this.primaryColor, { h: 150 });
		this.cScale8 = this.cScale8 || adjust(this.primaryColor, { h: 210 });
		this.cScale9 = this.cScale9 || adjust(this.primaryColor, { h: 270 });
		this.cScale10 = this.cScale10 || adjust(this.primaryColor, { h: 300 });
		this.cScale11 = this.cScale11 || adjust(this.primaryColor, { h: 330 });
		this["cScalePeer1"] = this["cScalePeer1"] || darken(this.secondaryColor, 45);
		this["cScalePeer2"] = this["cScalePeer2"] || darken(this.tertiaryColor, 40);
		for (let i = 0; i < this.THEME_COLOR_LIMIT; i++) {
			this["cScale" + i] = darken(this["cScale" + i], 10);
			this["cScalePeer" + i] = this["cScalePeer" + i] || darken(this["cScale" + i], 25);
		}
		for (let i = 0; i < this.THEME_COLOR_LIMIT; i++) this["cScaleInv" + i] = this["cScaleInv" + i] || adjust(this["cScale" + i], { h: 180 });
		for (let i = 0; i < 5; i++) {
			this["surface" + i] = this["surface" + i] || adjust(this.mainBkg, {
				h: 30,
				l: -(5 + i * 5)
			});
			this["surfacePeer" + i] = this["surfacePeer" + i] || adjust(this.mainBkg, {
				h: 30,
				l: -(7 + i * 5)
			});
		}
		this.scaleLabelColor = this.scaleLabelColor !== "calculated" && this.scaleLabelColor ? this.scaleLabelColor : this.labelTextColor;
		if (this.labelTextColor !== "calculated") {
			this.cScaleLabel0 = this.cScaleLabel0 || invert(this.labelTextColor);
			this.cScaleLabel3 = this.cScaleLabel3 || invert(this.labelTextColor);
			for (let i = 0; i < this.THEME_COLOR_LIMIT; i++) this["cScaleLabel" + i] = this["cScaleLabel" + i] || this.labelTextColor;
		}
		this.nodeBkg = this.mainBkg;
		this.nodeBorder = this.border1;
		this.clusterBkg = this.secondBkg;
		this.clusterBorder = this.border2;
		this.defaultLinkColor = this.lineColor;
		this.titleColor = this.textColor;
		this.edgeLabelBackground = this.labelBackground;
		this.actorBorder = this.border1;
		this.actorBkg = this.mainBkg;
		this.labelBoxBkgColor = this.actorBkg;
		this.signalColor = this.textColor;
		this.signalTextColor = this.textColor;
		this.labelBoxBorderColor = this.actorBorder;
		this.labelTextColor = this.actorTextColor;
		this.loopTextColor = this.actorTextColor;
		this.noteBorderColor = this.border2;
		this.noteTextColor = this.actorTextColor;
		this.actorLineColor = this.actorBorder;
		this.taskTextColor = this.taskTextLightColor;
		this.taskTextOutsideColor = this.taskTextDarkColor;
		this.archEdgeColor = this.lineColor;
		this.archEdgeArrowColor = this.lineColor;
		this.rowOdd = this.rowOdd || lighten(this.primaryColor, 75) || "#ffffff";
		this.rowEven = this.rowEven || lighten(this.primaryColor, 1);
		this.transitionColor = this.transitionColor || this.lineColor;
		this.transitionLabelColor = this.transitionLabelColor || this.textColor;
		this.stateLabelColor = this.stateLabelColor || this.stateBkg || this.primaryTextColor;
		this.stateBkg = this.stateBkg || this.mainBkg;
		this.labelBackgroundColor = this.labelBackgroundColor || this.stateBkg;
		this.compositeBackground = this.compositeBackground || this.background || this.tertiaryColor;
		this.altBackground = this.altBackground || "#f0f0f0";
		this.compositeTitleBackground = this.compositeTitleBackground || this.mainBkg;
		this.compositeBorder = this.compositeBorder || this.nodeBorder;
		this.innerEndBackground = this.nodeBorder;
		this.specialStateColor = this.lineColor;
		this.errorBkgColor = this.errorBkgColor || this.tertiaryColor;
		this.errorTextColor = this.errorTextColor || this.tertiaryTextColor;
		this.transitionColor = this.transitionColor || this.lineColor;
		this.classText = this.primaryTextColor;
		this.fillType0 = this.primaryColor;
		this.fillType1 = this.secondaryColor;
		this.fillType2 = adjust(this.primaryColor, { h: 64 });
		this.fillType3 = adjust(this.secondaryColor, { h: 64 });
		this.fillType4 = adjust(this.primaryColor, { h: -64 });
		this.fillType5 = adjust(this.secondaryColor, { h: -64 });
		this.fillType6 = adjust(this.primaryColor, { h: 128 });
		this.fillType7 = adjust(this.secondaryColor, { h: 128 });
		this.pie1 = this.pie1 || this.primaryColor;
		this.pie2 = this.pie2 || this.secondaryColor;
		this.pie3 = this.pie3 || adjust(this.tertiaryColor, { l: -40 });
		this.pie4 = this.pie4 || adjust(this.primaryColor, { l: -10 });
		this.pie5 = this.pie5 || adjust(this.secondaryColor, { l: -30 });
		this.pie6 = this.pie6 || adjust(this.tertiaryColor, { l: -20 });
		this.pie7 = this.pie7 || adjust(this.primaryColor, {
			h: 60,
			l: -20
		});
		this.pie8 = this.pie8 || adjust(this.primaryColor, {
			h: -60,
			l: -40
		});
		this.pie9 = this.pie9 || adjust(this.primaryColor, {
			h: 120,
			l: -40
		});
		this.pie10 = this.pie10 || adjust(this.primaryColor, {
			h: 60,
			l: -40
		});
		this.pie11 = this.pie11 || adjust(this.primaryColor, {
			h: -90,
			l: -40
		});
		this.pie12 = this.pie12 || adjust(this.primaryColor, {
			h: 120,
			l: -30
		});
		this.pieTitleTextSize = this.pieTitleTextSize || "25px";
		this.pieTitleTextColor = this.pieTitleTextColor || this.taskTextDarkColor;
		this.pieSectionTextSize = this.pieSectionTextSize || "17px";
		this.pieSectionTextColor = this.pieSectionTextColor || this.textColor;
		this.pieLegendTextSize = this.pieLegendTextSize || "17px";
		this.pieLegendTextColor = this.pieLegendTextColor || this.taskTextDarkColor;
		this.pieStrokeColor = this.pieStrokeColor || "black";
		this.pieStrokeWidth = this.pieStrokeWidth || "2px";
		this.pieOuterStrokeWidth = this.pieOuterStrokeWidth || "2px";
		this.pieOuterStrokeColor = this.pieOuterStrokeColor || "black";
		this.pieOpacity = this.pieOpacity || "0.7";
		this.venn1 = this.venn1 ?? adjust(this.primaryColor, { l: -30 });
		this.venn2 = this.venn2 ?? adjust(this.secondaryColor, { l: -30 });
		this.venn3 = this.venn3 ?? adjust(this.tertiaryColor, { l: -40 });
		this.venn4 = this.venn4 ?? adjust(this.primaryColor, {
			h: 60,
			l: -30
		});
		this.venn5 = this.venn5 ?? adjust(this.primaryColor, {
			h: -60,
			l: -30
		});
		this.venn6 = this.venn6 ?? adjust(this.secondaryColor, {
			h: 60,
			l: -30
		});
		this.venn7 = this.venn7 ?? adjust(this.primaryColor, {
			h: 120,
			l: -30
		});
		this.venn8 = this.venn8 ?? adjust(this.secondaryColor, {
			h: 120,
			l: -30
		});
		this.vennTitleTextColor = this.vennTitleTextColor ?? this.titleColor;
		this.vennSetTextColor = this.vennSetTextColor ?? this.textColor;
		this.quadrant1Fill = this.quadrant1Fill || this.primaryColor;
		this.quadrant2Fill = this.quadrant2Fill || adjust(this.primaryColor, {
			r: 5,
			g: 5,
			b: 5
		});
		this.quadrant3Fill = this.quadrant3Fill || adjust(this.primaryColor, {
			r: 10,
			g: 10,
			b: 10
		});
		this.quadrant4Fill = this.quadrant4Fill || adjust(this.primaryColor, {
			r: 15,
			g: 15,
			b: 15
		});
		this.quadrant1TextFill = this.quadrant1TextFill || this.primaryTextColor;
		this.quadrant2TextFill = this.quadrant2TextFill || adjust(this.primaryTextColor, {
			r: -5,
			g: -5,
			b: -5
		});
		this.quadrant3TextFill = this.quadrant3TextFill || adjust(this.primaryTextColor, {
			r: -10,
			g: -10,
			b: -10
		});
		this.quadrant4TextFill = this.quadrant4TextFill || adjust(this.primaryTextColor, {
			r: -15,
			g: -15,
			b: -15
		});
		this.quadrantPointFill = this.quadrantPointFill || isDark(this.quadrant1Fill) ? lighten(this.quadrant1Fill) : darken(this.quadrant1Fill);
		this.quadrantPointTextFill = this.quadrantPointTextFill || this.primaryTextColor;
		this.quadrantXAxisTextFill = this.quadrantXAxisTextFill || this.primaryTextColor;
		this.quadrantYAxisTextFill = this.quadrantYAxisTextFill || this.primaryTextColor;
		this.quadrantInternalBorderStrokeFill = this.quadrantInternalBorderStrokeFill || this.primaryBorderColor;
		this.quadrantExternalBorderStrokeFill = this.quadrantExternalBorderStrokeFill || this.primaryBorderColor;
		this.quadrantTitleFill = this.quadrantTitleFill || this.primaryTextColor;
		this.radar = {
			axisColor: this.radar?.axisColor || this.lineColor,
			axisStrokeWidth: this.radar?.axisStrokeWidth || 2,
			axisLabelFontSize: this.radar?.axisLabelFontSize || 12,
			curveOpacity: this.radar?.curveOpacity || .5,
			curveStrokeWidth: this.radar?.curveStrokeWidth || 2,
			graticuleColor: this.radar?.graticuleColor || "#DEDEDE",
			graticuleStrokeWidth: this.radar?.graticuleStrokeWidth || 1,
			graticuleOpacity: this.radar?.graticuleOpacity || .3,
			legendBoxSize: this.radar?.legendBoxSize || 12,
			legendFontSize: this.radar?.legendFontSize || 12
		};
		this.wardleyEvolutionColor = this.wardleyEvolutionColor || "#dc3545";
		this.wardley = {
			backgroundColor: this.wardley?.backgroundColor || this.background,
			axisColor: this.wardley?.axisColor || this.lineColor,
			axisTextColor: this.wardley?.axisTextColor || this.primaryTextColor,
			gridColor: this.wardley?.gridColor || this.gridColor,
			componentFill: this.wardley?.componentFill || this.background,
			componentStroke: this.wardley?.componentStroke || this.lineColor,
			componentLabelColor: this.wardley?.componentLabelColor || this.primaryTextColor,
			linkStroke: this.wardley?.linkStroke || this.lineColor,
			evolutionStroke: this.wardley?.evolutionStroke || this.wardleyEvolutionColor,
			annotationStroke: this.wardley?.annotationStroke || this.lineColor,
			annotationTextColor: this.wardley?.annotationTextColor || this.primaryTextColor,
			annotationFill: this.wardley?.annotationFill || this.background
		};
		this.xyChart = {
			backgroundColor: this.xyChart?.backgroundColor || this.background,
			titleColor: this.xyChart?.titleColor || this.primaryTextColor,
			dataLabelColor: this.xyChart?.dataLabelColor || this.primaryTextColor,
			xAxisTitleColor: this.xyChart?.xAxisTitleColor || this.primaryTextColor,
			xAxisLabelColor: this.xyChart?.xAxisLabelColor || this.primaryTextColor,
			xAxisTickColor: this.xyChart?.xAxisTickColor || this.primaryTextColor,
			xAxisLineColor: this.xyChart?.xAxisLineColor || this.primaryTextColor,
			yAxisTitleColor: this.xyChart?.yAxisTitleColor || this.primaryTextColor,
			yAxisLabelColor: this.xyChart?.yAxisLabelColor || this.primaryTextColor,
			yAxisTickColor: this.xyChart?.yAxisTickColor || this.primaryTextColor,
			yAxisLineColor: this.xyChart?.yAxisLineColor || this.primaryTextColor,
			plotColorPalette: this.xyChart?.plotColorPalette || "#ECECFF,#8493A6,#FFC3A0,#DCDDE1,#B8E994,#D1A36F,#C3CDE6,#FFB6C1,#496078,#F8F3E3"
		};
		this.requirementBackground = this.requirementBackground || this.primaryColor;
		this.requirementBorderColor = this.requirementBorderColor || this.primaryBorderColor;
		this.requirementBorderSize = this.requirementBorderSize || "1";
		this.requirementTextColor = this.requirementTextColor || this.primaryTextColor;
		this.relationColor = this.relationColor || this.lineColor;
		this.relationLabelBackground = this.relationLabelBackground || this.labelBackground;
		this.relationLabelColor = this.relationLabelColor || this.actorTextColor;
		this.git0 = this.git0 || this.primaryColor;
		this.git1 = this.git1 || this.secondaryColor;
		this.git2 = this.git2 || this.tertiaryColor;
		this.git3 = this.git3 || adjust(this.primaryColor, { h: -30 });
		this.git4 = this.git4 || adjust(this.primaryColor, { h: -60 });
		this.git5 = this.git5 || adjust(this.primaryColor, { h: -90 });
		this.git6 = this.git6 || adjust(this.primaryColor, { h: 60 });
		this.git7 = this.git7 || adjust(this.primaryColor, { h: 120 });
		if (this.darkMode) {
			this.git0 = lighten(this.git0, 25);
			this.git1 = lighten(this.git1, 25);
			this.git2 = lighten(this.git2, 25);
			this.git3 = lighten(this.git3, 25);
			this.git4 = lighten(this.git4, 25);
			this.git5 = lighten(this.git5, 25);
			this.git6 = lighten(this.git6, 25);
			this.git7 = lighten(this.git7, 25);
		} else {
			this.git0 = darken(this.git0, 25);
			this.git1 = darken(this.git1, 25);
			this.git2 = darken(this.git2, 25);
			this.git3 = darken(this.git3, 25);
			this.git4 = darken(this.git4, 25);
			this.git5 = darken(this.git5, 25);
			this.git6 = darken(this.git6, 25);
			this.git7 = darken(this.git7, 25);
		}
		this.gitInv0 = this.gitInv0 || darken(invert(this.git0), 25);
		this.gitInv1 = this.gitInv1 || invert(this.git1);
		this.gitInv2 = this.gitInv2 || invert(this.git2);
		this.gitInv3 = this.gitInv3 || invert(this.git3);
		this.gitInv4 = this.gitInv4 || invert(this.git4);
		this.gitInv5 = this.gitInv5 || invert(this.git5);
		this.gitInv6 = this.gitInv6 || invert(this.git6);
		this.gitInv7 = this.gitInv7 || invert(this.git7);
		this.gitBranchLabel0 = this.gitBranchLabel0 || invert(this.labelTextColor);
		this.gitBranchLabel1 = this.gitBranchLabel1 || this.labelTextColor;
		this.gitBranchLabel2 = this.gitBranchLabel2 || this.labelTextColor;
		this.gitBranchLabel3 = this.gitBranchLabel3 || invert(this.labelTextColor);
		this.gitBranchLabel4 = this.gitBranchLabel4 || this.labelTextColor;
		this.gitBranchLabel5 = this.gitBranchLabel5 || this.labelTextColor;
		this.gitBranchLabel6 = this.gitBranchLabel6 || this.labelTextColor;
		this.gitBranchLabel7 = this.gitBranchLabel7 || this.labelTextColor;
		this.tagLabelColor = this.tagLabelColor || this.primaryTextColor;
		this.tagLabelBackground = this.tagLabelBackground || this.primaryColor;
		this.tagLabelBorder = this.tagBorder || this.primaryBorderColor;
		this.tagLabelFontSize = this.tagLabelFontSize || "10px";
		this.commitLabelColor = this.commitLabelColor || this.secondaryTextColor;
		this.commitLabelBackground = this.commitLabelBackground || this.secondaryColor;
		this.commitLabelFontSize = this.commitLabelFontSize || "10px";
		this.emUiFill = this.emUiFill || "white";
		this.emUiStroke = this.emUiStroke || "#dbdada";
		this.emProcessorFill = this.emProcessorFill || "#edb3f6";
		this.emProcessorStroke = this.emProcessorStroke || "#b88cbf";
		this.emReadModelFill = this.emReadModelFill || "#d3f1a2";
		this.emReadModelStroke = this.emReadModelStroke || "#a3b732";
		this.emCommandFill = this.emCommandFill || "#bcd6fe";
		this.emCommandStroke = this.emCommandStroke || "#679ac3";
		this.emEventFill = this.emEventFill || "#ffb778";
		this.emEventStroke = this.emEventStroke || "#c19a0f";
		this.emSwimlaneBackgroundOdd = this.emSwimlaneBackgroundOdd || "rgb(250,250,250)";
		this.emSwimlaneBackgroundStroke = this.emSwimlaneBackgroundStroke || "rgb(240,240,240)";
		this.emArrowhead = this.emArrowhead || this.lineColor;
		this.emRelationStroke = this.emRelationStroke || this.lineColor;
		this.attributeBackgroundColorOdd = this.attributeBackgroundColorOdd || oldAttributeBackgroundColorOdd;
		this.attributeBackgroundColorEven = this.attributeBackgroundColorEven || oldAttributeBackgroundColorEven;
	}
	calculate(overrides) {
		Object.keys(this).forEach((k) => {
			if (this[k] === "calculated") this[k] = void 0;
		});
		if (typeof overrides !== "object") {
			this.updateColors();
			return;
		}
		const keys = Object.keys(overrides);
		keys.forEach((k) => {
			this[k] = overrides[k];
		});
		this.updateColors();
		keys.forEach((k) => {
			this[k] = overrides[k];
		});
	}
};
var getThemeVariables3 = /* @__PURE__ */ __name((userOverrides) => {
	const theme = new Theme3();
	theme.calculate(userOverrides);
	return theme;
}, "getThemeVariables");
var Theme4 = class {
	static {
		__name(this, "Theme");
	}
	constructor() {
		this.background = "#f4f4f4";
		this.primaryColor = "#cde498";
		this.secondaryColor = "#cdffb2";
		this.background = "white";
		this.mainBkg = "#cde498";
		this.secondBkg = "#cdffb2";
		this.lineColor = "green";
		this.border1 = "#13540c";
		this.border2 = "#6eaa49";
		this.arrowheadColor = "green";
		this.fontFamily = "\"trebuchet ms\", verdana, arial, sans-serif";
		this.fontSize = "16px";
		this.tertiaryColor = lighten("#cde498", 10);
		this.primaryBorderColor = mkBorder(this.primaryColor, this.darkMode);
		this.secondaryBorderColor = mkBorder(this.secondaryColor, this.darkMode);
		this.tertiaryBorderColor = mkBorder(this.tertiaryColor, this.darkMode);
		this.primaryTextColor = invert(this.primaryColor);
		this.secondaryTextColor = invert(this.secondaryColor);
		this.tertiaryTextColor = invert(this.primaryColor);
		this.lineColor = invert(this.background);
		this.textColor = invert(this.background);
		this.THEME_COLOR_LIMIT = 12;
		this.radius = 5;
		this.strokeWidth = 1;
		this.nodeBkg = "calculated";
		this.nodeBorder = "calculated";
		this.clusterBkg = "calculated";
		this.clusterBorder = "calculated";
		this.defaultLinkColor = "calculated";
		this.titleColor = "#333";
		this.edgeLabelBackground = "#e8e8e8";
		this.actorBorder = "calculated";
		this.actorBkg = "calculated";
		this.actorTextColor = "black";
		this.actorLineColor = "calculated";
		this.signalColor = "#333";
		this.signalTextColor = "#333";
		this.labelBoxBkgColor = "calculated";
		this.labelBoxBorderColor = "#326932";
		this.labelTextColor = "calculated";
		this.loopTextColor = "calculated";
		this.noteBorderColor = "calculated";
		this.noteBkgColor = "#fff5ad";
		this.noteTextColor = "calculated";
		this.activationBorderColor = "#666";
		this.activationBkgColor = "#f4f4f4";
		this.sequenceNumberColor = "white";
		this.sectionBkgColor = "#6eaa49";
		this.altSectionBkgColor = "white";
		this.sectionBkgColor2 = "#6eaa49";
		this.excludeBkgColor = "#eeeeee";
		this.taskBorderColor = "calculated";
		this.taskBkgColor = "#487e3a";
		this.taskTextLightColor = "white";
		this.taskTextColor = "calculated";
		this.taskTextDarkColor = "black";
		this.taskTextOutsideColor = "calculated";
		this.taskTextClickableColor = "#003163";
		this.activeTaskBorderColor = "calculated";
		this.activeTaskBkgColor = "calculated";
		this.gridColor = "lightgrey";
		this.doneTaskBkgColor = "lightgrey";
		this.doneTaskBorderColor = "grey";
		this.critBorderColor = "#ff8888";
		this.critBkgColor = "red";
		this.todayLineColor = "red";
		this.vertLineColor = "#00BFFF";
		this.personBorder = this.primaryBorderColor;
		this.personBkg = this.mainBkg;
		this.archEdgeColor = "calculated";
		this.archEdgeArrowColor = "calculated";
		this.archEdgeWidth = "3";
		this.archGroupBorderColor = this.primaryBorderColor;
		this.archGroupBorderWidth = "2px";
		this.noteFontWeight = "normal";
		this.fontWeight = "normal";
		this.labelColor = "black";
		this.errorBkgColor = "#552222";
		this.errorTextColor = "#552222";
		this.useGradient = true;
		this.gradientStart = this.primaryBorderColor;
		this.gradientStop = this.secondaryBorderColor;
		this.dropShadow = "drop-shadow( 1px 2px 2px rgba(185,185,185,0.5))";
	}
	updateColors() {
		this.actorBorder = darken(this.mainBkg, 20);
		this.actorBkg = this.mainBkg;
		this.labelBoxBkgColor = this.actorBkg;
		this.labelTextColor = this.actorTextColor;
		this.loopTextColor = this.actorTextColor;
		this.noteBorderColor = this.border2;
		this.noteTextColor = this.actorTextColor;
		this.actorLineColor = this.actorBorder;
		this.cScale0 = this.cScale0 || this.primaryColor;
		this.cScale1 = this.cScale1 || this.secondaryColor;
		this.cScale2 = this.cScale2 || this.tertiaryColor;
		this.cScale3 = this.cScale3 || adjust(this.primaryColor, { h: 30 });
		this.cScale4 = this.cScale4 || adjust(this.primaryColor, { h: 60 });
		this.cScale5 = this.cScale5 || adjust(this.primaryColor, { h: 90 });
		this.cScale6 = this.cScale6 || adjust(this.primaryColor, { h: 120 });
		this.cScale7 = this.cScale7 || adjust(this.primaryColor, { h: 150 });
		this.cScale8 = this.cScale8 || adjust(this.primaryColor, { h: 210 });
		this.cScale9 = this.cScale9 || adjust(this.primaryColor, { h: 270 });
		this.cScale10 = this.cScale10 || adjust(this.primaryColor, { h: 300 });
		this.cScale11 = this.cScale11 || adjust(this.primaryColor, { h: 330 });
		this["cScalePeer1"] = this["cScalePeer1"] || darken(this.secondaryColor, 45);
		this["cScalePeer2"] = this["cScalePeer2"] || darken(this.tertiaryColor, 40);
		for (let i = 0; i < this.THEME_COLOR_LIMIT; i++) {
			this["cScale" + i] = darken(this["cScale" + i], 10);
			this["cScalePeer" + i] = this["cScalePeer" + i] || darken(this["cScale" + i], 25);
		}
		for (let i = 0; i < this.THEME_COLOR_LIMIT; i++) this["cScaleInv" + i] = this["cScaleInv" + i] || adjust(this["cScale" + i], { h: 180 });
		this.scaleLabelColor = this.scaleLabelColor !== "calculated" && this.scaleLabelColor ? this.scaleLabelColor : this.labelTextColor;
		for (let i = 0; i < this.THEME_COLOR_LIMIT; i++) this["cScaleLabel" + i] = this["cScaleLabel" + i] || this.scaleLabelColor;
		for (let i = 0; i < 5; i++) {
			this["surface" + i] = this["surface" + i] || adjust(this.mainBkg, {
				h: 30,
				s: -30,
				l: -(5 + i * 5)
			});
			this["surfacePeer" + i] = this["surfacePeer" + i] || adjust(this.mainBkg, {
				h: 30,
				s: -30,
				l: -(8 + i * 5)
			});
		}
		this.nodeBkg = this.mainBkg;
		this.nodeBorder = this.border1;
		this.clusterBkg = this.secondBkg;
		this.clusterBorder = this.border2;
		this.defaultLinkColor = this.lineColor;
		this.taskBorderColor = this.border1;
		this.taskTextColor = this.taskTextLightColor;
		this.taskTextOutsideColor = this.taskTextDarkColor;
		this.activeTaskBorderColor = this.taskBorderColor;
		this.activeTaskBkgColor = this.mainBkg;
		this.archEdgeColor = this.lineColor;
		this.archEdgeArrowColor = this.lineColor;
		this.rowOdd = this.rowOdd || lighten(this.mainBkg, 75) || "#ffffff";
		this.rowEven = this.rowEven || lighten(this.mainBkg, 20);
		this.transitionColor = this.transitionColor || this.lineColor;
		this.transitionLabelColor = this.transitionLabelColor || this.textColor;
		this.stateLabelColor = this.stateLabelColor || this.stateBkg || this.primaryTextColor;
		this.stateBkg = this.stateBkg || this.mainBkg;
		this.labelBackgroundColor = this.labelBackgroundColor || this.stateBkg;
		this.compositeBackground = this.compositeBackground || this.background || this.tertiaryColor;
		this.altBackground = this.altBackground || "#f0f0f0";
		this.compositeTitleBackground = this.compositeTitleBackground || this.mainBkg;
		this.compositeBorder = this.compositeBorder || this.nodeBorder;
		this.innerEndBackground = this.primaryBorderColor;
		this.specialStateColor = this.lineColor;
		this.errorBkgColor = this.errorBkgColor || this.tertiaryColor;
		this.errorTextColor = this.errorTextColor || this.tertiaryTextColor;
		this.transitionColor = this.transitionColor || this.lineColor;
		this.classText = this.primaryTextColor;
		this.fillType0 = this.primaryColor;
		this.fillType1 = this.secondaryColor;
		this.fillType2 = adjust(this.primaryColor, { h: 64 });
		this.fillType3 = adjust(this.secondaryColor, { h: 64 });
		this.fillType4 = adjust(this.primaryColor, { h: -64 });
		this.fillType5 = adjust(this.secondaryColor, { h: -64 });
		this.fillType6 = adjust(this.primaryColor, { h: 128 });
		this.fillType7 = adjust(this.secondaryColor, { h: 128 });
		this.pie1 = this.pie1 || this.primaryColor;
		this.pie2 = this.pie2 || this.secondaryColor;
		this.pie3 = this.pie3 || this.tertiaryColor;
		this.pie4 = this.pie4 || adjust(this.primaryColor, { l: -30 });
		this.pie5 = this.pie5 || adjust(this.secondaryColor, { l: -30 });
		this.pie6 = this.pie6 || adjust(this.tertiaryColor, {
			h: 40,
			l: -40
		});
		this.pie7 = this.pie7 || adjust(this.primaryColor, {
			h: 60,
			l: -10
		});
		this.pie8 = this.pie8 || adjust(this.primaryColor, {
			h: -60,
			l: -10
		});
		this.pie9 = this.pie9 || adjust(this.primaryColor, {
			h: 120,
			l: 0
		});
		this.pie10 = this.pie10 || adjust(this.primaryColor, {
			h: 60,
			l: -50
		});
		this.pie11 = this.pie11 || adjust(this.primaryColor, {
			h: -60,
			l: -50
		});
		this.pie12 = this.pie12 || adjust(this.primaryColor, {
			h: 120,
			l: -50
		});
		this.pieTitleTextSize = this.pieTitleTextSize || "25px";
		this.pieTitleTextColor = this.pieTitleTextColor || this.taskTextDarkColor;
		this.pieSectionTextSize = this.pieSectionTextSize || "17px";
		this.pieSectionTextColor = this.pieSectionTextColor || this.textColor;
		this.pieLegendTextSize = this.pieLegendTextSize || "17px";
		this.pieLegendTextColor = this.pieLegendTextColor || this.taskTextDarkColor;
		this.pieStrokeColor = this.pieStrokeColor || "black";
		this.pieStrokeWidth = this.pieStrokeWidth || "2px";
		this.pieOuterStrokeWidth = this.pieOuterStrokeWidth || "2px";
		this.pieOuterStrokeColor = this.pieOuterStrokeColor || "black";
		this.pieOpacity = this.pieOpacity || "0.7";
		this.venn1 = this.venn1 ?? adjust(this.primaryColor, { l: -30 });
		this.venn2 = this.venn2 ?? adjust(this.secondaryColor, { l: -30 });
		this.venn3 = this.venn3 ?? adjust(this.tertiaryColor, { l: -30 });
		this.venn4 = this.venn4 ?? adjust(this.primaryColor, {
			h: 60,
			l: -30
		});
		this.venn5 = this.venn5 ?? adjust(this.primaryColor, {
			h: -60,
			l: -30
		});
		this.venn6 = this.venn6 ?? adjust(this.secondaryColor, {
			h: 60,
			l: -30
		});
		this.venn7 = this.venn7 ?? adjust(this.primaryColor, {
			h: 120,
			l: -30
		});
		this.venn8 = this.venn8 ?? adjust(this.secondaryColor, {
			h: 120,
			l: -30
		});
		this.vennTitleTextColor = this.vennTitleTextColor ?? this.titleColor;
		this.vennSetTextColor = this.vennSetTextColor ?? this.textColor;
		this.quadrant1Fill = this.quadrant1Fill || this.primaryColor;
		this.quadrant2Fill = this.quadrant2Fill || adjust(this.primaryColor, {
			r: 5,
			g: 5,
			b: 5
		});
		this.quadrant3Fill = this.quadrant3Fill || adjust(this.primaryColor, {
			r: 10,
			g: 10,
			b: 10
		});
		this.quadrant4Fill = this.quadrant4Fill || adjust(this.primaryColor, {
			r: 15,
			g: 15,
			b: 15
		});
		this.quadrant1TextFill = this.quadrant1TextFill || this.primaryTextColor;
		this.quadrant2TextFill = this.quadrant2TextFill || adjust(this.primaryTextColor, {
			r: -5,
			g: -5,
			b: -5
		});
		this.quadrant3TextFill = this.quadrant3TextFill || adjust(this.primaryTextColor, {
			r: -10,
			g: -10,
			b: -10
		});
		this.quadrant4TextFill = this.quadrant4TextFill || adjust(this.primaryTextColor, {
			r: -15,
			g: -15,
			b: -15
		});
		this.quadrantPointFill = this.quadrantPointFill || isDark(this.quadrant1Fill) ? lighten(this.quadrant1Fill) : darken(this.quadrant1Fill);
		this.quadrantPointTextFill = this.quadrantPointTextFill || this.primaryTextColor;
		this.quadrantXAxisTextFill = this.quadrantXAxisTextFill || this.primaryTextColor;
		this.quadrantYAxisTextFill = this.quadrantYAxisTextFill || this.primaryTextColor;
		this.quadrantInternalBorderStrokeFill = this.quadrantInternalBorderStrokeFill || this.primaryBorderColor;
		this.quadrantExternalBorderStrokeFill = this.quadrantExternalBorderStrokeFill || this.primaryBorderColor;
		this.quadrantTitleFill = this.quadrantTitleFill || this.primaryTextColor;
		this.packet = {
			startByteColor: this.primaryTextColor,
			endByteColor: this.primaryTextColor,
			labelColor: this.primaryTextColor,
			titleColor: this.primaryTextColor,
			blockStrokeColor: this.primaryTextColor,
			blockFillColor: this.mainBkg
		};
		this.radar = {
			axisColor: this.radar?.axisColor || this.lineColor,
			axisStrokeWidth: this.radar?.axisStrokeWidth || 2,
			axisLabelFontSize: this.radar?.axisLabelFontSize || 12,
			curveOpacity: this.radar?.curveOpacity || .5,
			curveStrokeWidth: this.radar?.curveStrokeWidth || 2,
			graticuleColor: this.radar?.graticuleColor || "#DEDEDE",
			graticuleStrokeWidth: this.radar?.graticuleStrokeWidth || 1,
			graticuleOpacity: this.radar?.graticuleOpacity || .3,
			legendBoxSize: this.radar?.legendBoxSize || 12,
			legendFontSize: this.radar?.legendFontSize || 12
		};
		this.wardleyEvolutionColor = this.wardleyEvolutionColor || "#dc3545";
		this.wardley = {
			backgroundColor: this.wardley?.backgroundColor || this.background,
			axisColor: this.wardley?.axisColor || this.lineColor,
			axisTextColor: this.wardley?.axisTextColor || this.primaryTextColor,
			gridColor: this.wardley?.gridColor || this.gridColor,
			componentFill: this.wardley?.componentFill || this.background,
			componentStroke: this.wardley?.componentStroke || this.lineColor,
			componentLabelColor: this.wardley?.componentLabelColor || this.primaryTextColor,
			linkStroke: this.wardley?.linkStroke || this.lineColor,
			evolutionStroke: this.wardley?.evolutionStroke || this.wardleyEvolutionColor,
			annotationStroke: this.wardley?.annotationStroke || this.lineColor,
			annotationTextColor: this.wardley?.annotationTextColor || this.primaryTextColor,
			annotationFill: this.wardley?.annotationFill || this.background
		};
		this.xyChart = {
			backgroundColor: this.xyChart?.backgroundColor || this.background,
			titleColor: this.xyChart?.titleColor || this.primaryTextColor,
			dataLabelColor: this.xyChart?.dataLabelColor || this.primaryTextColor,
			xAxisTitleColor: this.xyChart?.xAxisTitleColor || this.primaryTextColor,
			xAxisLabelColor: this.xyChart?.xAxisLabelColor || this.primaryTextColor,
			xAxisTickColor: this.xyChart?.xAxisTickColor || this.primaryTextColor,
			xAxisLineColor: this.xyChart?.xAxisLineColor || this.primaryTextColor,
			yAxisTitleColor: this.xyChart?.yAxisTitleColor || this.primaryTextColor,
			yAxisLabelColor: this.xyChart?.yAxisLabelColor || this.primaryTextColor,
			yAxisTickColor: this.xyChart?.yAxisTickColor || this.primaryTextColor,
			yAxisLineColor: this.xyChart?.yAxisLineColor || this.primaryTextColor,
			plotColorPalette: this.xyChart?.plotColorPalette || "#CDE498,#FF6B6B,#A0D2DB,#D7BDE2,#F0F0F0,#FFC3A0,#7FD8BE,#FF9A8B,#FAF3E0,#FFF176"
		};
		this.requirementBackground = this.requirementBackground || this.primaryColor;
		this.requirementBorderColor = this.requirementBorderColor || this.primaryBorderColor;
		this.requirementBorderSize = this.requirementBorderSize || "1";
		this.requirementTextColor = this.requirementTextColor || this.primaryTextColor;
		this.relationColor = this.relationColor || this.lineColor;
		this.relationLabelBackground = this.relationLabelBackground || this.edgeLabelBackground;
		this.relationLabelColor = this.relationLabelColor || this.actorTextColor;
		this.git0 = this.git0 || this.primaryColor;
		this.git1 = this.git1 || this.secondaryColor;
		this.git2 = this.git2 || this.tertiaryColor;
		this.git3 = this.git3 || adjust(this.primaryColor, { h: -30 });
		this.git4 = this.git4 || adjust(this.primaryColor, { h: -60 });
		this.git5 = this.git5 || adjust(this.primaryColor, { h: -90 });
		this.git6 = this.git6 || adjust(this.primaryColor, { h: 60 });
		this.git7 = this.git7 || adjust(this.primaryColor, { h: 120 });
		if (this.darkMode) {
			this.git0 = lighten(this.git0, 25);
			this.git1 = lighten(this.git1, 25);
			this.git2 = lighten(this.git2, 25);
			this.git3 = lighten(this.git3, 25);
			this.git4 = lighten(this.git4, 25);
			this.git5 = lighten(this.git5, 25);
			this.git6 = lighten(this.git6, 25);
			this.git7 = lighten(this.git7, 25);
		} else {
			this.git0 = darken(this.git0, 25);
			this.git1 = darken(this.git1, 25);
			this.git2 = darken(this.git2, 25);
			this.git3 = darken(this.git3, 25);
			this.git4 = darken(this.git4, 25);
			this.git5 = darken(this.git5, 25);
			this.git6 = darken(this.git6, 25);
			this.git7 = darken(this.git7, 25);
		}
		this.gitInv0 = this.gitInv0 || invert(this.git0);
		this.gitInv1 = this.gitInv1 || invert(this.git1);
		this.gitInv2 = this.gitInv2 || invert(this.git2);
		this.gitInv3 = this.gitInv3 || invert(this.git3);
		this.gitInv4 = this.gitInv4 || invert(this.git4);
		this.gitInv5 = this.gitInv5 || invert(this.git5);
		this.gitInv6 = this.gitInv6 || invert(this.git6);
		this.gitInv7 = this.gitInv7 || invert(this.git7);
		this.gitBranchLabel0 = this.gitBranchLabel0 || invert(this.labelTextColor);
		this.gitBranchLabel1 = this.gitBranchLabel1 || this.labelTextColor;
		this.gitBranchLabel2 = this.gitBranchLabel2 || this.labelTextColor;
		this.gitBranchLabel3 = this.gitBranchLabel3 || invert(this.labelTextColor);
		this.gitBranchLabel4 = this.gitBranchLabel4 || this.labelTextColor;
		this.gitBranchLabel5 = this.gitBranchLabel5 || this.labelTextColor;
		this.gitBranchLabel6 = this.gitBranchLabel6 || this.labelTextColor;
		this.gitBranchLabel7 = this.gitBranchLabel7 || this.labelTextColor;
		this.tagLabelColor = this.tagLabelColor || this.primaryTextColor;
		this.tagLabelBackground = this.tagLabelBackground || this.primaryColor;
		this.tagLabelBorder = this.tagBorder || this.primaryBorderColor;
		this.tagLabelFontSize = this.tagLabelFontSize || "10px";
		this.commitLabelColor = this.commitLabelColor || this.secondaryTextColor;
		this.commitLabelBackground = this.commitLabelBackground || this.secondaryColor;
		this.commitLabelFontSize = this.commitLabelFontSize || "10px";
		this.emUiFill = this.emUiFill || "white";
		this.emUiStroke = this.emUiStroke || "#dbdada";
		this.emProcessorFill = this.emProcessorFill || "#edb3f6";
		this.emProcessorStroke = this.emProcessorStroke || "#b88cbf";
		this.emReadModelFill = this.emReadModelFill || "#d3f1a2";
		this.emReadModelStroke = this.emReadModelStroke || "#a3b732";
		this.emCommandFill = this.emCommandFill || "#bcd6fe";
		this.emCommandStroke = this.emCommandStroke || "#679ac3";
		this.emEventFill = this.emEventFill || "#ffb778";
		this.emEventStroke = this.emEventStroke || "#c19a0f";
		this.emSwimlaneBackgroundOdd = this.emSwimlaneBackgroundOdd || "rgb(250,250,250)";
		this.emSwimlaneBackgroundStroke = this.emSwimlaneBackgroundStroke || "rgb(240,240,240)";
		this.emArrowhead = this.emArrowhead || this.lineColor;
		this.emRelationStroke = this.emRelationStroke || this.lineColor;
		this.attributeBackgroundColorOdd = this.attributeBackgroundColorOdd || oldAttributeBackgroundColorOdd;
		this.attributeBackgroundColorEven = this.attributeBackgroundColorEven || oldAttributeBackgroundColorEven;
	}
	calculate(overrides) {
		if (typeof overrides !== "object") {
			this.updateColors();
			return;
		}
		const keys = Object.keys(overrides);
		keys.forEach((k) => {
			this[k] = overrides[k];
		});
		this.updateColors();
		keys.forEach((k) => {
			this[k] = overrides[k];
		});
	}
};
var getThemeVariables4 = /* @__PURE__ */ __name((userOverrides) => {
	const theme = new Theme4();
	theme.calculate(userOverrides);
	return theme;
}, "getThemeVariables");
var Theme5 = class {
	static {
		__name(this, "Theme");
	}
	constructor() {
		this.primaryColor = "#eee";
		this.contrast = "#707070";
		this.secondaryColor = lighten(this.contrast, 55);
		this.background = "#ffffff";
		this.tertiaryColor = adjust(this.primaryColor, { h: -160 });
		this.primaryBorderColor = mkBorder(this.primaryColor, this.darkMode);
		this.secondaryBorderColor = mkBorder(this.secondaryColor, this.darkMode);
		this.tertiaryBorderColor = mkBorder(this.tertiaryColor, this.darkMode);
		this.primaryTextColor = invert(this.primaryColor);
		this.secondaryTextColor = invert(this.secondaryColor);
		this.tertiaryTextColor = invert(this.tertiaryColor);
		this.lineColor = invert(this.background);
		this.textColor = invert(this.background);
		this.mainBkg = "#eee";
		this.secondBkg = "calculated";
		this.lineColor = "#666";
		this.border1 = "#999";
		this.border2 = "calculated";
		this.note = "#ffa";
		this.text = "#333";
		this.critical = "#d42";
		this.done = "#bbb";
		this.arrowheadColor = "#333333";
		this.fontFamily = "\"trebuchet ms\", verdana, arial, sans-serif";
		this.fontSize = "16px";
		this.THEME_COLOR_LIMIT = 12;
		this.radius = 5;
		this.strokeWidth = 1;
		this.nodeBkg = "calculated";
		this.nodeBorder = "calculated";
		this.clusterBkg = "calculated";
		this.clusterBorder = "calculated";
		this.defaultLinkColor = "calculated";
		this.titleColor = "calculated";
		this.edgeLabelBackground = "white";
		this.actorBorder = "calculated";
		this.actorBkg = "calculated";
		this.actorTextColor = "calculated";
		this.actorLineColor = this.actorBorder;
		this.signalColor = "calculated";
		this.signalTextColor = "calculated";
		this.labelBoxBkgColor = "calculated";
		this.labelBoxBorderColor = "calculated";
		this.labelTextColor = "calculated";
		this.loopTextColor = "calculated";
		this.noteBorderColor = "calculated";
		this.noteBkgColor = "calculated";
		this.noteTextColor = "calculated";
		this.activationBorderColor = "#666";
		this.activationBkgColor = "#f4f4f4";
		this.sequenceNumberColor = "white";
		this.sectionBkgColor = "calculated";
		this.altSectionBkgColor = "white";
		this.sectionBkgColor2 = "calculated";
		this.excludeBkgColor = "#eeeeee";
		this.taskBorderColor = "calculated";
		this.taskBkgColor = "calculated";
		this.taskTextLightColor = "white";
		this.taskTextColor = "calculated";
		this.taskTextDarkColor = "calculated";
		this.taskTextOutsideColor = "calculated";
		this.taskTextClickableColor = "#003163";
		this.activeTaskBorderColor = "calculated";
		this.activeTaskBkgColor = "calculated";
		this.gridColor = "calculated";
		this.doneTaskBkgColor = "calculated";
		this.doneTaskBorderColor = "calculated";
		this.critBkgColor = "calculated";
		this.critBorderColor = "calculated";
		this.todayLineColor = "calculated";
		this.vertLineColor = "calculated";
		this.personBorder = this.primaryBorderColor;
		this.personBkg = this.mainBkg;
		this.archEdgeColor = "calculated";
		this.archEdgeArrowColor = "calculated";
		this.archEdgeWidth = "3";
		this.archGroupBorderColor = this.primaryBorderColor;
		this.archGroupBorderWidth = "2px";
		this.noteFontWeight = "normal";
		this.fontWeight = "normal";
		this.rowOdd = this.rowOdd || lighten(this.mainBkg, 75) || "#ffffff";
		this.rowEven = this.rowEven || "#f4f4f4";
		this.labelColor = "black";
		this.errorBkgColor = "#552222";
		this.errorTextColor = "#552222";
		this.useGradient = true;
		this.gradientStart = this.primaryBorderColor;
		this.gradientStop = this.secondaryBorderColor;
		this.dropShadow = "drop-shadow( 1px 2px 2px rgba(185,185,185,1))";
	}
	updateColors() {
		this.secondBkg = lighten(this.contrast, 55);
		this.border2 = this.contrast;
		this.actorBorder = lighten(this.border1, 23);
		this.actorBkg = this.mainBkg;
		this.actorTextColor = this.text;
		this.actorLineColor = this.actorBorder;
		this.signalColor = this.text;
		this.signalTextColor = this.text;
		this.labelBoxBkgColor = this.actorBkg;
		this.labelBoxBorderColor = this.actorBorder;
		this.labelTextColor = this.text;
		this.loopTextColor = this.text;
		this.noteBorderColor = "#999";
		this.noteBkgColor = "#666";
		this.noteTextColor = "#fff";
		this.cScale0 = this.cScale0 || "#555";
		this.cScale1 = this.cScale1 || "#F4F4F4";
		this.cScale2 = this.cScale2 || "#555";
		this.cScale3 = this.cScale3 || "#BBB";
		this.cScale4 = this.cScale4 || "#777";
		this.cScale5 = this.cScale5 || "#999";
		this.cScale6 = this.cScale6 || "#DDD";
		this.cScale7 = this.cScale7 || "#FFF";
		this.cScale8 = this.cScale8 || "#DDD";
		this.cScale9 = this.cScale9 || "#BBB";
		this.cScale10 = this.cScale10 || "#999";
		this.cScale11 = this.cScale11 || "#777";
		for (let i = 0; i < this.THEME_COLOR_LIMIT; i++) this["cScaleInv" + i] = this["cScaleInv" + i] || invert(this["cScale" + i]);
		for (let i = 0; i < this.THEME_COLOR_LIMIT; i++) if (this.darkMode) this["cScalePeer" + i] = this["cScalePeer" + i] || lighten(this["cScale" + i], 10);
		else this["cScalePeer" + i] = this["cScalePeer" + i] || darken(this["cScale" + i], 10);
		this.scaleLabelColor = this.scaleLabelColor || (this.darkMode ? "black" : this.labelTextColor);
		this.cScaleLabel0 = this.cScaleLabel0 || this.cScale1;
		this.cScaleLabel2 = this.cScaleLabel2 || this.cScale1;
		for (let i = 0; i < this.THEME_COLOR_LIMIT; i++) this["cScaleLabel" + i] = this["cScaleLabel" + i] || this.scaleLabelColor;
		for (let i = 0; i < 5; i++) {
			this["surface" + i] = this["surface" + i] || adjust(this.mainBkg, { l: -(5 + i * 5) });
			this["surfacePeer" + i] = this["surfacePeer" + i] || adjust(this.mainBkg, { l: -(8 + i * 5) });
		}
		this.nodeBkg = this.mainBkg;
		this.nodeBorder = this.border1;
		this.clusterBkg = this.secondBkg;
		this.clusterBorder = this.border2;
		this.defaultLinkColor = this.lineColor;
		this.titleColor = this.text;
		this.sectionBkgColor = lighten(this.contrast, 30);
		this.sectionBkgColor2 = lighten(this.contrast, 30);
		this.taskBorderColor = darken(this.contrast, 10);
		this.taskBkgColor = this.contrast;
		this.taskTextColor = this.taskTextLightColor;
		this.taskTextDarkColor = this.text;
		this.taskTextOutsideColor = this.taskTextDarkColor;
		this.activeTaskBorderColor = this.taskBorderColor;
		this.activeTaskBkgColor = this.mainBkg;
		this.gridColor = lighten(this.border1, 30);
		this.doneTaskBkgColor = this.done;
		this.doneTaskBorderColor = this.lineColor;
		this.critBkgColor = this.critical;
		this.critBorderColor = darken(this.critBkgColor, 10);
		this.todayLineColor = this.critBkgColor;
		this.vertLineColor = this.critBkgColor;
		this.archEdgeColor = this.lineColor;
		this.archEdgeArrowColor = this.lineColor;
		this.transitionColor = this.transitionColor || "#000";
		this.transitionLabelColor = this.transitionLabelColor || this.textColor;
		this.stateLabelColor = this.stateLabelColor || this.stateBkg || this.primaryTextColor;
		this.stateBkg = this.stateBkg || this.mainBkg;
		this.labelBackgroundColor = this.labelBackgroundColor || this.stateBkg;
		this.compositeBackground = this.compositeBackground || this.background || this.tertiaryColor;
		this.altBackground = this.altBackground || "#f4f4f4";
		this.compositeTitleBackground = this.compositeTitleBackground || this.mainBkg;
		this.stateBorder = this.stateBorder || "#000";
		this.innerEndBackground = this.primaryBorderColor;
		this.specialStateColor = "#222";
		this.errorBkgColor = this.errorBkgColor || this.tertiaryColor;
		this.errorTextColor = this.errorTextColor || this.tertiaryTextColor;
		this.classText = this.primaryTextColor;
		this.fillType0 = this.primaryColor;
		this.fillType1 = this.secondaryColor;
		this.fillType2 = adjust(this.primaryColor, { h: 64 });
		this.fillType3 = adjust(this.secondaryColor, { h: 64 });
		this.fillType4 = adjust(this.primaryColor, { h: -64 });
		this.fillType5 = adjust(this.secondaryColor, { h: -64 });
		this.fillType6 = adjust(this.primaryColor, { h: 128 });
		this.fillType7 = adjust(this.secondaryColor, { h: 128 });
		for (let i = 0; i < this.THEME_COLOR_LIMIT; i++) this["pie" + i] = this["cScale" + i];
		this.pie12 = this.pie0;
		this.pieTitleTextSize = this.pieTitleTextSize || "25px";
		this.pieTitleTextColor = this.pieTitleTextColor || this.taskTextDarkColor;
		this.pieSectionTextSize = this.pieSectionTextSize || "17px";
		this.pieSectionTextColor = this.pieSectionTextColor || this.textColor;
		this.pieLegendTextSize = this.pieLegendTextSize || "17px";
		this.pieLegendTextColor = this.pieLegendTextColor || this.taskTextDarkColor;
		this.pieStrokeColor = this.pieStrokeColor || "black";
		this.pieStrokeWidth = this.pieStrokeWidth || "2px";
		this.pieOuterStrokeWidth = this.pieOuterStrokeWidth || "2px";
		this.pieOuterStrokeColor = this.pieOuterStrokeColor || "black";
		this.pieOpacity = this.pieOpacity || "0.7";
		for (let i = 0; i < 8; i++) this["venn" + (i + 1)] = this["venn" + (i + 1)] ?? this["cScale" + i];
		this.vennTitleTextColor = this.vennTitleTextColor ?? this.titleColor;
		this.vennSetTextColor = this.vennSetTextColor ?? this.textColor;
		this.quadrant1Fill = this.quadrant1Fill || this.primaryColor;
		this.quadrant2Fill = this.quadrant2Fill || adjust(this.primaryColor, {
			r: 5,
			g: 5,
			b: 5
		});
		this.quadrant3Fill = this.quadrant3Fill || adjust(this.primaryColor, {
			r: 10,
			g: 10,
			b: 10
		});
		this.quadrant4Fill = this.quadrant4Fill || adjust(this.primaryColor, {
			r: 15,
			g: 15,
			b: 15
		});
		this.quadrant1TextFill = this.quadrant1TextFill || this.primaryTextColor;
		this.quadrant2TextFill = this.quadrant2TextFill || adjust(this.primaryTextColor, {
			r: -5,
			g: -5,
			b: -5
		});
		this.quadrant3TextFill = this.quadrant3TextFill || adjust(this.primaryTextColor, {
			r: -10,
			g: -10,
			b: -10
		});
		this.quadrant4TextFill = this.quadrant4TextFill || adjust(this.primaryTextColor, {
			r: -15,
			g: -15,
			b: -15
		});
		this.quadrantPointFill = this.quadrantPointFill || isDark(this.quadrant1Fill) ? lighten(this.quadrant1Fill) : darken(this.quadrant1Fill);
		this.quadrantPointTextFill = this.quadrantPointTextFill || this.primaryTextColor;
		this.quadrantXAxisTextFill = this.quadrantXAxisTextFill || this.primaryTextColor;
		this.quadrantYAxisTextFill = this.quadrantYAxisTextFill || this.primaryTextColor;
		this.quadrantInternalBorderStrokeFill = this.quadrantInternalBorderStrokeFill || this.primaryBorderColor;
		this.quadrantExternalBorderStrokeFill = this.quadrantExternalBorderStrokeFill || this.primaryBorderColor;
		this.quadrantTitleFill = this.quadrantTitleFill || this.primaryTextColor;
		this.xyChart = {
			backgroundColor: this.xyChart?.backgroundColor || this.background,
			titleColor: this.xyChart?.titleColor || this.primaryTextColor,
			dataLabelColor: this.xyChart?.dataLabelColor || this.primaryTextColor,
			xAxisTitleColor: this.xyChart?.xAxisTitleColor || this.primaryTextColor,
			xAxisLabelColor: this.xyChart?.xAxisLabelColor || this.primaryTextColor,
			xAxisTickColor: this.xyChart?.xAxisTickColor || this.primaryTextColor,
			xAxisLineColor: this.xyChart?.xAxisLineColor || this.primaryTextColor,
			yAxisTitleColor: this.xyChart?.yAxisTitleColor || this.primaryTextColor,
			yAxisLabelColor: this.xyChart?.yAxisLabelColor || this.primaryTextColor,
			yAxisTickColor: this.xyChart?.yAxisTickColor || this.primaryTextColor,
			yAxisLineColor: this.xyChart?.yAxisLineColor || this.primaryTextColor,
			plotColorPalette: this.xyChart?.plotColorPalette || "#EEE,#6BB8E4,#8ACB88,#C7ACD6,#E8DCC2,#FFB2A8,#FFF380,#7E8D91,#FFD8B1,#FAF3E0"
		};
		this.radar = {
			axisColor: this.radar?.axisColor || this.lineColor,
			axisStrokeWidth: this.radar?.axisStrokeWidth || 2,
			axisLabelFontSize: this.radar?.axisLabelFontSize || 12,
			curveOpacity: this.radar?.curveOpacity || .5,
			curveStrokeWidth: this.radar?.curveStrokeWidth || 2,
			graticuleColor: this.radar?.graticuleColor || "#DEDEDE",
			graticuleStrokeWidth: this.radar?.graticuleStrokeWidth || 1,
			graticuleOpacity: this.radar?.graticuleOpacity || .3,
			legendBoxSize: this.radar?.legendBoxSize || 12,
			legendFontSize: this.radar?.legendFontSize || 12
		};
		this.wardleyEvolutionColor = this.wardleyEvolutionColor || "#dc3545";
		this.wardley = {
			backgroundColor: this.wardley?.backgroundColor || this.background,
			axisColor: this.wardley?.axisColor || this.lineColor,
			axisTextColor: this.wardley?.axisTextColor || this.primaryTextColor,
			gridColor: this.wardley?.gridColor || this.gridColor,
			componentFill: this.wardley?.componentFill || this.background,
			componentStroke: this.wardley?.componentStroke || this.lineColor,
			componentLabelColor: this.wardley?.componentLabelColor || this.primaryTextColor,
			linkStroke: this.wardley?.linkStroke || this.lineColor,
			evolutionStroke: this.wardley?.evolutionStroke || this.wardleyEvolutionColor,
			annotationStroke: this.wardley?.annotationStroke || this.lineColor,
			annotationTextColor: this.wardley?.annotationTextColor || this.primaryTextColor,
			annotationFill: this.wardley?.annotationFill || this.background
		};
		this.requirementBackground = this.requirementBackground || this.primaryColor;
		this.requirementBorderColor = this.requirementBorderColor || this.primaryBorderColor;
		this.requirementBorderSize = this.requirementBorderSize || "1";
		this.requirementTextColor = this.requirementTextColor || this.primaryTextColor;
		this.relationColor = this.relationColor || this.lineColor;
		this.relationLabelBackground = this.relationLabelBackground || this.edgeLabelBackground;
		this.relationLabelColor = this.relationLabelColor || this.actorTextColor;
		this.git0 = darken(this.pie1, 25) || this.primaryColor;
		this.git1 = this.pie2 || this.secondaryColor;
		this.git2 = this.pie3 || this.tertiaryColor;
		this.git3 = this.pie4 || adjust(this.primaryColor, { h: -30 });
		this.git4 = this.pie5 || adjust(this.primaryColor, { h: -60 });
		this.git5 = this.pie6 || adjust(this.primaryColor, { h: -90 });
		this.git6 = this.pie7 || adjust(this.primaryColor, { h: 60 });
		this.git7 = this.pie8 || adjust(this.primaryColor, { h: 120 });
		this.gitInv0 = this.gitInv0 || invert(this.git0);
		this.gitInv1 = this.gitInv1 || invert(this.git1);
		this.gitInv2 = this.gitInv2 || invert(this.git2);
		this.gitInv3 = this.gitInv3 || invert(this.git3);
		this.gitInv4 = this.gitInv4 || invert(this.git4);
		this.gitInv5 = this.gitInv5 || invert(this.git5);
		this.gitInv6 = this.gitInv6 || invert(this.git6);
		this.gitInv7 = this.gitInv7 || invert(this.git7);
		this.branchLabelColor = this.branchLabelColor || this.labelTextColor;
		this.gitBranchLabel0 = this.branchLabelColor;
		this.gitBranchLabel1 = "white";
		this.gitBranchLabel2 = this.branchLabelColor;
		this.gitBranchLabel3 = "white";
		this.gitBranchLabel4 = this.branchLabelColor;
		this.gitBranchLabel5 = this.branchLabelColor;
		this.gitBranchLabel6 = this.branchLabelColor;
		this.gitBranchLabel7 = this.branchLabelColor;
		this.tagLabelColor = this.tagLabelColor || this.primaryTextColor;
		this.tagLabelBackground = this.tagLabelBackground || this.primaryColor;
		this.tagLabelBorder = this.tagBorder || this.primaryBorderColor;
		this.tagLabelFontSize = this.tagLabelFontSize || "10px";
		this.commitLabelColor = this.commitLabelColor || this.secondaryTextColor;
		this.commitLabelBackground = this.commitLabelBackground || this.secondaryColor;
		this.commitLabelFontSize = this.commitLabelFontSize || "10px";
		this.emUiFill = this.emUiFill || "white";
		this.emUiStroke = this.emUiStroke || "#dbdada";
		this.emProcessorFill = this.emProcessorFill || "#edb3f6";
		this.emProcessorStroke = this.emProcessorStroke || "#b88cbf";
		this.emReadModelFill = this.emReadModelFill || "#d3f1a2";
		this.emReadModelStroke = this.emReadModelStroke || "#a3b732";
		this.emCommandFill = this.emCommandFill || "#bcd6fe";
		this.emCommandStroke = this.emCommandStroke || "#679ac3";
		this.emEventFill = this.emEventFill || "#ffb778";
		this.emEventStroke = this.emEventStroke || "#c19a0f";
		this.emSwimlaneBackgroundOdd = this.emSwimlaneBackgroundOdd || "rgb(250,250,250)";
		this.emSwimlaneBackgroundStroke = this.emSwimlaneBackgroundStroke || "rgb(240,240,240)";
		this.emArrowhead = this.emArrowhead || this.lineColor;
		this.emRelationStroke = this.emRelationStroke || this.lineColor;
		this.attributeBackgroundColorOdd = this.attributeBackgroundColorOdd || oldAttributeBackgroundColorOdd;
		this.attributeBackgroundColorEven = this.attributeBackgroundColorEven || oldAttributeBackgroundColorEven;
	}
	calculate(overrides) {
		if (typeof overrides !== "object") {
			this.updateColors();
			return;
		}
		const keys = Object.keys(overrides);
		keys.forEach((k) => {
			this[k] = overrides[k];
		});
		this.updateColors();
		keys.forEach((k) => {
			this[k] = overrides[k];
		});
	}
};
var getThemeVariables5 = /* @__PURE__ */ __name((userOverrides) => {
	const theme = new Theme5();
	theme.calculate(userOverrides);
	return theme;
}, "getThemeVariables");
var Theme6 = class {
	static {
		__name(this, "Theme");
	}
	constructor() {
		this.background = "#ffffff";
		this.primaryColor = "#cccccc";
		this.mainBkg = "#ffffff";
		this.noteBkgColor = "#fff5ad";
		this.noteTextColor = "#333";
		this.THEME_COLOR_LIMIT = 12;
		this.radius = 3;
		this.strokeWidth = 2;
		this.primaryBorderColor = mkBorder(this.primaryColor, this.darkMode);
		this.fontFamily = "arial, sans-serif";
		this.fontSize = "14px";
		this.nodeBorder = "#000000";
		this.stateBorder = "#000000";
		this.useGradient = true;
		this.gradientStart = "#0042eb";
		this.gradientStop = "#eb0042";
		this.dropShadow = "drop-shadow( 0px 1px 2px rgba(0, 0, 0, 0.25));";
		this.tertiaryColor = "#ffffff";
		this.archEdgeColor = "calculated";
		this.archEdgeArrowColor = "calculated";
		this.archEdgeWidth = "3";
		this.archGroupBorderColor = this.primaryBorderColor;
		this.archGroupBorderWidth = "2px";
		this.noteFontWeight = "normal";
		this.fontWeight = "normal";
	}
	updateColors() {
		this.primaryTextColor = this.primaryTextColor || (this.darkMode ? "#eee" : "#333");
		this.secondaryColor = this.secondaryColor || adjust(this.primaryColor, { h: -120 });
		this.tertiaryColor = this.tertiaryColor || adjust(this.primaryColor, {
			h: 180,
			l: 5
		});
		this.primaryBorderColor = this.primaryBorderColor || mkBorder(this.primaryColor, this.darkMode);
		this.secondaryBorderColor = this.secondaryBorderColor || mkBorder(this.secondaryColor, this.darkMode);
		this.tertiaryBorderColor = this.tertiaryBorderColor || mkBorder(this.tertiaryColor, this.darkMode);
		this.noteBorderColor = this.noteBorderColor || mkBorder(this.noteBkgColor, this.darkMode);
		this.noteBkgColor = this.noteBkgColor || "#fff5ad";
		this.noteTextColor = this.noteTextColor || "#333";
		this.secondaryTextColor = this.secondaryTextColor || invert(this.secondaryColor);
		this.tertiaryTextColor = this.tertiaryTextColor || invert(this.tertiaryColor);
		this.lineColor = this.lineColor || invert(this.background);
		this.arrowheadColor = this.arrowheadColor || invert(this.background);
		this.textColor = this.textColor || this.primaryTextColor;
		this.border2 = this.border2 || this.tertiaryBorderColor;
		this.nodeBkg = this.nodeBkg || this.primaryColor;
		this.mainBkg = this.mainBkg || this.primaryColor;
		this.nodeBorder = this.nodeBorder || this.primaryBorderColor;
		this.clusterBkg = this.clusterBkg || this.tertiaryColor;
		this.clusterBorder = this.clusterBorder || this.tertiaryBorderColor;
		this.defaultLinkColor = this.defaultLinkColor || this.lineColor;
		this.titleColor = this.titleColor || this.tertiaryTextColor;
		this.edgeLabelBackground = this.edgeLabelBackground || (this.darkMode ? darken(this.secondaryColor, 30) : this.secondaryColor);
		this.nodeTextColor = this.nodeTextColor || this.primaryTextColor;
		this.actorBorder = this.actorBorder || this.primaryBorderColor;
		this.actorBkg = this.actorBkg || this.mainBkg;
		this.actorTextColor = this.actorTextColor || this.primaryTextColor;
		this.actorLineColor = this.actorLineColor || this.actorBorder;
		this.labelBoxBkgColor = this.labelBoxBkgColor || this.actorBkg;
		this.signalColor = this.signalColor || this.textColor;
		this.signalTextColor = this.signalTextColor || this.textColor;
		this.labelBoxBorderColor = this.labelBoxBorderColor || this.actorBorder;
		this.labelTextColor = this.labelTextColor || this.actorTextColor;
		this.loopTextColor = this.loopTextColor || this.actorTextColor;
		this.activationBorderColor = this.activationBorderColor || darken(this.secondaryColor, 10);
		this.activationBkgColor = this.activationBkgColor || this.secondaryColor;
		this.sequenceNumberColor = this.sequenceNumberColor || invert(this.lineColor);
		const primaryColor = "#ECECFE";
		const secondaryColor = "#E9E9F1";
		const tertiaryColor = adjust(primaryColor, {
			h: 180,
			l: 5
		});
		this.sectionBkgColor = this.sectionBkgColor || tertiaryColor;
		this.altSectionBkgColor = this.altSectionBkgColor || "white";
		this.sectionBkgColor = this.sectionBkgColor || secondaryColor;
		this.sectionBkgColor2 = this.sectionBkgColor2 || primaryColor;
		this.excludeBkgColor = this.excludeBkgColor || "#eeeeee";
		this.taskBorderColor = this.taskBorderColor || this.primaryBorderColor;
		this.taskBkgColor = this.taskBkgColor || primaryColor;
		this.activeTaskBorderColor = this.activeTaskBorderColor || primaryColor;
		this.activeTaskBkgColor = this.activeTaskBkgColor || lighten(primaryColor, 23);
		this.gridColor = this.gridColor || "lightgrey";
		this.doneTaskBkgColor = this.doneTaskBkgColor || "lightgrey";
		this.doneTaskBorderColor = this.doneTaskBorderColor || "grey";
		this.critBorderColor = this.critBorderColor || "#ff8888";
		this.critBkgColor = this.critBkgColor || "red";
		this.todayLineColor = this.todayLineColor || "red";
		this.taskTextColor = this.taskTextColor || this.textColor;
		this.taskTextOutsideColor = this.taskTextOutsideColor || this.textColor;
		this.vertLineColor = this.vertLineColor || this.primaryBorderColor;
		this.taskTextLightColor = this.taskTextLightColor || this.textColor;
		this.taskTextColor = this.taskTextColor || this.primaryTextColor;
		this.taskTextDarkColor = this.taskTextDarkColor || this.textColor;
		this.taskTextClickableColor = this.taskTextClickableColor || "#003163";
		this.archEdgeColor = this.lineColor;
		this.archEdgeArrowColor = this.lineColor;
		this.personBorder = this.personBorder || this.primaryBorderColor;
		this.personBkg = this.personBkg || this.mainBkg;
		this.transitionColor = this.transitionColor || this.lineColor;
		this.transitionLabelColor = this.transitionLabelColor || this.textColor;
		this.stateLabelColor = this.stateLabelColor || this.stateBkg || this.primaryTextColor;
		this.stateBkg = this.stateBkg || this.mainBkg;
		this.labelBackgroundColor = this.labelBackgroundColor || this.stateBkg;
		this.compositeBackground = this.compositeBackground || this.background || this.tertiaryColor;
		this.altBackground = this.altBackground || "#f0f0f0";
		this.compositeTitleBackground = this.compositeTitleBackground || this.mainBkg;
		this.compositeBorder = this.compositeBorder || this.nodeBorder;
		this.innerEndBackground = this.nodeBorder;
		this.errorBkgColor = this.errorBkgColor || this.tertiaryColor;
		this.errorTextColor = this.errorTextColor || this.tertiaryTextColor;
		this.transitionColor = this.transitionColor || this.lineColor;
		this.specialStateColor = this.lineColor;
		this.cScale0 = this.cScale0 || primaryColor;
		this.cScale1 = this.cScale1 || secondaryColor;
		this.cScale2 = this.cScale2 || tertiaryColor;
		this.cScale3 = this.cScale3 || adjust(primaryColor, { h: 30 });
		this.cScale4 = this.cScale4 || adjust(primaryColor, { h: 60 });
		this.cScale5 = this.cScale5 || adjust(primaryColor, { h: 90 });
		this.cScale6 = this.cScale6 || adjust(primaryColor, { h: 120 });
		this.cScale7 = this.cScale7 || adjust(primaryColor, { h: 150 });
		this.cScale8 = this.cScale8 || adjust(primaryColor, {
			h: 210,
			l: 150
		});
		this.cScale9 = this.cScale9 || adjust(primaryColor, { h: 270 });
		this.cScale10 = this.cScale10 || adjust(primaryColor, { h: 300 });
		this.cScale11 = this.cScale11 || adjust(primaryColor, { h: 330 });
		if (this.darkMode) for (let i = 0; i < this.THEME_COLOR_LIMIT; i++) this["cScale" + i] = darken(this["cScale" + i], 75);
		else for (let i = 0; i < this.THEME_COLOR_LIMIT; i++) this["cScale" + i] = darken(this["cScale" + i], 25);
		for (let i = 0; i < this.THEME_COLOR_LIMIT; i++) this["cScaleInv" + i] = this["cScaleInv" + i] || invert(this["cScale" + i]);
		for (let i = 0; i < this.THEME_COLOR_LIMIT; i++) if (this.darkMode) this["cScalePeer" + i] = this["cScalePeer" + i] || lighten(this["cScale" + i], 10);
		else this["cScalePeer" + i] = this["cScalePeer" + i] || darken(this["cScale" + i], 10);
		this.scaleLabelColor = this.scaleLabelColor || this.labelTextColor;
		for (let i = 0; i < this.THEME_COLOR_LIMIT; i++) this["cScaleLabel" + i] = this["cScaleLabel" + i] || this.scaleLabelColor;
		const multiplier = this.darkMode ? -4 : -1;
		for (let i = 0; i < 5; i++) {
			this["surface" + i] = this["surface" + i] || adjust(this.mainBkg, {
				h: 180,
				s: -15,
				l: multiplier * (5 + i * 3)
			});
			this["surfacePeer" + i] = this["surfacePeer" + i] || adjust(this.mainBkg, {
				h: 180,
				s: -15,
				l: multiplier * (8 + i * 3)
			});
		}
		this.classText = this.classText || this.textColor;
		this.fillType0 = this.fillType0 || primaryColor;
		this.fillType1 = this.fillType1 || secondaryColor;
		this.fillType2 = this.fillType2 || adjust(primaryColor, { h: 64 });
		this.fillType3 = this.fillType3 || adjust(secondaryColor, { h: 64 });
		this.fillType4 = this.fillType4 || adjust(primaryColor, { h: -64 });
		this.fillType5 = this.fillType5 || adjust(secondaryColor, { h: -64 });
		this.fillType6 = this.fillType6 || adjust(primaryColor, { h: 128 });
		this.fillType7 = this.fillType7 || adjust(secondaryColor, { h: 128 });
		this.pie1 = this.pie1 || primaryColor;
		this.pie2 = this.pie2 || secondaryColor;
		this.pie3 = this.pie3 || tertiaryColor;
		this.pie4 = this.pie4 || adjust(primaryColor, { l: -10 });
		this.pie5 = this.pie5 || adjust(secondaryColor, { l: -10 });
		this.pie6 = this.pie6 || adjust(tertiaryColor, { l: -10 });
		this.pie7 = this.pie7 || adjust(primaryColor, {
			h: 60,
			l: -10
		});
		this.pie8 = this.pie8 || adjust(primaryColor, {
			h: -60,
			l: -10
		});
		this.pie9 = this.pie9 || adjust(primaryColor, {
			h: 120,
			l: 0
		});
		this.pie10 = this.pie10 || adjust(primaryColor, {
			h: 60,
			l: -20
		});
		this.pie11 = this.pie11 || adjust(primaryColor, {
			h: -60,
			l: -20
		});
		this.pie12 = this.pie12 || adjust(primaryColor, {
			h: 120,
			l: -10
		});
		this.pieTitleTextSize = this.pieTitleTextSize || "25px";
		this.pieTitleTextColor = this.pieTitleTextColor || this.taskTextDarkColor;
		this.pieSectionTextSize = this.pieSectionTextSize || "17px";
		this.pieSectionTextColor = this.pieSectionTextColor || this.textColor;
		this.pieLegendTextSize = this.pieLegendTextSize || "17px";
		this.pieLegendTextColor = this.pieLegendTextColor || this.taskTextDarkColor;
		this.pieStrokeColor = this.pieStrokeColor || "black";
		this.pieStrokeWidth = this.pieStrokeWidth || "2px";
		this.pieOuterStrokeWidth = this.pieOuterStrokeWidth || "2px";
		this.pieOuterStrokeColor = this.pieOuterStrokeColor || "black";
		this.pieOpacity = this.pieOpacity || "0.7";
		this.vennTitleTextColor = this.vennTitleTextColor ?? this.titleColor;
		this.vennSetTextColor = this.vennSetTextColor ?? this.textColor;
		this.quadrant1Fill = this.quadrant1Fill || primaryColor;
		this.quadrant2Fill = this.quadrant2Fill || adjust(primaryColor, {
			r: 5,
			g: 5,
			b: 5
		});
		this.quadrant3Fill = this.quadrant3Fill || adjust(primaryColor, {
			r: 10,
			g: 10,
			b: 10
		});
		this.quadrant4Fill = this.quadrant4Fill || adjust(primaryColor, {
			r: 15,
			g: 15,
			b: 15
		});
		this.quadrant1TextFill = this.quadrant1TextFill || this.primaryTextColor;
		this.quadrant2TextFill = this.quadrant2TextFill || adjust(this.primaryTextColor, {
			r: -5,
			g: -5,
			b: -5
		});
		this.quadrant3TextFill = this.quadrant3TextFill || adjust(this.primaryTextColor, {
			r: -10,
			g: -10,
			b: -10
		});
		this.quadrant4TextFill = this.quadrant4TextFill || adjust(this.primaryTextColor, {
			r: -15,
			g: -15,
			b: -15
		});
		this.quadrantPointFill = this.quadrantPointFill || isDark(this.quadrant1Fill) ? lighten(this.quadrant1Fill) : darken(this.quadrant1Fill);
		this.quadrantPointTextFill = this.quadrantPointTextFill || this.primaryTextColor;
		this.quadrantXAxisTextFill = this.quadrantXAxisTextFill || this.primaryTextColor;
		this.quadrantYAxisTextFill = this.quadrantYAxisTextFill || this.primaryTextColor;
		this.quadrantInternalBorderStrokeFill = this.quadrantInternalBorderStrokeFill || this.primaryBorderColor;
		this.quadrantExternalBorderStrokeFill = this.quadrantExternalBorderStrokeFill || this.primaryBorderColor;
		this.quadrantTitleFill = this.quadrantTitleFill || this.primaryTextColor;
		this.xyChart = {
			backgroundColor: this.xyChart?.backgroundColor || this.background,
			titleColor: this.xyChart?.titleColor || this.primaryTextColor,
			xAxisTitleColor: this.xyChart?.xAxisTitleColor || this.primaryTextColor,
			xAxisLabelColor: this.xyChart?.xAxisLabelColor || this.primaryTextColor,
			xAxisTickColor: this.xyChart?.xAxisTickColor || this.primaryTextColor,
			xAxisLineColor: this.xyChart?.xAxisLineColor || this.primaryTextColor,
			yAxisTitleColor: this.xyChart?.yAxisTitleColor || this.primaryTextColor,
			yAxisLabelColor: this.xyChart?.yAxisLabelColor || this.primaryTextColor,
			yAxisTickColor: this.xyChart?.yAxisTickColor || this.primaryTextColor,
			yAxisLineColor: this.xyChart?.yAxisLineColor || this.primaryTextColor,
			plotColorPalette: this.xyChart?.plotColorPalette || "#FFF4DD,#FFD8B1,#FFA07A,#ECEFF1,#D6DBDF,#C3E0A8,#FFB6A4,#FFD74D,#738FA7,#FFFFF0"
		};
		this.requirementBackground = this.requirementBackground || primaryColor;
		this.requirementBorderColor = this.requirementBorderColor || this.primaryBorderColor;
		this.requirementBorderSize = this.requirementBorderSize || "1";
		this.requirementTextColor = this.requirementTextColor || this.primaryTextColor;
		this.relationColor = this.relationColor || this.lineColor;
		this.relationLabelBackground = this.relationLabelBackground || (this.darkMode ? darken(this.secondaryColor, 30) : this.secondaryColor);
		this.relationLabelColor = this.relationLabelColor || this.actorTextColor;
		this.git0 = this.git0 || primaryColor;
		this.git1 = this.git1 || secondaryColor;
		this.git2 = this.git2 || tertiaryColor;
		this.git3 = this.git3 || adjust(primaryColor, { h: -30 });
		this.git4 = this.git4 || adjust(primaryColor, { h: -60 });
		this.git5 = this.git5 || adjust(primaryColor, { h: -90 });
		this.git6 = this.git6 || adjust(primaryColor, { h: 60 });
		this.git7 = this.git7 || adjust(primaryColor, { h: 120 });
		if (this.darkMode) {
			this.git0 = lighten(this.git0, 25);
			this.git1 = lighten(this.git1, 25);
			this.git2 = lighten(this.git2, 25);
			this.git3 = lighten(this.git3, 25);
			this.git4 = lighten(this.git4, 25);
			this.git5 = lighten(this.git5, 25);
			this.git6 = lighten(this.git6, 25);
			this.git7 = lighten(this.git7, 25);
		} else {
			this.git0 = darken(this.git0, 25);
			this.git1 = darken(this.git1, 25);
			this.git2 = darken(this.git2, 25);
			this.git3 = darken(this.git3, 25);
			this.git4 = darken(this.git4, 25);
			this.git5 = darken(this.git5, 25);
			this.git6 = darken(this.git6, 25);
			this.git7 = darken(this.git7, 25);
		}
		this.gitInv0 = this.gitInv0 || invert(this.git0);
		this.gitInv1 = this.gitInv1 || invert(this.git1);
		this.gitInv2 = this.gitInv2 || invert(this.git2);
		this.gitInv3 = this.gitInv3 || invert(this.git3);
		this.gitInv4 = this.gitInv4 || invert(this.git4);
		this.gitInv5 = this.gitInv5 || invert(this.git5);
		this.gitInv6 = this.gitInv6 || invert(this.git6);
		this.gitInv7 = this.gitInv7 || invert(this.git7);
		this.branchLabelColor = this.branchLabelColor || (this.darkMode ? "black" : this.labelTextColor);
		this.gitBranchLabel0 = this.gitBranchLabel0 || this.branchLabelColor;
		this.gitBranchLabel1 = this.gitBranchLabel1 || this.branchLabelColor;
		this.gitBranchLabel2 = this.gitBranchLabel2 || this.branchLabelColor;
		this.gitBranchLabel3 = this.gitBranchLabel3 || this.branchLabelColor;
		this.gitBranchLabel4 = this.gitBranchLabel4 || this.branchLabelColor;
		this.gitBranchLabel5 = this.gitBranchLabel5 || this.branchLabelColor;
		this.gitBranchLabel6 = this.gitBranchLabel6 || this.branchLabelColor;
		this.gitBranchLabel7 = this.gitBranchLabel7 || this.branchLabelColor;
		this.tagLabelColor = this.tagLabelColor || this.primaryTextColor;
		this.tagLabelBackground = this.tagLabelBackground || this.primaryColor;
		this.tagLabelBorder = this.tagBorder || this.primaryBorderColor;
		this.tagLabelFontSize = this.tagLabelFontSize || "10px";
		this.commitLabelColor = this.commitLabelColor || this.secondaryTextColor;
		this.commitLabelBackground = this.commitLabelBackground || this.secondaryColor;
		this.commitLabelFontSize = this.commitLabelFontSize || "10px";
		this.attributeBackgroundColorOdd = this.attributeBackgroundColorOdd || oldAttributeBackgroundColorOdd;
		this.attributeBackgroundColorEven = this.attributeBackgroundColorEven || oldAttributeBackgroundColorEven;
	}
	calculate(overrides) {
		if (typeof overrides !== "object") {
			this.updateColors();
			return;
		}
		const keys = Object.keys(overrides);
		keys.forEach((k) => {
			this[k] = overrides[k];
		});
		this.updateColors();
		keys.forEach((k) => {
			this[k] = overrides[k];
		});
	}
};
var getThemeVariables6 = /* @__PURE__ */ __name((userOverrides) => {
	const theme = new Theme6();
	theme.calculate(userOverrides);
	return theme;
}, "getThemeVariables");
var Theme7 = class {
	static {
		__name(this, "Theme");
	}
	constructor() {
		this.background = "#333";
		this.primaryColor = "#1f2020";
		this.secondaryColor = lighten(this.primaryColor, 16);
		this.tertiaryColor = adjust(this.primaryColor, { h: -160 });
		this.primaryBorderColor = invert(this.background);
		this.secondaryBorderColor = mkBorder(this.secondaryColor, this.darkMode);
		this.tertiaryBorderColor = mkBorder(this.tertiaryColor, this.darkMode);
		this.primaryTextColor = invert(this.primaryColor);
		this.secondaryTextColor = invert(this.secondaryColor);
		this.tertiaryTextColor = invert(this.tertiaryColor);
		this.mainBkg = "#2a2020";
		this.secondBkg = "calculated";
		this.mainContrastColor = "lightgrey";
		this.darkTextColor = lighten(invert("#323D47"), 10);
		this.border1 = "#ccc";
		this.border2 = rgba(255, 255, 255, .25);
		this.arrowheadColor = invert(this.background);
		this.fontFamily = "arial, sans-serif";
		this.fontSize = "14px";
		this.labelBackground = "#181818";
		this.textColor = "#ccc";
		this.THEME_COLOR_LIMIT = 12;
		this.radius = 3;
		this.strokeWidth = 1;
		this.noteBkgColor = "#fff5ad";
		this.noteTextColor = "#333";
		this.THEME_COLOR_LIMIT = 12;
		this.fontFamily = "arial, sans-serif";
		this.fontSize = "14px";
		this.useGradient = true;
		this.gradientStart = "#0042eb";
		this.gradientStop = "#eb0042";
		this.dropShadow = "drop-shadow( 1px 2px 2px rgba(185,185,185,0.2))";
		this.archEdgeColor = "calculated";
		this.archEdgeArrowColor = "calculated";
		this.archEdgeWidth = "3";
		this.archGroupBorderColor = this.primaryBorderColor;
		this.archGroupBorderWidth = "2px";
		this.noteFontWeight = "normal";
		this.fontWeight = "normal";
	}
	updateColors() {
		this.primaryTextColor = this.primaryTextColor || (this.darkMode ? "#eee" : "#333");
		this.secondaryColor = this.secondaryColor || adjust(this.primaryColor, { h: -120 });
		this.tertiaryColor = this.tertiaryColor || adjust(this.primaryColor, {
			h: 180,
			l: 5
		});
		this.primaryBorderColor = this.primaryBorderColor || mkBorder(this.primaryColor, this.darkMode);
		this.secondaryBorderColor = this.secondaryBorderColor || mkBorder(this.secondaryColor, this.darkMode);
		this.tertiaryBorderColor = this.tertiaryBorderColor || mkBorder(this.tertiaryColor, this.darkMode);
		this.noteBorderColor = this.noteBorderColor || mkBorder(this.noteBkgColor, this.darkMode);
		this.noteBkgColor = this.noteBkgColor || "#fff5ad";
		this.noteTextColor = this.noteTextColor || "#333";
		this.secondaryTextColor = this.secondaryTextColor || invert(this.secondaryColor);
		this.tertiaryTextColor = this.tertiaryTextColor || invert(this.tertiaryColor);
		this.lineColor = this.lineColor || invert(this.background);
		this.arrowheadColor = this.arrowheadColor || invert(this.background);
		this.textColor = this.textColor || this.primaryTextColor;
		this.border2 = this.border2 || this.tertiaryBorderColor;
		this.nodeBkg = this.nodeBkg || this.primaryColor;
		this.mainBkg = this.mainBkg || this.primaryColor;
		this.nodeBorder = this.nodeBorder || this.border1;
		this.clusterBkg = this.clusterBkg || this.tertiaryColor;
		this.clusterBorder = this.clusterBorder || this.tertiaryBorderColor;
		this.defaultLinkColor = this.defaultLinkColor || this.lineColor;
		this.titleColor = this.titleColor || this.tertiaryTextColor;
		this.edgeLabelBackground = this.edgeLabelBackground || (this.darkMode ? darken(this.secondaryColor, 30) : this.secondaryColor);
		this.nodeTextColor = this.nodeTextColor || this.primaryTextColor;
		this.actorBorder = this.actorBorder || this.primaryBorderColor;
		this.actorBkg = this.actorBkg || this.mainBkg;
		this.actorTextColor = this.actorTextColor || this.primaryTextColor;
		this.actorLineColor = this.actorLineColor || this.actorBorder;
		this.labelBoxBkgColor = this.labelBoxBkgColor || this.actorBkg;
		this.signalColor = this.signalColor || this.textColor;
		this.signalTextColor = this.signalTextColor || this.textColor;
		this.labelBoxBorderColor = this.labelBoxBorderColor || this.actorBorder;
		this.labelTextColor = this.labelTextColor || this.actorTextColor;
		this.loopTextColor = this.loopTextColor || this.actorTextColor;
		this.activationBorderColor = this.activationBorderColor || darken(this.secondaryColor, 10);
		this.activationBkgColor = this.activationBkgColor || this.secondaryColor;
		this.sequenceNumberColor = this.sequenceNumberColor || invert(this.lineColor);
		this.sectionBkgColor = this.sectionBkgColor || this.tertiaryColor;
		this.altSectionBkgColor = this.altSectionBkgColor || "white";
		this.sectionBkgColor = this.sectionBkgColor || this.secondaryColor;
		this.sectionBkgColor2 = this.sectionBkgColor2 || this.primaryColor;
		this.excludeBkgColor = this.excludeBkgColor || "#eeeeee";
		this.taskBorderColor = this.taskBorderColor || this.primaryBorderColor;
		this.taskBkgColor = this.taskBkgColor || this.primaryColor;
		this.activeTaskBorderColor = this.activeTaskBorderColor || this.primaryColor;
		this.activeTaskBkgColor = this.activeTaskBkgColor || lighten(this.primaryColor, 23);
		this.gridColor = this.gridColor || "lightgrey";
		this.doneTaskBkgColor = this.doneTaskBkgColor || "lightgrey";
		this.doneTaskBorderColor = this.doneTaskBorderColor || "grey";
		this.critBorderColor = this.critBorderColor || "#ff8888";
		this.critBkgColor = this.critBkgColor || "red";
		this.todayLineColor = this.todayLineColor || "red";
		this.vertLineColor = this.vertLineColor || this.primaryBorderColor;
		this.taskTextColor = this.taskTextColor || this.textColor;
		this.taskTextOutsideColor = this.taskTextOutsideColor || this.textColor;
		this.taskTextLightColor = this.taskTextLightColor || this.textColor;
		this.taskTextColor = this.taskTextColor || this.primaryTextColor;
		this.taskTextDarkColor = this.taskTextDarkColor || this.textColor;
		this.taskTextClickableColor = this.taskTextClickableColor || "#003163";
		this.archEdgeColor = this.lineColor;
		this.archEdgeArrowColor = this.lineColor;
		this.personBorder = this.personBorder || this.primaryBorderColor;
		this.personBkg = this.personBkg || this.mainBkg;
		this.transitionColor = this.transitionColor || this.lineColor;
		this.transitionLabelColor = this.transitionLabelColor || this.textColor;
		this.stateLabelColor = this.stateLabelColor || this.stateBkg || this.primaryTextColor;
		this.stateBkg = this.stateBkg || this.mainBkg;
		this.labelBackgroundColor = this.labelBackgroundColor || this.stateBkg;
		this.compositeBackground = this.compositeBackground || this.background || this.tertiaryColor;
		this.altBackground = this.altBackground || "#f0f0f0";
		this.compositeTitleBackground = this.compositeTitleBackground || this.mainBkg;
		this.compositeBorder = this.compositeBorder || this.nodeBorder;
		this.innerEndBackground = this.nodeBorder;
		this.errorBkgColor = this.errorBkgColor || this.tertiaryColor;
		this.errorTextColor = this.errorTextColor || this.tertiaryTextColor;
		this.transitionColor = this.transitionColor || this.lineColor;
		this.specialStateColor = this.lineColor;
		this.cScale0 = this.cScale0 || this.primaryColor;
		this.cScale1 = this.cScale1 || this.secondaryColor;
		this.cScale2 = this.cScale2 || this.tertiaryColor;
		this.cScale3 = this.cScale3 || adjust(this.primaryColor, { h: 30 });
		this.cScale4 = this.cScale4 || adjust(this.primaryColor, { h: 60 });
		this.cScale5 = this.cScale5 || adjust(this.primaryColor, { h: 90 });
		this.cScale6 = this.cScale6 || adjust(this.primaryColor, { h: 120 });
		this.cScale7 = this.cScale7 || adjust(this.primaryColor, { h: 150 });
		this.cScale8 = this.cScale8 || adjust(this.primaryColor, {
			h: 210,
			l: 150
		});
		this.cScale9 = this.cScale9 || adjust(this.primaryColor, { h: 270 });
		this.cScale10 = this.cScale10 || adjust(this.primaryColor, { h: 300 });
		this.cScale11 = this.cScale11 || adjust(this.primaryColor, { h: 330 });
		if (this.darkMode) for (let i = 0; i < this.THEME_COLOR_LIMIT; i++) this["cScale" + i] = darken(this["cScale" + i], 75);
		else for (let i = 0; i < this.THEME_COLOR_LIMIT; i++) this["cScale" + i] = darken(this["cScale" + i], 25);
		for (let i = 0; i < this.THEME_COLOR_LIMIT; i++) this["cScaleInv" + i] = this["cScaleInv" + i] || invert(this["cScale" + i]);
		for (let i = 0; i < this.THEME_COLOR_LIMIT; i++) if (this.darkMode) this["cScalePeer" + i] = this["cScalePeer" + i] || lighten(this["cScale" + i], 10);
		else this["cScalePeer" + i] = this["cScalePeer" + i] || darken(this["cScale" + i], 10);
		this.scaleLabelColor = this.scaleLabelColor || this.labelTextColor;
		for (let i = 0; i < this.THEME_COLOR_LIMIT; i++) this["cScaleLabel" + i] = this["cScaleLabel" + i] || this.scaleLabelColor;
		const multiplier = this.darkMode ? -4 : -1;
		for (let i = 0; i < 5; i++) {
			this["surface" + i] = this["surface" + i] || adjust(this.mainBkg, {
				h: 180,
				s: -15,
				l: multiplier * (5 + i * 3)
			});
			this["surfacePeer" + i] = this["surfacePeer" + i] || adjust(this.mainBkg, {
				h: 180,
				s: -15,
				l: multiplier * (8 + i * 3)
			});
		}
		this.classText = this.classText || this.textColor;
		this.fillType0 = this.fillType0 || this.primaryColor;
		this.fillType1 = this.fillType1 || this.secondaryColor;
		this.fillType2 = this.fillType2 || adjust(this.primaryColor, { h: 64 });
		this.fillType3 = this.fillType3 || adjust(this.secondaryColor, { h: 64 });
		this.fillType4 = this.fillType4 || adjust(this.primaryColor, { h: -64 });
		this.fillType5 = this.fillType5 || adjust(this.secondaryColor, { h: -64 });
		this.fillType6 = this.fillType6 || adjust(this.primaryColor, { h: 128 });
		this.fillType7 = this.fillType7 || adjust(this.secondaryColor, { h: 128 });
		this.pie1 = this.pie1 || this.primaryColor;
		this.pie2 = this.pie2 || this.secondaryColor;
		this.pie3 = this.pie3 || this.tertiaryColor;
		this.pie4 = this.pie4 || adjust(this.primaryColor, { l: -10 });
		this.pie5 = this.pie5 || adjust(this.secondaryColor, { l: -10 });
		this.pie6 = this.pie6 || adjust(this.tertiaryColor, { l: -10 });
		this.pie7 = this.pie7 || adjust(this.primaryColor, {
			h: 60,
			l: -10
		});
		this.pie8 = this.pie8 || adjust(this.primaryColor, {
			h: -60,
			l: -10
		});
		this.pie9 = this.pie9 || adjust(this.primaryColor, {
			h: 120,
			l: 0
		});
		this.pie10 = this.pie10 || adjust(this.primaryColor, {
			h: 60,
			l: -20
		});
		this.pie11 = this.pie11 || adjust(this.primaryColor, {
			h: -60,
			l: -20
		});
		this.pie12 = this.pie12 || adjust(this.primaryColor, {
			h: 120,
			l: -10
		});
		this.pieTitleTextSize = this.pieTitleTextSize || "25px";
		this.pieTitleTextColor = this.pieTitleTextColor || this.taskTextDarkColor;
		this.pieSectionTextSize = this.pieSectionTextSize || "17px";
		this.pieSectionTextColor = this.pieSectionTextColor || this.textColor;
		this.pieLegendTextSize = this.pieLegendTextSize || "17px";
		this.pieLegendTextColor = this.pieLegendTextColor || this.taskTextDarkColor;
		this.pieStrokeColor = this.pieStrokeColor || "black";
		this.pieStrokeWidth = this.pieStrokeWidth || "2px";
		this.pieOuterStrokeWidth = this.pieOuterStrokeWidth || "2px";
		this.pieOuterStrokeColor = this.pieOuterStrokeColor || "black";
		this.pieOpacity = this.pieOpacity || "0.7";
		this.vennTitleTextColor = this.vennTitleTextColor ?? this.titleColor;
		this.vennSetTextColor = this.vennSetTextColor ?? this.textColor;
		this.quadrant1Fill = this.quadrant1Fill || this.primaryColor;
		this.quadrant2Fill = this.quadrant2Fill || adjust(this.primaryColor, {
			r: 5,
			g: 5,
			b: 5
		});
		this.quadrant3Fill = this.quadrant3Fill || adjust(this.primaryColor, {
			r: 10,
			g: 10,
			b: 10
		});
		this.quadrant4Fill = this.quadrant4Fill || adjust(this.primaryColor, {
			r: 15,
			g: 15,
			b: 15
		});
		this.quadrant1TextFill = this.quadrant1TextFill || this.primaryTextColor;
		this.quadrant2TextFill = this.quadrant2TextFill || adjust(this.primaryTextColor, {
			r: -5,
			g: -5,
			b: -5
		});
		this.quadrant3TextFill = this.quadrant3TextFill || adjust(this.primaryTextColor, {
			r: -10,
			g: -10,
			b: -10
		});
		this.quadrant4TextFill = this.quadrant4TextFill || adjust(this.primaryTextColor, {
			r: -15,
			g: -15,
			b: -15
		});
		this.quadrantPointFill = this.quadrantPointFill || isDark(this.quadrant1Fill) ? lighten(this.quadrant1Fill) : darken(this.quadrant1Fill);
		this.quadrantPointTextFill = this.quadrantPointTextFill || this.primaryTextColor;
		this.quadrantXAxisTextFill = this.quadrantXAxisTextFill || this.primaryTextColor;
		this.quadrantYAxisTextFill = this.quadrantYAxisTextFill || this.primaryTextColor;
		this.quadrantInternalBorderStrokeFill = this.quadrantInternalBorderStrokeFill || this.primaryBorderColor;
		this.quadrantExternalBorderStrokeFill = this.quadrantExternalBorderStrokeFill || this.primaryBorderColor;
		this.quadrantTitleFill = this.quadrantTitleFill || this.primaryTextColor;
		this.xyChart = {
			backgroundColor: this.xyChart?.backgroundColor || this.background,
			titleColor: this.xyChart?.titleColor || this.primaryTextColor,
			xAxisTitleColor: this.xyChart?.xAxisTitleColor || this.primaryTextColor,
			xAxisLabelColor: this.xyChart?.xAxisLabelColor || this.primaryTextColor,
			xAxisTickColor: this.xyChart?.xAxisTickColor || this.primaryTextColor,
			xAxisLineColor: this.xyChart?.xAxisLineColor || this.primaryTextColor,
			yAxisTitleColor: this.xyChart?.yAxisTitleColor || this.primaryTextColor,
			yAxisLabelColor: this.xyChart?.yAxisLabelColor || this.primaryTextColor,
			yAxisTickColor: this.xyChart?.yAxisTickColor || this.primaryTextColor,
			yAxisLineColor: this.xyChart?.yAxisLineColor || this.primaryTextColor,
			plotColorPalette: this.xyChart?.plotColorPalette || "#FFF4DD,#FFD8B1,#FFA07A,#ECEFF1,#D6DBDF,#C3E0A8,#FFB6A4,#FFD74D,#738FA7,#FFFFF0"
		};
		this.requirementBackground = this.requirementBackground || this.primaryColor;
		this.requirementBorderColor = this.requirementBorderColor || this.primaryBorderColor;
		this.requirementBorderSize = this.requirementBorderSize || "1";
		this.requirementTextColor = this.requirementTextColor || this.primaryTextColor;
		this.relationColor = this.relationColor || this.lineColor;
		this.relationLabelBackground = this.relationLabelBackground || (this.darkMode ? darken(this.secondaryColor, 30) : this.secondaryColor);
		this.relationLabelColor = this.relationLabelColor || this.actorTextColor;
		this.git0 = this.git0 || "#0b0000";
		this.git1 = this.git1 || "#4d1037";
		this.git2 = this.git2 || "#3f5258";
		this.git3 = this.git3 || "#4f2f1b";
		this.git4 = this.git4 || "#6e0a0a";
		this.git5 = this.git5 || "#3b0048";
		this.git6 = this.git6 || "#995a01";
		this.git7 = this.git7 || "#154706";
		this.gitDarkMode = true;
		if (this.gitDarkMode) {
			this.git0 = lighten(this.git0, 25);
			this.git1 = lighten(this.git1, 25);
			this.git2 = lighten(this.git2, 25);
			this.git3 = lighten(this.git3, 25);
			this.git4 = lighten(this.git4, 25);
			this.git5 = lighten(this.git5, 25);
			this.git6 = lighten(this.git6, 25);
			this.git7 = lighten(this.git7, 25);
		} else {
			this.git0 = darken(this.git0, 25);
			this.git1 = darken(this.git1, 25);
			this.git2 = darken(this.git2, 25);
			this.git3 = darken(this.git3, 25);
			this.git4 = darken(this.git4, 25);
			this.git5 = darken(this.git5, 25);
			this.git6 = darken(this.git6, 25);
			this.git7 = darken(this.git7, 25);
		}
		this.gitInv0 = this.gitInv0 || invert(this.git0);
		this.gitInv1 = this.gitInv1 || invert(this.git1);
		this.gitInv2 = this.gitInv2 || invert(this.git2);
		this.gitInv3 = this.gitInv3 || invert(this.git3);
		this.gitInv4 = this.gitInv4 || invert(this.git4);
		this.gitInv5 = this.gitInv5 || invert(this.git5);
		this.gitInv6 = this.gitInv6 || invert(this.git6);
		this.gitInv7 = this.gitInv7 || invert(this.git7);
		this.branchLabelColor = this.branchLabelColor || (this.darkMode ? "black" : this.labelTextColor);
		this.gitBranchLabel0 = this.gitBranchLabel0 || this.branchLabelColor;
		this.gitBranchLabel1 = this.gitBranchLabel1 || this.branchLabelColor;
		this.gitBranchLabel2 = this.gitBranchLabel2 || this.branchLabelColor;
		this.gitBranchLabel3 = this.gitBranchLabel3 || this.branchLabelColor;
		this.gitBranchLabel4 = this.gitBranchLabel4 || this.branchLabelColor;
		this.gitBranchLabel5 = this.gitBranchLabel5 || this.branchLabelColor;
		this.gitBranchLabel6 = this.gitBranchLabel6 || this.branchLabelColor;
		this.gitBranchLabel7 = this.gitBranchLabel7 || this.branchLabelColor;
		this.tagLabelColor = this.tagLabelColor || this.primaryTextColor;
		this.tagLabelBackground = this.tagLabelBackground || this.primaryColor;
		this.tagLabelBorder = this.tagBorder || this.primaryBorderColor;
		this.tagLabelFontSize = this.tagLabelFontSize || "10px";
		this.commitLabelColor = this.commitLabelColor || this.secondaryTextColor;
		this.commitLabelBackground = this.commitLabelBackground || this.secondaryColor;
		this.commitLabelFontSize = this.commitLabelFontSize || "10px";
		this.attributeBackgroundColorOdd = this.attributeBackgroundColorOdd || oldAttributeBackgroundColorOdd;
		this.attributeBackgroundColorEven = this.attributeBackgroundColorEven || oldAttributeBackgroundColorEven;
	}
	calculate(overrides) {
		if (typeof overrides !== "object") {
			this.updateColors();
			return;
		}
		const keys = Object.keys(overrides);
		keys.forEach((k) => {
			this[k] = overrides[k];
		});
		this.updateColors();
		keys.forEach((k) => {
			this[k] = overrides[k];
		});
	}
};
var getThemeVariables7 = /* @__PURE__ */ __name((userOverrides) => {
	const theme = new Theme7();
	theme.calculate(userOverrides);
	return theme;
}, "getThemeVariables");
var Theme8 = class {
	static {
		__name(this, "Theme");
	}
	constructor() {
		this.background = "#ffffff";
		this.primaryColor = "#cccccc";
		this.mainBkg = "#ffffff";
		this.noteBkgColor = "#fff5ad";
		this.noteTextColor = "#28253D";
		this.THEME_COLOR_LIMIT = 12;
		this.radius = 12;
		this.strokeWidth = 2;
		this.primaryBorderColor = mkBorder("#28253D", this.darkMode);
		this.fontFamily = "\"Recursive Variable\", arial, sans-serif";
		this.fontSize = "14px";
		this.nodeBorder = "#28253D";
		this.stateBorder = "#28253D";
		this.useGradient = false;
		this.gradientStart = "#0042eb";
		this.gradientStop = "#eb0042";
		this.dropShadow = "url(#drop-shadow)";
		this.nodeShadow = true;
		this.tertiaryColor = "#ffffff";
		this.clusterBkg = "#F9F9FB";
		this.clusterBorder = "#BDBCCC";
		this.noteBorderColor = "#FACC15";
		this.archEdgeColor = "calculated";
		this.archEdgeArrowColor = "calculated";
		this.archEdgeWidth = "3";
		this.archGroupBorderColor = this.primaryBorderColor;
		this.archGroupBorderWidth = "2px";
		this.actorBorder = "#28253D";
		this.filterColor = "#000000";
	}
	updateColors() {
		this.primaryTextColor = this.primaryTextColor || (this.darkMode ? "#eee" : "#28253D");
		this.secondaryColor = this.secondaryColor || adjust(this.primaryColor, { h: -120 });
		this.tertiaryColor = this.tertiaryColor || adjust(this.primaryColor, {
			h: 180,
			l: 5
		});
		this.primaryBorderColor = this.primaryBorderColor || mkBorder(this.primaryColor, this.darkMode);
		this.secondaryBorderColor = this.secondaryBorderColor || mkBorder(this.secondaryColor, this.darkMode);
		this.tertiaryBorderColor = this.tertiaryBorderColor || mkBorder(this.tertiaryColor, this.darkMode);
		this.noteBorderColor = this.noteBorderColor || mkBorder(this.noteBkgColor, this.darkMode);
		this.noteBkgColor = this.noteBkgColor || "#FEF9C3";
		this.noteTextColor = this.noteTextColor || "#28253D";
		this.secondaryTextColor = this.secondaryTextColor || invert(this.secondaryColor);
		this.tertiaryTextColor = this.tertiaryTextColor || invert(this.tertiaryColor);
		this.lineColor = this.lineColor || invert(this.background);
		this.arrowheadColor = this.arrowheadColor || invert(this.background);
		this.textColor = this.textColor || this.primaryTextColor;
		this.border2 = this.border2 || this.tertiaryBorderColor;
		this.nodeBkg = this.nodeBkg || this.primaryColor;
		this.mainBkg = this.mainBkg || this.primaryColor;
		this.nodeBorder = this.nodeBorder || this.primaryBorderColor;
		this.clusterBkg = this.clusterBkg || this.tertiaryColor;
		this.clusterBorder = this.clusterBorder || this.tertiaryBorderColor;
		this.defaultLinkColor = this.defaultLinkColor || this.lineColor;
		this.titleColor = this.titleColor || this.tertiaryTextColor;
		this.edgeLabelBackground = this.edgeLabelBackground || (this.darkMode ? darken(this.secondaryColor, 30) : this.secondaryColor);
		this.nodeTextColor = this.nodeTextColor || this.primaryTextColor;
		this.noteFontWeight = 600;
		this.actorBorder = this.actorBorder || this.primaryBorderColor;
		this.actorBkg = this.actorBkg || this.mainBkg;
		this.actorTextColor = this.actorTextColor || this.primaryTextColor;
		this.actorLineColor = this.actorLineColor || this.actorBorder;
		this.labelBoxBkgColor = this.labelBoxBkgColor || this.actorBkg;
		this.signalColor = this.signalColor || this.textColor;
		this.signalTextColor = this.signalTextColor || this.textColor;
		this.labelBoxBorderColor = this.labelBoxBorderColor || this.actorBorder;
		this.labelTextColor = this.labelTextColor || this.actorTextColor;
		this.loopTextColor = this.loopTextColor || this.actorTextColor;
		this.activationBorderColor = this.activationBorderColor || darken(this.secondaryColor, 10);
		this.activationBkgColor = this.activationBkgColor || this.secondaryColor;
		this.sequenceNumberColor = this.sequenceNumberColor || invert(this.lineColor);
		const primaryColor = "#ECECFE";
		const secondaryColor = "#E9E9F1";
		const tertiaryColor = adjust(primaryColor, {
			h: 180,
			l: 5
		});
		this.sectionBkgColor = this.sectionBkgColor || tertiaryColor;
		this.altSectionBkgColor = this.altSectionBkgColor || "white";
		this.sectionBkgColor = this.sectionBkgColor || secondaryColor;
		this.sectionBkgColor2 = this.sectionBkgColor2 || primaryColor;
		this.excludeBkgColor = this.excludeBkgColor || "#eeeeee";
		this.taskBorderColor = this.taskBorderColor || this.primaryBorderColor;
		this.taskBkgColor = this.taskBkgColor || primaryColor;
		this.activeTaskBorderColor = this.activeTaskBorderColor || primaryColor;
		this.activeTaskBkgColor = this.activeTaskBkgColor || lighten(primaryColor, 23);
		this.gridColor = this.gridColor || "lightgrey";
		this.doneTaskBkgColor = this.doneTaskBkgColor || "lightgrey";
		this.doneTaskBorderColor = this.doneTaskBorderColor || "grey";
		this.critBorderColor = this.critBorderColor || "#ff8888";
		this.critBkgColor = this.critBkgColor || "red";
		this.todayLineColor = this.todayLineColor || "red";
		this.taskTextColor = this.taskTextColor || this.textColor;
		this.vertLineColor = this.vertLineColor || this.primaryBorderColor;
		this.taskTextOutsideColor = this.taskTextOutsideColor || this.textColor;
		this.taskTextLightColor = this.taskTextLightColor || this.textColor;
		this.taskTextColor = this.taskTextColor || this.primaryTextColor;
		this.taskTextDarkColor = this.taskTextDarkColor || this.textColor;
		this.taskTextClickableColor = this.taskTextClickableColor || "#003163";
		this.archEdgeColor = this.lineColor;
		this.archEdgeArrowColor = this.lineColor;
		this.personBorder = this.personBorder || this.primaryBorderColor;
		this.personBkg = this.personBkg || this.mainBkg;
		this.transitionColor = this.transitionColor || this.lineColor;
		this.transitionLabelColor = this.transitionLabelColor || this.textColor;
		this.stateLabelColor = this.stateLabelColor || this.stateBkg || this.primaryTextColor;
		this.compositeTitleBackground = "#F9F9FB";
		this.altBackground = "#F9F9FB";
		this.stateEdgeLabelBackground = "#FFFFFF";
		this.fontWeight = 600;
		this.stateBkg = this.stateBkg || this.mainBkg;
		this.labelBackgroundColor = this.labelBackgroundColor || this.stateBkg;
		this.compositeBackground = this.compositeBackground || this.background || this.tertiaryColor;
		this.altBackground = this.altBackground || "#f0f0f0";
		this.compositeTitleBackground = this.compositeTitleBackground || this.mainBkg;
		this.compositeBorder = this.compositeBorder || this.nodeBorder;
		this.innerEndBackground = this.nodeBorder;
		this.errorBkgColor = this.errorBkgColor || this.tertiaryColor;
		this.errorTextColor = this.errorTextColor || this.tertiaryTextColor;
		this.transitionColor = this.transitionColor || this.lineColor;
		this.specialStateColor = this.lineColor;
		for (let i = 0; i < this.THEME_COLOR_LIMIT; i++) this["cScale" + i] = this.mainBkg;
		if (this.darkMode) for (let i = 0; i < this.THEME_COLOR_LIMIT; i++) this["cScale" + i] = darken(this["cScale" + i], 75);
		else for (let i = 0; i < this.THEME_COLOR_LIMIT; i++) this["cScale" + i] = darken(this["cScale" + i], 25);
		for (let i = 0; i < this.THEME_COLOR_LIMIT; i++) this["cScaleInv" + i] = this["cScaleInv" + i] || invert(this["cScale" + i]);
		for (let i = 0; i < this.THEME_COLOR_LIMIT; i++) if (this.darkMode) this["cScalePeer" + i] = this["cScalePeer" + i] || lighten(this["cScale" + i], 10);
		else this["cScalePeer" + i] = this["cScalePeer" + i] || darken(this["cScale" + i], 10);
		this.scaleLabelColor = this.scaleLabelColor || this.labelTextColor;
		for (let i = 0; i < this.THEME_COLOR_LIMIT; i++) this["cScaleLabel" + i] = this["cScaleLabel" + i] || this.scaleLabelColor;
		const multiplier = this.darkMode ? -4 : -1;
		for (let i = 0; i < 5; i++) {
			this["surface" + i] = this["surface" + i] || adjust(this.mainBkg, {
				h: 180,
				s: -15,
				l: multiplier * (5 + i * 3)
			});
			this["surfacePeer" + i] = this["surfacePeer" + i] || adjust(this.mainBkg, {
				h: 180,
				s: -15,
				l: multiplier * (8 + i * 3)
			});
		}
		this.classText = this.classText || this.textColor;
		this.fillType0 = this.fillType0 || primaryColor;
		this.fillType1 = this.fillType1 || secondaryColor;
		this.fillType2 = this.fillType2 || adjust(primaryColor, { h: 64 });
		this.fillType3 = this.fillType3 || adjust(secondaryColor, { h: 64 });
		this.fillType4 = this.fillType4 || adjust(primaryColor, { h: -64 });
		this.fillType5 = this.fillType5 || adjust(secondaryColor, { h: -64 });
		this.fillType6 = this.fillType6 || adjust(primaryColor, { h: 128 });
		this.fillType7 = this.fillType7 || adjust(secondaryColor, { h: 128 });
		this.pie1 = this.pie1 || primaryColor;
		this.pie2 = this.pie2 || secondaryColor;
		this.pie3 = this.pie3 || tertiaryColor;
		this.pie4 = this.pie4 || adjust(primaryColor, { l: -10 });
		this.pie5 = this.pie5 || adjust(secondaryColor, { l: -10 });
		this.pie6 = this.pie6 || adjust(tertiaryColor, { l: -10 });
		this.pie7 = this.pie7 || adjust(primaryColor, {
			h: 60,
			l: -10
		});
		this.pie8 = this.pie8 || adjust(primaryColor, {
			h: -60,
			l: -10
		});
		this.pie9 = this.pie9 || adjust(primaryColor, {
			h: 120,
			l: 0
		});
		this.pie10 = this.pie10 || adjust(primaryColor, {
			h: 60,
			l: -20
		});
		this.pie11 = this.pie11 || adjust(primaryColor, {
			h: -60,
			l: -20
		});
		this.pie12 = this.pie12 || adjust(primaryColor, {
			h: 120,
			l: -10
		});
		this.pieTitleTextSize = this.pieTitleTextSize || "25px";
		this.pieTitleTextColor = this.pieTitleTextColor || this.taskTextDarkColor;
		this.pieSectionTextSize = this.pieSectionTextSize || "17px";
		this.pieSectionTextColor = this.pieSectionTextColor || this.textColor;
		this.pieLegendTextSize = this.pieLegendTextSize || "17px";
		this.pieLegendTextColor = this.pieLegendTextColor || this.taskTextDarkColor;
		this.pieStrokeColor = this.pieStrokeColor || "black";
		this.pieStrokeWidth = this.pieStrokeWidth || "2px";
		this.pieOuterStrokeWidth = this.pieOuterStrokeWidth || "2px";
		this.pieOuterStrokeColor = this.pieOuterStrokeColor || "black";
		this.pieOpacity = this.pieOpacity || "0.7";
		this.vennTitleTextColor = this.vennTitleTextColor ?? this.titleColor;
		this.vennSetTextColor = this.vennSetTextColor ?? this.textColor;
		this.quadrant1Fill = this.quadrant1Fill || primaryColor;
		this.quadrant2Fill = this.quadrant2Fill || adjust(primaryColor, {
			r: 5,
			g: 5,
			b: 5
		});
		this.quadrant3Fill = this.quadrant3Fill || adjust(primaryColor, {
			r: 10,
			g: 10,
			b: 10
		});
		this.quadrant4Fill = this.quadrant4Fill || adjust(primaryColor, {
			r: 15,
			g: 15,
			b: 15
		});
		this.quadrant1TextFill = this.quadrant1TextFill || this.primaryTextColor;
		this.quadrant2TextFill = this.quadrant2TextFill || adjust(this.primaryTextColor, {
			r: -5,
			g: -5,
			b: -5
		});
		this.quadrant3TextFill = this.quadrant3TextFill || adjust(this.primaryTextColor, {
			r: -10,
			g: -10,
			b: -10
		});
		this.quadrant4TextFill = this.quadrant4TextFill || adjust(this.primaryTextColor, {
			r: -15,
			g: -15,
			b: -15
		});
		this.quadrantPointFill = this.quadrantPointFill || isDark(this.quadrant1Fill) ? lighten(this.quadrant1Fill) : darken(this.quadrant1Fill);
		this.quadrantPointTextFill = this.quadrantPointTextFill || this.primaryTextColor;
		this.quadrantXAxisTextFill = this.quadrantXAxisTextFill || this.primaryTextColor;
		this.quadrantYAxisTextFill = this.quadrantYAxisTextFill || this.primaryTextColor;
		this.quadrantInternalBorderStrokeFill = this.quadrantInternalBorderStrokeFill || this.primaryBorderColor;
		this.quadrantExternalBorderStrokeFill = this.quadrantExternalBorderStrokeFill || this.primaryBorderColor;
		this.quadrantTitleFill = this.quadrantTitleFill || this.primaryTextColor;
		this.xyChart = {
			backgroundColor: this.xyChart?.backgroundColor || this.background,
			titleColor: this.xyChart?.titleColor || this.primaryTextColor,
			xAxisTitleColor: this.xyChart?.xAxisTitleColor || this.primaryTextColor,
			xAxisLabelColor: this.xyChart?.xAxisLabelColor || this.primaryTextColor,
			xAxisTickColor: this.xyChart?.xAxisTickColor || this.primaryTextColor,
			xAxisLineColor: this.xyChart?.xAxisLineColor || this.primaryTextColor,
			yAxisTitleColor: this.xyChart?.yAxisTitleColor || this.primaryTextColor,
			yAxisLabelColor: this.xyChart?.yAxisLabelColor || this.primaryTextColor,
			yAxisTickColor: this.xyChart?.yAxisTickColor || this.primaryTextColor,
			yAxisLineColor: this.xyChart?.yAxisLineColor || this.primaryTextColor,
			plotColorPalette: this.xyChart?.plotColorPalette || "#FFF4DD,#FFD8B1,#FFA07A,#ECEFF1,#D6DBDF,#C3E0A8,#FFB6A4,#FFD74D,#738FA7,#FFFFF0"
		};
		this.requirementBackground = this.requirementBackground || primaryColor;
		this.requirementBorderColor = this.requirementBorderColor || this.primaryBorderColor;
		this.requirementBorderSize = this.requirementBorderSize || "1";
		this.requirementTextColor = this.requirementTextColor || this.primaryTextColor;
		this.relationColor = this.relationColor || this.lineColor;
		this.relationLabelBackground = this.relationLabelBackground || (this.darkMode ? darken(this.secondaryColor, 30) : this.secondaryColor);
		this.relationLabelColor = this.relationLabelColor || this.actorTextColor;
		this.requirementEdgeLabelBackground = "#FFFFFF";
		this.git0 = this.git0 || primaryColor;
		this.git1 = this.git1 || secondaryColor;
		this.git2 = this.git2 || tertiaryColor;
		this.git3 = this.git3 || adjust(primaryColor, { h: -30 });
		this.git4 = this.git4 || adjust(primaryColor, { h: -60 });
		this.git5 = this.git5 || adjust(primaryColor, { h: -90 });
		this.git6 = this.git6 || adjust(primaryColor, { h: 60 });
		this.git7 = this.git7 || adjust(primaryColor, { h: 120 });
		if (this.darkMode) {
			this.git0 = lighten(this.git0, 25);
			this.git1 = lighten(this.git1, 25);
			this.git2 = lighten(this.git2, 25);
			this.git3 = lighten(this.git3, 25);
			this.git4 = lighten(this.git4, 25);
			this.git5 = lighten(this.git5, 25);
			this.git6 = lighten(this.git6, 25);
			this.git7 = lighten(this.git7, 25);
		} else {
			this.git0 = darken(this.git0, 25);
			this.git1 = darken(this.git1, 25);
			this.git2 = darken(this.git2, 25);
			this.git3 = darken(this.git3, 25);
			this.git4 = darken(this.git4, 25);
			this.git5 = darken(this.git5, 25);
			this.git6 = darken(this.git6, 25);
			this.git7 = darken(this.git7, 25);
		}
		this.gitInv0 = this.gitInv0 || invert(this.git0);
		this.gitInv1 = this.gitInv1 || invert(this.git1);
		this.gitInv2 = this.gitInv2 || invert(this.git2);
		this.gitInv3 = this.gitInv3 || invert(this.git3);
		this.gitInv4 = this.gitInv4 || invert(this.git4);
		this.gitInv5 = this.gitInv5 || invert(this.git5);
		this.gitInv6 = this.gitInv6 || invert(this.git6);
		this.gitInv7 = this.gitInv7 || invert(this.git7);
		this.branchLabelColor = this.branchLabelColor || (this.darkMode ? "black" : this.labelTextColor);
		this.gitBranchLabel0 = this.gitBranchLabel0 || this.branchLabelColor;
		this.gitBranchLabel1 = this.gitBranchLabel1 || this.branchLabelColor;
		this.gitBranchLabel2 = this.gitBranchLabel2 || this.branchLabelColor;
		this.gitBranchLabel3 = this.gitBranchLabel3 || this.branchLabelColor;
		this.gitBranchLabel4 = this.gitBranchLabel4 || this.branchLabelColor;
		this.gitBranchLabel5 = this.gitBranchLabel5 || this.branchLabelColor;
		this.gitBranchLabel6 = this.gitBranchLabel6 || this.branchLabelColor;
		this.gitBranchLabel7 = this.gitBranchLabel7 || this.branchLabelColor;
		this.tagLabelColor = this.tagLabelColor || this.primaryTextColor;
		this.tagLabelBackground = this.tagLabelBackground || this.primaryColor;
		this.tagLabelBorder = this.tagBorder || this.primaryBorderColor;
		this.tagLabelFontSize = this.tagLabelFontSize || "10px";
		this.commitLabelColor = this.commitLabelColor || this.secondaryTextColor;
		this.commitLabelBackground = this.commitLabelBackground || this.secondaryColor;
		this.commitLabelFontSize = this.commitLabelFontSize || "10px";
		this.commitLineColor = this.commitLineColor ?? "#BDBCCC";
		this.erEdgeLabelBackground = "#FFFFFF";
		this.attributeBackgroundColorOdd = this.attributeBackgroundColorOdd || oldAttributeBackgroundColorOdd;
		this.attributeBackgroundColorEven = this.attributeBackgroundColorEven || oldAttributeBackgroundColorEven;
	}
	calculate(overrides) {
		if (typeof overrides !== "object") {
			this.updateColors();
			return;
		}
		const keys = Object.keys(overrides);
		keys.forEach((k) => {
			this[k] = overrides[k];
		});
		this.updateColors();
		keys.forEach((k) => {
			this[k] = overrides[k];
		});
	}
};
var getThemeVariables8 = /* @__PURE__ */ __name((userOverrides) => {
	const theme = new Theme8();
	theme.calculate(userOverrides);
	return theme;
}, "getThemeVariables");
var Theme9 = class {
	static {
		__name(this, "Theme");
	}
	constructor() {
		this.background = "#333";
		this.primaryColor = "#1f2020";
		this.secondaryColor = lighten(this.primaryColor, 16);
		this.tertiaryColor = adjust(this.primaryColor, { h: -160 });
		this.primaryBorderColor = invert(this.background);
		this.secondaryBorderColor = mkBorder(this.secondaryColor, this.darkMode);
		this.tertiaryBorderColor = mkBorder(this.tertiaryColor, this.darkMode);
		this.primaryTextColor = invert(this.primaryColor);
		this.secondaryTextColor = invert(this.secondaryColor);
		this.tertiaryTextColor = invert(this.tertiaryColor);
		this.mainBkg = "#111113";
		this.secondBkg = "calculated";
		this.mainContrastColor = "lightgrey";
		this.darkTextColor = lighten(invert("#323D47"), 10);
		this.border1 = "#ccc";
		this.border2 = rgba(255, 255, 255, .25);
		this.arrowheadColor = invert(this.background);
		this.fontFamily = "\"Recursive Variable\", arial, sans-serif";
		this.fontSize = "14px";
		this.labelBackground = "#111113";
		this.textColor = "#ccc";
		this.THEME_COLOR_LIMIT = 12;
		this.radius = 12;
		this.strokeWidth = 2;
		this.noteBkgColor = this.noteBkgColor ?? "#FEF9C3";
		this.noteTextColor = this.noteTextColor ?? "#28253D";
		this.THEME_COLOR_LIMIT = 12;
		this.fontFamily = "\"Recursive Variable\", arial, sans-serif";
		this.fontSize = "14px";
		this.nodeBorder = "#FFFFFF";
		this.stateBorder = "#FFFFFF";
		this.useGradient = false;
		this.gradientStart = "#0042eb";
		this.gradientStop = "#eb0042";
		this.dropShadow = "url(#drop-shadow)";
		this.nodeShadow = true;
		this.archEdgeColor = "calculated";
		this.archEdgeArrowColor = "calculated";
		this.archEdgeWidth = "3";
		this.archGroupBorderColor = this.primaryBorderColor;
		this.archGroupBorderWidth = "2px";
		this.clusterBkg = "#1E1A2E";
		this.clusterBorder = "#BDBCCC";
		this.noteBorderColor = "#FACC15";
		this.noteFontWeight = 600;
		this.filterColor = "#FFFFFF";
	}
	updateColors() {
		this.primaryTextColor = this.primaryTextColor || (this.darkMode ? "#eee" : "#FFFFFF");
		this.secondaryColor = this.secondaryColor || adjust(this.primaryColor, { h: -120 });
		this.tertiaryColor = this.tertiaryColor || adjust(this.primaryColor, {
			h: 180,
			l: 5
		});
		this.primaryBorderColor = this.primaryBorderColor || mkBorder(this.primaryColor, this.darkMode);
		this.secondaryBorderColor = this.secondaryBorderColor || mkBorder(this.secondaryColor, this.darkMode);
		this.tertiaryBorderColor = this.tertiaryBorderColor || mkBorder(this.tertiaryColor, this.darkMode);
		this.noteBorderColor = this.noteBorderColor || mkBorder(this.noteBkgColor, this.darkMode);
		this.noteBkgColor = this.noteBkgColor || "#fff5ad";
		this.noteTextColor = this.noteTextColor || "#FFFFFF";
		this.secondaryTextColor = this.secondaryTextColor || invert(this.secondaryColor);
		this.tertiaryTextColor = this.tertiaryTextColor || invert(this.tertiaryColor);
		this.lineColor = this.lineColor || invert(this.background);
		this.arrowheadColor = this.arrowheadColor || invert(this.background);
		this.textColor = this.textColor || this.primaryTextColor;
		this.border2 = this.border2 || this.tertiaryBorderColor;
		this.nodeBkg = this.nodeBkg || this.primaryColor;
		this.mainBkg = this.mainBkg || this.primaryColor;
		this.nodeBorder = this.nodeBorder || this.border1;
		this.clusterBkg = this.clusterBkg || this.tertiaryColor;
		this.clusterBorder = this.clusterBorder || this.tertiaryBorderColor;
		this.defaultLinkColor = this.defaultLinkColor || this.lineColor;
		this.titleColor = this.titleColor || this.tertiaryTextColor;
		this.edgeLabelBackground = this.edgeLabelBackground || (this.darkMode ? darken(this.secondaryColor, 30) : this.secondaryColor);
		this.nodeTextColor = this.nodeTextColor || this.primaryTextColor;
		this.actorBorder = "#FFFFFF";
		this.signalColor = "#FFFFFF";
		this.labelBoxBorderColor = "#BDBCCC";
		this.actorBorder = this.actorBorder || this.primaryBorderColor;
		this.actorBkg = this.actorBkg || this.mainBkg;
		this.actorTextColor = this.actorTextColor || this.primaryTextColor;
		this.actorLineColor = this.actorLineColor || this.actorBorder;
		this.labelBoxBkgColor = this.labelBoxBkgColor || this.actorBkg;
		this.signalColor = this.signalColor || this.textColor;
		this.signalTextColor = this.signalTextColor || this.textColor;
		this.labelBoxBorderColor = this.labelBoxBorderColor || this.actorBorder;
		this.labelTextColor = this.labelTextColor || this.actorTextColor;
		this.loopTextColor = this.loopTextColor || this.actorTextColor;
		this.activationBorderColor = this.activationBorderColor || darken(this.secondaryColor, 10);
		this.activationBkgColor = this.activationBkgColor || this.secondaryColor;
		this.sequenceNumberColor = this.sequenceNumberColor || invert(this.lineColor);
		this.sectionBkgColor = this.sectionBkgColor || this.tertiaryColor;
		this.altSectionBkgColor = this.altSectionBkgColor || "white";
		this.sectionBkgColor = this.sectionBkgColor || this.secondaryColor;
		this.sectionBkgColor2 = this.sectionBkgColor2 || this.primaryColor;
		this.excludeBkgColor = this.excludeBkgColor || "#eeeeee";
		this.taskBorderColor = this.taskBorderColor || this.primaryBorderColor;
		this.taskBkgColor = this.taskBkgColor || this.primaryColor;
		this.activeTaskBorderColor = this.activeTaskBorderColor || this.primaryColor;
		this.activeTaskBkgColor = this.activeTaskBkgColor || lighten(this.primaryColor, 23);
		this.gridColor = this.gridColor || "lightgrey";
		this.doneTaskBkgColor = this.doneTaskBkgColor || "lightgrey";
		this.doneTaskBorderColor = this.doneTaskBorderColor || "grey";
		this.critBorderColor = this.critBorderColor || "#ff8888";
		this.critBkgColor = this.critBkgColor || "red";
		this.todayLineColor = this.todayLineColor || "red";
		this.taskTextColor = this.taskTextColor || this.textColor;
		this.taskTextOutsideColor = this.taskTextOutsideColor || this.textColor;
		this.taskTextLightColor = this.taskTextLightColor || this.textColor;
		this.taskTextColor = this.taskTextColor || this.primaryTextColor;
		this.taskTextDarkColor = this.taskTextDarkColor || this.textColor;
		this.taskTextClickableColor = this.taskTextClickableColor || "#003163";
		this.archEdgeColor = this.lineColor;
		this.archEdgeArrowColor = this.lineColor;
		this.personBorder = this.personBorder || this.primaryBorderColor;
		this.personBkg = this.personBkg || this.mainBkg;
		this.transitionColor = this.transitionColor || this.lineColor;
		this.transitionLabelColor = this.transitionLabelColor || this.textColor;
		this.stateLabelColor = this.stateLabelColor || this.stateBkg || this.primaryTextColor;
		this.vertLineColor = this.vertLineColor || this.primaryBorderColor;
		this.compositeBackground = "#16141F";
		this.altBackground = "#16141F";
		this.compositeTitleBackground = "#16141F";
		this.stateEdgeLabelBackground = "#16141F";
		this.fontWeight = 600;
		this.stateBkg = this.stateBkg || this.mainBkg;
		this.labelBackgroundColor = this.labelBackgroundColor || this.stateBkg;
		this.compositeBackground = this.compositeBackground || this.background || this.tertiaryColor;
		this.altBackground = this.altBackground || "#f0f0f0";
		this.compositeTitleBackground = this.compositeTitleBackground || this.mainBkg;
		this.compositeBorder = this.compositeBorder || this.nodeBorder;
		this.innerEndBackground = this.nodeBorder;
		this.errorBkgColor = this.errorBkgColor || this.tertiaryColor;
		this.errorTextColor = this.errorTextColor || this.tertiaryTextColor;
		this.transitionColor = this.transitionColor || this.lineColor;
		this.specialStateColor = this.lineColor;
		this.cScale0 = this.cScale0 || this.primaryColor;
		this.cScale1 = this.cScale1 || this.secondaryColor;
		this.cScale2 = this.cScale2 || this.tertiaryColor;
		this.cScale3 = this.cScale3 || adjust(this.primaryColor, { h: 30 });
		this.cScale4 = this.cScale4 || adjust(this.primaryColor, { h: 60 });
		this.cScale5 = this.cScale5 || adjust(this.primaryColor, { h: 90 });
		this.cScale6 = this.cScale6 || adjust(this.primaryColor, { h: 120 });
		this.cScale7 = this.cScale7 || adjust(this.primaryColor, { h: 150 });
		this.cScale8 = this.cScale8 || adjust(this.primaryColor, {
			h: 210,
			l: 150
		});
		this.cScale9 = this.cScale9 || adjust(this.primaryColor, { h: 270 });
		this.cScale10 = this.cScale10 || adjust(this.primaryColor, { h: 300 });
		this.cScale11 = this.cScale11 || adjust(this.primaryColor, { h: 330 });
		if (this.darkMode) for (let i = 0; i < this.THEME_COLOR_LIMIT; i++) this["cScale" + i] = darken(this["cScale" + i], 75);
		else for (let i = 0; i < this.THEME_COLOR_LIMIT; i++) this["cScale" + i] = darken(this["cScale" + i], 25);
		for (let i = 0; i < this.THEME_COLOR_LIMIT; i++) this["cScaleInv" + i] = this["cScaleInv" + i] || invert(this["cScale" + i]);
		for (let i = 0; i < this.THEME_COLOR_LIMIT; i++) if (this.darkMode) this["cScalePeer" + i] = this["cScalePeer" + i] || lighten(this["cScale" + i], 10);
		else this["cScalePeer" + i] = this["cScalePeer" + i] || darken(this["cScale" + i], 10);
		this.scaleLabelColor = this.scaleLabelColor || this.labelTextColor;
		for (let i = 0; i < this.THEME_COLOR_LIMIT; i++) this["cScaleLabel" + i] = this["cScaleLabel" + i] || this.scaleLabelColor;
		const multiplier = this.darkMode ? -4 : -1;
		for (let i = 0; i < 5; i++) {
			this["surface" + i] = this["surface" + i] || adjust(this.mainBkg, {
				h: 180,
				s: -15,
				l: multiplier * (5 + i * 3)
			});
			this["surfacePeer" + i] = this["surfacePeer" + i] || adjust(this.mainBkg, {
				h: 180,
				s: -15,
				l: multiplier * (8 + i * 3)
			});
		}
		this.classText = this.classText || this.textColor;
		this.fillType0 = this.fillType0 || this.primaryColor;
		this.fillType1 = this.fillType1 || this.secondaryColor;
		this.fillType2 = this.fillType2 || adjust(this.primaryColor, { h: 64 });
		this.fillType3 = this.fillType3 || adjust(this.secondaryColor, { h: 64 });
		this.fillType4 = this.fillType4 || adjust(this.primaryColor, { h: -64 });
		this.fillType5 = this.fillType5 || adjust(this.secondaryColor, { h: -64 });
		this.fillType6 = this.fillType6 || adjust(this.primaryColor, { h: 128 });
		this.fillType7 = this.fillType7 || adjust(this.secondaryColor, { h: 128 });
		this.pie1 = this.pie1 || this.primaryColor;
		this.pie2 = this.pie2 || this.secondaryColor;
		this.pie3 = this.pie3 || this.tertiaryColor;
		this.pie4 = this.pie4 || adjust(this.primaryColor, { l: -10 });
		this.pie5 = this.pie5 || adjust(this.secondaryColor, { l: -10 });
		this.pie6 = this.pie6 || adjust(this.tertiaryColor, { l: -10 });
		this.pie7 = this.pie7 || adjust(this.primaryColor, {
			h: 60,
			l: -10
		});
		this.pie8 = this.pie8 || adjust(this.primaryColor, {
			h: -60,
			l: -10
		});
		this.pie9 = this.pie9 || adjust(this.primaryColor, {
			h: 120,
			l: 0
		});
		this.pie10 = this.pie10 || adjust(this.primaryColor, {
			h: 60,
			l: -20
		});
		this.pie11 = this.pie11 || adjust(this.primaryColor, {
			h: -60,
			l: -20
		});
		this.pie12 = this.pie12 || adjust(this.primaryColor, {
			h: 120,
			l: -10
		});
		this.pieTitleTextSize = this.pieTitleTextSize || "25px";
		this.pieTitleTextColor = this.pieTitleTextColor || this.taskTextDarkColor;
		this.pieSectionTextSize = this.pieSectionTextSize || "17px";
		this.pieSectionTextColor = this.pieSectionTextColor || this.textColor;
		this.pieLegendTextSize = this.pieLegendTextSize || "17px";
		this.pieLegendTextColor = this.pieLegendTextColor || this.taskTextDarkColor;
		this.pieStrokeColor = this.pieStrokeColor || "black";
		this.pieStrokeWidth = this.pieStrokeWidth || "2px";
		this.pieOuterStrokeWidth = this.pieOuterStrokeWidth || "2px";
		this.pieOuterStrokeColor = this.pieOuterStrokeColor || "black";
		this.pieOpacity = this.pieOpacity || "0.7";
		this.vennTitleTextColor = this.vennTitleTextColor ?? this.titleColor;
		this.vennSetTextColor = this.vennSetTextColor ?? this.textColor;
		this.quadrant1Fill = this.quadrant1Fill || this.primaryColor;
		this.quadrant2Fill = this.quadrant2Fill || adjust(this.primaryColor, {
			r: 5,
			g: 5,
			b: 5
		});
		this.quadrant3Fill = this.quadrant3Fill || adjust(this.primaryColor, {
			r: 10,
			g: 10,
			b: 10
		});
		this.quadrant4Fill = this.quadrant4Fill || adjust(this.primaryColor, {
			r: 15,
			g: 15,
			b: 15
		});
		this.quadrant1TextFill = this.quadrant1TextFill || this.primaryTextColor;
		this.quadrant2TextFill = this.quadrant2TextFill || adjust(this.primaryTextColor, {
			r: -5,
			g: -5,
			b: -5
		});
		this.quadrant3TextFill = this.quadrant3TextFill || adjust(this.primaryTextColor, {
			r: -10,
			g: -10,
			b: -10
		});
		this.quadrant4TextFill = this.quadrant4TextFill || adjust(this.primaryTextColor, {
			r: -15,
			g: -15,
			b: -15
		});
		this.quadrantPointFill = this.quadrantPointFill || isDark(this.quadrant1Fill) ? lighten(this.quadrant1Fill) : darken(this.quadrant1Fill);
		this.quadrantPointTextFill = this.quadrantPointTextFill || this.primaryTextColor;
		this.quadrantXAxisTextFill = this.quadrantXAxisTextFill || this.primaryTextColor;
		this.quadrantYAxisTextFill = this.quadrantYAxisTextFill || this.primaryTextColor;
		this.quadrantInternalBorderStrokeFill = this.quadrantInternalBorderStrokeFill || this.primaryBorderColor;
		this.quadrantExternalBorderStrokeFill = this.quadrantExternalBorderStrokeFill || this.primaryBorderColor;
		this.quadrantTitleFill = this.quadrantTitleFill || this.primaryTextColor;
		this.xyChart = {
			backgroundColor: this.xyChart?.backgroundColor || this.background,
			titleColor: this.xyChart?.titleColor || this.primaryTextColor,
			xAxisTitleColor: this.xyChart?.xAxisTitleColor || this.primaryTextColor,
			xAxisLabelColor: this.xyChart?.xAxisLabelColor || this.primaryTextColor,
			xAxisTickColor: this.xyChart?.xAxisTickColor || this.primaryTextColor,
			xAxisLineColor: this.xyChart?.xAxisLineColor || this.primaryTextColor,
			yAxisTitleColor: this.xyChart?.yAxisTitleColor || this.primaryTextColor,
			yAxisLabelColor: this.xyChart?.yAxisLabelColor || this.primaryTextColor,
			yAxisTickColor: this.xyChart?.yAxisTickColor || this.primaryTextColor,
			yAxisLineColor: this.xyChart?.yAxisLineColor || this.primaryTextColor,
			plotColorPalette: this.xyChart?.plotColorPalette || "#FFF4DD,#FFD8B1,#FFA07A,#ECEFF1,#D6DBDF,#C3E0A8,#FFB6A4,#FFD74D,#738FA7,#FFFFF0"
		};
		this.requirementBackground = this.requirementBackground || this.primaryColor;
		this.requirementBorderColor = this.requirementBorderColor || this.primaryBorderColor;
		this.requirementBorderSize = this.requirementBorderSize || "1";
		this.requirementTextColor = this.requirementTextColor || this.primaryTextColor;
		this.relationColor = this.relationColor || this.lineColor;
		this.relationLabelBackground = this.relationLabelBackground || (this.darkMode ? darken(this.secondaryColor, 30) : this.secondaryColor);
		this.relationLabelColor = this.relationLabelColor || this.actorTextColor;
		this.requirementEdgeLabelBackground = "#16141F";
		this.git0 = this.git0 || this.primaryColor;
		this.git1 = this.git1 || this.secondaryColor;
		this.git2 = this.git2 || this.tertiaryColor;
		this.git3 = this.git3 || adjust(this.primaryColor, { h: -30 });
		this.git4 = this.git4 || adjust(this.primaryColor, { h: -60 });
		this.git5 = this.git5 || adjust(this.primaryColor, { h: -90 });
		this.git6 = this.git6 || adjust(this.primaryColor, { h: 60 });
		this.git7 = this.git7 || adjust(this.primaryColor, { h: 120 });
		if (this.darkMode) {
			this.git0 = lighten(this.git0, 25);
			this.git1 = lighten(this.git1, 25);
			this.git2 = lighten(this.git2, 25);
			this.git3 = lighten(this.git3, 25);
			this.git4 = lighten(this.git4, 25);
			this.git5 = lighten(this.git5, 25);
			this.git6 = lighten(this.git6, 25);
			this.git7 = lighten(this.git7, 25);
		} else {
			this.git0 = darken(this.git0, 25);
			this.git1 = darken(this.git1, 25);
			this.git2 = darken(this.git2, 25);
			this.git3 = darken(this.git3, 25);
			this.git4 = darken(this.git4, 25);
			this.git5 = darken(this.git5, 25);
			this.git6 = darken(this.git6, 25);
			this.git7 = darken(this.git7, 25);
		}
		this.gitInv0 = this.gitInv0 || invert(this.git0);
		this.gitInv1 = this.gitInv1 || invert(this.git1);
		this.gitInv2 = this.gitInv2 || invert(this.git2);
		this.gitInv3 = this.gitInv3 || invert(this.git3);
		this.gitInv4 = this.gitInv4 || invert(this.git4);
		this.gitInv5 = this.gitInv5 || invert(this.git5);
		this.gitInv6 = this.gitInv6 || invert(this.git6);
		this.gitInv7 = this.gitInv7 || invert(this.git7);
		this.branchLabelColor = this.branchLabelColor || (this.darkMode ? "black" : this.labelTextColor);
		this.gitBranchLabel0 = this.gitBranchLabel0 || this.branchLabelColor;
		this.gitBranchLabel1 = this.gitBranchLabel1 || this.branchLabelColor;
		this.gitBranchLabel2 = this.gitBranchLabel2 || this.branchLabelColor;
		this.gitBranchLabel3 = this.gitBranchLabel3 || this.branchLabelColor;
		this.gitBranchLabel4 = this.gitBranchLabel4 || this.branchLabelColor;
		this.gitBranchLabel5 = this.gitBranchLabel5 || this.branchLabelColor;
		this.gitBranchLabel6 = this.gitBranchLabel6 || this.branchLabelColor;
		this.gitBranchLabel7 = this.gitBranchLabel7 || this.branchLabelColor;
		this.tagLabelColor = this.tagLabelColor || this.primaryTextColor;
		this.tagLabelBackground = this.tagLabelBackground || this.primaryColor;
		this.tagLabelBorder = this.tagBorder || this.primaryBorderColor;
		this.tagLabelFontSize = this.tagLabelFontSize || "10px";
		this.commitLabelColor = this.commitLabelColor || this.secondaryTextColor;
		this.commitLabelBackground = this.commitLabelBackground || this.secondaryColor;
		this.commitLabelFontSize = this.commitLabelFontSize || "10px";
		this.commitLineColor = this.commitLineColor ?? "#BDBCCC";
		this.erEdgeLabelBackground = "#16141F";
		this.attributeBackgroundColorOdd = this.attributeBackgroundColorOdd || oldAttributeBackgroundColorOdd;
		this.attributeBackgroundColorEven = this.attributeBackgroundColorEven || oldAttributeBackgroundColorEven;
	}
	calculate(overrides) {
		if (typeof overrides !== "object") {
			this.updateColors();
			return;
		}
		const keys = Object.keys(overrides);
		keys.forEach((k) => {
			this[k] = overrides[k];
		});
		this.updateColors();
		keys.forEach((k) => {
			this[k] = overrides[k];
		});
	}
};
var getThemeVariables9 = /* @__PURE__ */ __name((userOverrides) => {
	const theme = new Theme9();
	theme.calculate(userOverrides);
	return theme;
}, "getThemeVariables");
var Theme10 = class {
	static {
		__name(this, "Theme");
	}
	constructor() {
		this.background = "#ffffff";
		this.primaryColor = "#cccccc";
		this.mainBkg = "#ffffff";
		this.noteBkgColor = "#fff5ad";
		this.noteTextColor = "#28253D";
		this.THEME_COLOR_LIMIT = 12;
		this.radius = 12;
		this.strokeWidth = 2;
		this.primaryBorderColor = mkBorder(this.primaryColor, this.darkMode);
		this.fontFamily = "\"Recursive Variable\", arial, sans-serif";
		this.fontSize = "14px";
		this.nodeBorder = "#28253D";
		this.stateBorder = "#28253D";
		this.useGradient = false;
		this.gradientStart = "#0042eb";
		this.gradientStop = "#eb0042";
		this.dropShadow = "url(#drop-shadow)";
		this.nodeShadow = true;
		this.tertiaryColor = "#ffffff";
		this.archEdgeColor = "calculated";
		this.archEdgeArrowColor = "calculated";
		this.archEdgeWidth = "3";
		this.archGroupBorderColor = this.primaryBorderColor;
		this.archGroupBorderWidth = "2px";
		this.actorBorder = "#28253D";
		this.noteBorderColor = "#FACC15";
		this.noteFontWeight = 600;
		this.borderColorArray = [
			"#E879F9",
			"#2DD4BF",
			"#FB923C",
			"#22D3EE",
			"#4ADE80",
			"#A78BFA",
			"#F87171",
			"#FACC15",
			"#818CF8",
			"#A3E635 ",
			"#38BDF8",
			"#FB7185"
		];
		this.bkgColorArray = [
			"#FDF4FF",
			"#F0FDFA",
			"#FFF7ED",
			"#ECFEFF",
			"#F0FDF4",
			"#F5F3FF",
			"#FEF2F2",
			"#FEFCE8",
			"#EEF2FF",
			"#F7FEE7",
			"#F0F9FF",
			"#FFF1F2"
		];
		this.filterColor = "#000000";
	}
	updateColors() {
		this.primaryTextColor = this.primaryTextColor || (this.darkMode ? "#eee" : "#28253D");
		this.secondaryColor = this.secondaryColor || adjust(this.primaryColor, { h: -120 });
		this.tertiaryColor = this.tertiaryColor || adjust(this.primaryColor, {
			h: 180,
			l: 5
		});
		this.primaryBorderColor = this.primaryBorderColor || mkBorder(this.primaryColor, this.darkMode);
		this.secondaryBorderColor = this.secondaryBorderColor || mkBorder(this.secondaryColor, this.darkMode);
		this.tertiaryBorderColor = this.tertiaryBorderColor || mkBorder(this.tertiaryColor, this.darkMode);
		this.noteBorderColor = this.noteBorderColor || mkBorder(this.noteBkgColor, this.darkMode);
		this.noteBkgColor = this.noteBkgColor || "#fff5ad";
		this.noteTextColor = this.noteTextColor || "#28253D";
		this.secondaryTextColor = this.secondaryTextColor || invert(this.secondaryColor);
		this.tertiaryTextColor = this.tertiaryTextColor || invert(this.tertiaryColor);
		this.lineColor = this.lineColor || invert(this.background);
		this.arrowheadColor = this.arrowheadColor || invert(this.background);
		this.textColor = this.textColor || this.primaryTextColor;
		this.border2 = this.border2 || this.tertiaryBorderColor;
		this.nodeBkg = this.nodeBkg || this.primaryColor;
		this.mainBkg = this.mainBkg || this.primaryColor;
		this.nodeBorder = this.nodeBorder || this.primaryBorderColor;
		this.clusterBkg = this.clusterBkg || this.tertiaryColor;
		this.clusterBorder = this.clusterBorder || this.tertiaryBorderColor;
		this.defaultLinkColor = this.defaultLinkColor || this.lineColor;
		this.titleColor = this.titleColor || this.tertiaryTextColor;
		this.edgeLabelBackground = this.edgeLabelBackground || (this.darkMode ? darken(this.secondaryColor, 30) : this.secondaryColor);
		this.nodeTextColor = this.nodeTextColor || this.primaryTextColor;
		this.actorBorder = this.actorBorder || this.primaryBorderColor;
		this.actorBkg = this.actorBkg || this.mainBkg;
		this.actorTextColor = this.actorTextColor || this.primaryTextColor;
		this.actorLineColor = this.actorLineColor || this.actorBorder;
		this.labelBoxBkgColor = this.labelBoxBkgColor || this.actorBkg;
		this.signalColor = this.signalColor || this.textColor;
		this.signalTextColor = this.signalTextColor || this.textColor;
		this.labelBoxBorderColor = this.labelBoxBorderColor || this.actorBorder;
		this.labelTextColor = this.labelTextColor || this.actorTextColor;
		this.loopTextColor = this.loopTextColor || this.actorTextColor;
		this.activationBorderColor = this.activationBorderColor || darken(this.secondaryColor, 10);
		this.activationBkgColor = this.activationBkgColor || this.secondaryColor;
		this.sequenceNumberColor = this.sequenceNumberColor || invert(this.lineColor);
		const primaryColor = "#ECECFE";
		const secondaryColor = "#E9E9F1";
		const tertiaryColor = adjust(primaryColor, {
			h: 180,
			l: 5
		});
		this.sectionBkgColor = this.sectionBkgColor || tertiaryColor;
		this.altSectionBkgColor = this.altSectionBkgColor || "white";
		this.sectionBkgColor = this.sectionBkgColor || secondaryColor;
		this.sectionBkgColor2 = this.sectionBkgColor2 || primaryColor;
		this.excludeBkgColor = this.excludeBkgColor || "#eeeeee";
		this.taskBorderColor = this.taskBorderColor || this.primaryBorderColor;
		this.taskBkgColor = this.taskBkgColor || primaryColor;
		this.activeTaskBorderColor = this.activeTaskBorderColor || primaryColor;
		this.activeTaskBkgColor = this.activeTaskBkgColor || lighten(primaryColor, 23);
		this.gridColor = this.gridColor || "lightgrey";
		this.doneTaskBkgColor = this.doneTaskBkgColor || "lightgrey";
		this.doneTaskBorderColor = this.doneTaskBorderColor || "grey";
		this.critBorderColor = this.critBorderColor || "#ff8888";
		this.critBkgColor = this.critBkgColor || "red";
		this.todayLineColor = this.todayLineColor || "red";
		this.taskTextColor = this.taskTextColor || this.textColor;
		this.vertLineColor = this.vertLineColor || this.primaryBorderColor;
		this.taskTextOutsideColor = this.taskTextOutsideColor || this.textColor;
		this.taskTextLightColor = this.taskTextLightColor || this.textColor;
		this.taskTextColor = this.taskTextColor || this.primaryTextColor;
		this.taskTextDarkColor = this.taskTextDarkColor || this.textColor;
		this.taskTextClickableColor = this.taskTextClickableColor || "#003163";
		this.archEdgeColor = this.lineColor;
		this.archEdgeArrowColor = this.lineColor;
		this.personBorder = this.personBorder || this.primaryBorderColor;
		this.personBkg = this.personBkg || this.mainBkg;
		this.transitionColor = this.transitionColor || this.lineColor;
		this.transitionLabelColor = this.transitionLabelColor || this.textColor;
		this.stateLabelColor = this.stateLabelColor || this.stateBkg || this.primaryTextColor;
		this.stateBkg = this.stateBkg || this.mainBkg;
		this.labelBackgroundColor = this.labelBackgroundColor || this.stateBkg;
		this.compositeBackground = this.compositeBackground || this.background || this.tertiaryColor;
		this.altBackground = this.altBackground || "#f0f0f0";
		this.compositeTitleBackground = this.compositeTitleBackground || this.mainBkg;
		this.compositeBorder = this.compositeBorder || this.nodeBorder;
		this.innerEndBackground = this.nodeBorder;
		this.errorBkgColor = this.errorBkgColor || this.tertiaryColor;
		this.errorTextColor = this.errorTextColor || this.tertiaryTextColor;
		this.transitionColor = this.transitionColor || this.lineColor;
		this.specialStateColor = this.lineColor;
		this.cScale0 = this.cScale0 || "#f4a8ff";
		this.cScale1 = this.cScale1 || "#46ecd5";
		this.cScale2 = this.cScale2 || "#ffb86a";
		this.cScale3 = this.cScale3 || "#dab2ff";
		this.cScale4 = this.cScale4 || "#7bf1a8";
		this.cScale5 = this.cScale5 || "#c4b4ff";
		this.cScale6 = this.cScale6 || "#ffa2a2";
		this.cScale7 = this.cScale7 || "#ffdf20";
		this.cScale8 = this.cScale8 || "#a3b3ff";
		this.cScale9 = this.cScale9 || "#bbf451";
		this.cScale10 = this.cScale10 || "#74d4ff";
		this.cScale11 = this.cScale11 || "#ffa1ad";
		for (let i = 0; i < this.THEME_COLOR_LIMIT; i++) this["cScaleInv" + i] = this["cScaleInv" + i] || invert(this["cScale" + i]);
		for (let i = 0; i < this.THEME_COLOR_LIMIT; i++) if (this.darkMode) this["cScalePeer" + i] = this["cScalePeer" + i] || lighten(this["cScale" + i], 10);
		else this["cScalePeer" + i] = this["cScalePeer" + i] || darken(this["cScale" + i], 10);
		this.scaleLabelColor = this.scaleLabelColor || this.labelTextColor;
		for (let i = 0; i < this.THEME_COLOR_LIMIT; i++) this["cScaleLabel" + i] = this["cScaleLabel" + i] || this.scaleLabelColor;
		const multiplier = this.darkMode ? -4 : -1;
		for (let i = 0; i < 5; i++) {
			this["surface" + i] = this["surface" + i] || adjust(this.mainBkg, {
				h: 180,
				s: -15,
				l: multiplier * (5 + i * 3)
			});
			this["surfacePeer" + i] = this["surfacePeer" + i] || adjust(this.mainBkg, {
				h: 180,
				s: -15,
				l: multiplier * (8 + i * 3)
			});
		}
		this.classText = this.classText || this.textColor;
		this.fillType0 = this.fillType0 || primaryColor;
		this.fillType1 = this.fillType1 || secondaryColor;
		this.fillType2 = this.fillType2 || adjust(primaryColor, { h: 64 });
		this.fillType3 = this.fillType3 || adjust(secondaryColor, { h: 64 });
		this.fillType4 = this.fillType4 || adjust(primaryColor, { h: -64 });
		this.fillType5 = this.fillType5 || adjust(secondaryColor, { h: -64 });
		this.fillType6 = this.fillType6 || adjust(primaryColor, { h: 128 });
		this.fillType7 = this.fillType7 || adjust(secondaryColor, { h: 128 });
		this.pie1 = this.pie1 || primaryColor;
		this.pie2 = this.pie2 || secondaryColor;
		this.pie3 = this.pie3 || tertiaryColor;
		this.pie4 = this.pie4 || adjust(primaryColor, { l: -10 });
		this.pie5 = this.pie5 || adjust(secondaryColor, { l: -10 });
		this.pie6 = this.pie6 || adjust(tertiaryColor, { l: -10 });
		this.pie7 = this.pie7 || adjust(primaryColor, {
			h: 60,
			l: -10
		});
		this.pie8 = this.pie8 || adjust(primaryColor, {
			h: -60,
			l: -10
		});
		this.pie9 = this.pie9 || adjust(primaryColor, {
			h: 120,
			l: 0
		});
		this.pie10 = this.pie10 || adjust(primaryColor, {
			h: 60,
			l: -20
		});
		this.pie11 = this.pie11 || adjust(primaryColor, {
			h: -60,
			l: -20
		});
		this.pie12 = this.pie12 || adjust(primaryColor, {
			h: 120,
			l: -10
		});
		this.pieTitleTextSize = this.pieTitleTextSize || "25px";
		this.pieTitleTextColor = this.pieTitleTextColor || this.taskTextDarkColor;
		this.pieSectionTextSize = this.pieSectionTextSize || "17px";
		this.pieSectionTextColor = this.pieSectionTextColor || this.textColor;
		this.pieLegendTextSize = this.pieLegendTextSize || "17px";
		this.pieLegendTextColor = this.pieLegendTextColor || this.taskTextDarkColor;
		this.pieStrokeColor = this.pieStrokeColor || "black";
		this.pieStrokeWidth = this.pieStrokeWidth || "2px";
		this.pieOuterStrokeWidth = this.pieOuterStrokeWidth || "2px";
		this.pieOuterStrokeColor = this.pieOuterStrokeColor || "black";
		this.pieOpacity = this.pieOpacity || "0.7";
		this.vennTitleTextColor = this.vennTitleTextColor ?? this.titleColor;
		this.vennSetTextColor = this.vennSetTextColor ?? this.textColor;
		this.quadrant1Fill = this.quadrant1Fill || primaryColor;
		this.quadrant2Fill = this.quadrant2Fill || adjust(primaryColor, {
			r: 5,
			g: 5,
			b: 5
		});
		this.quadrant3Fill = this.quadrant3Fill || adjust(primaryColor, {
			r: 10,
			g: 10,
			b: 10
		});
		this.quadrant4Fill = this.quadrant4Fill || adjust(primaryColor, {
			r: 15,
			g: 15,
			b: 15
		});
		this.quadrant1TextFill = this.quadrant1TextFill || this.primaryTextColor;
		this.quadrant2TextFill = this.quadrant2TextFill || adjust(this.primaryTextColor, {
			r: -5,
			g: -5,
			b: -5
		});
		this.quadrant3TextFill = this.quadrant3TextFill || adjust(this.primaryTextColor, {
			r: -10,
			g: -10,
			b: -10
		});
		this.quadrant4TextFill = this.quadrant4TextFill || adjust(this.primaryTextColor, {
			r: -15,
			g: -15,
			b: -15
		});
		this.quadrantPointFill = this.quadrantPointFill || isDark(this.quadrant1Fill) ? lighten(this.quadrant1Fill) : darken(this.quadrant1Fill);
		this.quadrantPointTextFill = this.quadrantPointTextFill || this.primaryTextColor;
		this.quadrantXAxisTextFill = this.quadrantXAxisTextFill || this.primaryTextColor;
		this.quadrantYAxisTextFill = this.quadrantYAxisTextFill || this.primaryTextColor;
		this.quadrantInternalBorderStrokeFill = this.quadrantInternalBorderStrokeFill || this.primaryBorderColor;
		this.quadrantExternalBorderStrokeFill = this.quadrantExternalBorderStrokeFill || this.primaryBorderColor;
		this.quadrantTitleFill = this.quadrantTitleFill || this.primaryTextColor;
		this.xyChart = {
			backgroundColor: this.xyChart?.backgroundColor || this.background,
			titleColor: this.xyChart?.titleColor || this.primaryTextColor,
			xAxisTitleColor: this.xyChart?.xAxisTitleColor || this.primaryTextColor,
			xAxisLabelColor: this.xyChart?.xAxisLabelColor || this.primaryTextColor,
			xAxisTickColor: this.xyChart?.xAxisTickColor || this.primaryTextColor,
			xAxisLineColor: this.xyChart?.xAxisLineColor || this.primaryTextColor,
			yAxisTitleColor: this.xyChart?.yAxisTitleColor || this.primaryTextColor,
			yAxisLabelColor: this.xyChart?.yAxisLabelColor || this.primaryTextColor,
			yAxisTickColor: this.xyChart?.yAxisTickColor || this.primaryTextColor,
			yAxisLineColor: this.xyChart?.yAxisLineColor || this.primaryTextColor,
			plotColorPalette: this.xyChart?.plotColorPalette || "#FFF4DD,#FFD8B1,#FFA07A,#ECEFF1,#D6DBDF,#C3E0A8,#FFB6A4,#FFD74D,#738FA7,#FFFFF0"
		};
		this.requirementBackground = this.requirementBackground || primaryColor;
		this.requirementBorderColor = this.requirementBorderColor || this.primaryBorderColor;
		this.requirementBorderSize = this.requirementBorderSize || "1";
		this.requirementTextColor = this.requirementTextColor || this.primaryTextColor;
		this.relationColor = this.relationColor || this.lineColor;
		this.relationLabelBackground = this.relationLabelBackground || (this.darkMode ? darken(this.secondaryColor, 30) : this.secondaryColor);
		this.relationLabelColor = this.relationLabelColor || this.actorTextColor;
		this.git0 = this.git0 || primaryColor;
		this.git1 = this.git1 || secondaryColor;
		this.git2 = this.git2 || tertiaryColor;
		this.git3 = this.git3 || adjust(primaryColor, { h: -30 });
		this.git4 = this.git4 || adjust(primaryColor, { h: -60 });
		this.git5 = this.git5 || adjust(primaryColor, { h: -90 });
		this.git6 = this.git6 || adjust(primaryColor, { h: 60 });
		this.git7 = this.git7 || adjust(primaryColor, { h: 120 });
		if (this.darkMode) {
			this.git0 = lighten(this.git0, 25);
			this.git1 = lighten(this.git1, 25);
			this.git2 = lighten(this.git2, 25);
			this.git3 = lighten(this.git3, 25);
			this.git4 = lighten(this.git4, 25);
			this.git5 = lighten(this.git5, 25);
			this.git6 = lighten(this.git6, 25);
			this.git7 = lighten(this.git7, 25);
		} else {
			this.git0 = darken(this.git0, 25);
			this.git1 = darken(this.git1, 25);
			this.git2 = darken(this.git2, 25);
			this.git3 = darken(this.git3, 25);
			this.git4 = darken(this.git4, 25);
			this.git5 = darken(this.git5, 25);
			this.git6 = darken(this.git6, 25);
			this.git7 = darken(this.git7, 25);
		}
		this.gitInv0 = this.gitInv0 || invert(this.git0);
		this.gitInv1 = this.gitInv1 || invert(this.git1);
		this.gitInv2 = this.gitInv2 || invert(this.git2);
		this.gitInv3 = this.gitInv3 || invert(this.git3);
		this.gitInv4 = this.gitInv4 || invert(this.git4);
		this.gitInv5 = this.gitInv5 || invert(this.git5);
		this.gitInv6 = this.gitInv6 || invert(this.git6);
		this.gitInv7 = this.gitInv7 || invert(this.git7);
		this.branchLabelColor = this.branchLabelColor || (this.darkMode ? "black" : this.labelTextColor);
		this.gitBranchLabel0 = this.gitBranchLabel0 || this.branchLabelColor;
		this.gitBranchLabel1 = this.gitBranchLabel1 || this.branchLabelColor;
		this.gitBranchLabel2 = this.gitBranchLabel2 || this.branchLabelColor;
		this.gitBranchLabel3 = this.gitBranchLabel3 || this.branchLabelColor;
		this.gitBranchLabel4 = this.gitBranchLabel4 || this.branchLabelColor;
		this.gitBranchLabel5 = this.gitBranchLabel5 || this.branchLabelColor;
		this.gitBranchLabel6 = this.gitBranchLabel6 || this.branchLabelColor;
		this.gitBranchLabel7 = this.gitBranchLabel7 || this.branchLabelColor;
		this.tagLabelColor = this.tagLabelColor || this.primaryTextColor;
		this.tagLabelBackground = this.tagLabelBackground || this.primaryColor;
		this.tagLabelBorder = this.tagBorder || this.primaryBorderColor;
		this.tagLabelFontSize = this.tagLabelFontSize || "10px";
		this.commitLabelColor = this.commitLabelColor || this.secondaryTextColor;
		this.commitLabelBackground = this.commitLabelBackground || this.secondaryColor;
		this.commitLineColor = this.commitLineColor ?? "#BDBCCC";
		this.commitLabelFontSize = this.commitLabelFontSize || "10px";
		this.fontWeight = 600;
		this.erEdgeLabelBackground = "#FFFFFF";
		this.attributeBackgroundColorOdd = this.attributeBackgroundColorOdd || oldAttributeBackgroundColorOdd;
		this.attributeBackgroundColorEven = this.attributeBackgroundColorEven || oldAttributeBackgroundColorEven;
	}
	calculate(overrides) {
		if (typeof overrides !== "object") {
			this.updateColors();
			return;
		}
		const keys = Object.keys(overrides);
		keys.forEach((k) => {
			this[k] = overrides[k];
		});
		this.updateColors();
		keys.forEach((k) => {
			this[k] = overrides[k];
		});
	}
};
var getThemeVariables10 = /* @__PURE__ */ __name((userOverrides) => {
	const theme = new Theme10();
	theme.calculate(userOverrides);
	return theme;
}, "getThemeVariables");
var Theme11 = class {
	static {
		__name(this, "Theme");
	}
	constructor() {
		this.background = "#333";
		this.primaryColor = "#1f2020";
		this.secondaryColor = lighten(this.primaryColor, 16);
		this.tertiaryColor = adjust(this.primaryColor, { h: -160 });
		this.primaryBorderColor = invert(this.background);
		this.secondaryBorderColor = mkBorder(this.secondaryColor, this.darkMode);
		this.tertiaryBorderColor = mkBorder(this.tertiaryColor, this.darkMode);
		this.primaryTextColor = invert(this.primaryColor);
		this.secondaryTextColor = invert(this.secondaryColor);
		this.tertiaryTextColor = invert(this.tertiaryColor);
		this.mainBkg = "#111113";
		this.secondBkg = "calculated";
		this.mainContrastColor = "lightgrey";
		this.darkTextColor = lighten(invert("#323D47"), 10);
		this.border1 = "#ccc";
		this.border2 = rgba(255, 255, 255, .25);
		this.arrowheadColor = invert(this.background);
		this.fontFamily = "\"Recursive Variable\", arial, sans-serif";
		this.fontSize = "14px";
		this.labelBackground = "#111113";
		this.textColor = "#ccc";
		this.THEME_COLOR_LIMIT = 12;
		this.radius = 12;
		this.strokeWidth = 2;
		this.noteBkgColor = this.noteBkgColor ?? "#FEF9C3";
		this.noteTextColor = this.noteTextColor ?? "#28253D";
		this.THEME_COLOR_LIMIT = 12;
		this.fontFamily = "\"Recursive Variable\", arial, sans-serif";
		this.fontSize = "14px";
		this.nodeBorder = "#FFFFFF";
		this.stateBorder = "#FFFFFF";
		this.useGradient = false;
		this.gradientStart = "#0042eb";
		this.gradientStop = "#eb0042";
		this.dropShadow = "url(#drop-shadow)";
		this.nodeShadow = true;
		this.archEdgeColor = "calculated";
		this.archEdgeArrowColor = "calculated";
		this.archEdgeWidth = "3";
		this.archGroupBorderColor = this.primaryBorderColor;
		this.archGroupBorderWidth = "2px";
		this.clusterBkg = "#1E1A2E";
		this.clusterBorder = "#BDBCCC";
		this.noteBorderColor = "#FACC15";
		this.noteFontWeight = 600;
		this.borderColorArray = [
			"#E879F9",
			"#2DD4BF",
			"#FB923C",
			"#22D3EE",
			"#4ADE80",
			"#A78BFA",
			"#F87171",
			"#FACC15",
			"#818CF8",
			"#A3E635 ",
			"#38BDF8",
			"#FB7185"
		];
		this.bkgColorArray = [];
		this.filterColor = "#FFFFFF";
	}
	updateColors() {
		this.primaryTextColor = this.primaryTextColor || (this.darkMode ? "#eee" : "#FFFFFF");
		this.secondaryColor = this.secondaryColor || adjust(this.primaryColor, { h: -120 });
		this.tertiaryColor = this.tertiaryColor || adjust(this.primaryColor, {
			h: 180,
			l: 5
		});
		this.primaryBorderColor = this.primaryBorderColor || mkBorder(this.primaryColor, this.darkMode);
		this.secondaryBorderColor = this.secondaryBorderColor || mkBorder(this.secondaryColor, this.darkMode);
		this.tertiaryBorderColor = this.tertiaryBorderColor || mkBorder(this.tertiaryColor, this.darkMode);
		this.noteBorderColor = this.noteBorderColor || mkBorder(this.noteBkgColor, this.darkMode);
		this.noteBkgColor = this.noteBkgColor || "#fff5ad";
		this.noteTextColor = this.noteTextColor || "#FFFFFF";
		this.secondaryTextColor = this.secondaryTextColor || invert(this.secondaryColor);
		this.tertiaryTextColor = this.tertiaryTextColor || invert(this.tertiaryColor);
		this.lineColor = this.lineColor || invert(this.background);
		this.arrowheadColor = this.arrowheadColor || invert(this.background);
		this.textColor = this.textColor || this.primaryTextColor;
		this.border2 = this.border2 || this.tertiaryBorderColor;
		this.nodeBkg = this.nodeBkg || this.primaryColor;
		this.mainBkg = this.mainBkg || this.primaryColor;
		this.nodeBorder = this.nodeBorder || this.border1;
		this.clusterBkg = this.clusterBkg || this.tertiaryColor;
		this.clusterBorder = this.clusterBorder || this.tertiaryBorderColor;
		this.defaultLinkColor = this.defaultLinkColor || this.lineColor;
		this.titleColor = this.titleColor || this.tertiaryTextColor;
		this.edgeLabelBackground = this.edgeLabelBackground || (this.darkMode ? darken(this.secondaryColor, 30) : this.secondaryColor);
		this.nodeTextColor = this.nodeTextColor || this.primaryTextColor;
		this.actorBorder = "#FFFFFF";
		this.signalColor = "#FFFFFF";
		this.labelBoxBorderColor = "#BDBCCC";
		this.actorBorder = this.actorBorder || this.primaryBorderColor;
		this.actorBkg = this.actorBkg || this.mainBkg;
		this.actorTextColor = this.actorTextColor || this.primaryTextColor;
		this.actorLineColor = this.actorLineColor || this.actorBorder;
		this.labelBoxBkgColor = this.labelBoxBkgColor || this.actorBkg;
		this.signalColor = this.signalColor || this.textColor;
		this.signalTextColor = this.signalTextColor || this.textColor;
		this.labelBoxBorderColor = this.labelBoxBorderColor || this.actorBorder;
		this.labelTextColor = this.labelTextColor || this.actorTextColor;
		this.loopTextColor = this.loopTextColor || this.actorTextColor;
		this.activationBorderColor = this.activationBorderColor || darken(this.secondaryColor, 10);
		this.activationBkgColor = this.activationBkgColor || this.secondaryColor;
		this.sequenceNumberColor = this.sequenceNumberColor || invert(this.lineColor);
		this.rootLabelColor = "#FFFFFF";
		this.sectionBkgColor = this.sectionBkgColor || this.tertiaryColor;
		this.altSectionBkgColor = this.altSectionBkgColor || "white";
		this.sectionBkgColor = this.sectionBkgColor || this.secondaryColor;
		this.sectionBkgColor2 = this.sectionBkgColor2 || this.primaryColor;
		this.excludeBkgColor = this.excludeBkgColor || "#eeeeee";
		this.taskBorderColor = this.taskBorderColor || this.primaryBorderColor;
		this.taskBkgColor = this.taskBkgColor || this.primaryColor;
		this.activeTaskBorderColor = this.activeTaskBorderColor || this.primaryColor;
		this.activeTaskBkgColor = this.activeTaskBkgColor || lighten(this.primaryColor, 23);
		this.gridColor = this.gridColor || "lightgrey";
		this.doneTaskBkgColor = this.doneTaskBkgColor || "lightgrey";
		this.doneTaskBorderColor = this.doneTaskBorderColor || "grey";
		this.critBorderColor = this.critBorderColor || "#ff8888";
		this.critBkgColor = this.critBkgColor || "red";
		this.todayLineColor = this.todayLineColor || "red";
		this.taskTextColor = this.taskTextColor || this.textColor;
		this.vertLineColor = this.vertLineColor || this.primaryBorderColor;
		this.taskTextOutsideColor = this.taskTextOutsideColor || this.textColor;
		this.taskTextLightColor = this.taskTextLightColor || this.textColor;
		this.taskTextColor = this.taskTextColor || this.primaryTextColor;
		this.taskTextDarkColor = this.taskTextDarkColor || this.textColor;
		this.taskTextClickableColor = this.taskTextClickableColor || "#003163";
		this.archEdgeColor = this.lineColor;
		this.archEdgeArrowColor = this.lineColor;
		this.personBorder = this.personBorder || this.primaryBorderColor;
		this.personBkg = this.personBkg || this.mainBkg;
		this.transitionColor = this.transitionColor || this.lineColor;
		this.transitionLabelColor = this.transitionLabelColor || this.textColor;
		this.stateLabelColor = this.stateLabelColor || this.stateBkg || this.primaryTextColor;
		this.stateBkg = this.stateBkg || this.mainBkg;
		this.labelBackgroundColor = this.labelBackgroundColor || this.stateBkg;
		this.compositeBackground = this.compositeBackground || this.background || this.tertiaryColor;
		this.altBackground = this.altBackground || "#f0f0f0";
		this.compositeTitleBackground = this.compositeTitleBackground || this.mainBkg;
		this.compositeBorder = this.compositeBorder || this.nodeBorder;
		this.innerEndBackground = this.nodeBorder;
		this.errorBkgColor = this.errorBkgColor || this.tertiaryColor;
		this.errorTextColor = this.errorTextColor || this.tertiaryTextColor;
		this.transitionColor = this.transitionColor || this.lineColor;
		this.specialStateColor = this.lineColor;
		this.cScale0 = this.cScale0 || "#f4a8ff";
		this.cScale1 = this.cScale1 || "#46ecd5";
		this.cScale2 = this.cScale2 || "#ffb86a";
		this.cScale3 = this.cScale3 || "#dab2ff";
		this.cScale4 = this.cScale4 || "#7bf1a8";
		this.cScale5 = this.cScale5 || "#c4b4ff";
		this.cScale6 = this.cScale6 || "#ffa2a2";
		this.cScale7 = this.cScale7 || "#ffdf20";
		this.cScale8 = this.cScale8 || "#a3b3ff";
		this.cScale9 = this.cScale9 || "#bbf451";
		this.cScale10 = this.cScale10 || "#74d4ff";
		this.cScale11 = this.cScale11 || "#ffa1ad";
		for (let i = 0; i < this.THEME_COLOR_LIMIT; i++) this["cScaleInv" + i] = this["cScaleInv" + i] || invert(this["cScale" + i]);
		for (let i = 0; i < this.THEME_COLOR_LIMIT; i++) if (this.darkMode) this["cScalePeer" + i] = this["cScalePeer" + i] || lighten(this["cScale" + i], 10);
		else this["cScalePeer" + i] = this["cScalePeer" + i] || darken(this["cScale" + i], 10);
		this.scaleLabelColor = this.scaleLabelColor || this.labelTextColor;
		for (let i = 0; i < this.THEME_COLOR_LIMIT; i++) this["cScaleLabel" + i] = darken(this["cScale" + i], 75);
		const multiplier = this.darkMode ? -4 : -1;
		for (let i = 0; i < 5; i++) {
			this["surface" + i] = this["surface" + i] || adjust(this.mainBkg, {
				h: 180,
				s: -15,
				l: multiplier * (5 + i * 3)
			});
			this["surfacePeer" + i] = this["surfacePeer" + i] || adjust(this.mainBkg, {
				h: 180,
				s: -15,
				l: multiplier * (8 + i * 3)
			});
		}
		this.classText = this.classText || this.textColor;
		this.fillType0 = this.fillType0 || this.primaryColor;
		this.fillType1 = this.fillType1 || this.secondaryColor;
		this.fillType2 = this.fillType2 || adjust(this.primaryColor, { h: 64 });
		this.fillType3 = this.fillType3 || adjust(this.secondaryColor, { h: 64 });
		this.fillType4 = this.fillType4 || adjust(this.primaryColor, { h: -64 });
		this.fillType5 = this.fillType5 || adjust(this.secondaryColor, { h: -64 });
		this.fillType6 = this.fillType6 || adjust(this.primaryColor, { h: 128 });
		this.fillType7 = this.fillType7 || adjust(this.secondaryColor, { h: 128 });
		this.pie1 = this.pie1 || this.primaryColor;
		this.pie2 = this.pie2 || this.secondaryColor;
		this.pie3 = this.pie3 || this.tertiaryColor;
		this.pie4 = this.pie4 || adjust(this.primaryColor, { l: -10 });
		this.pie5 = this.pie5 || adjust(this.secondaryColor, { l: -10 });
		this.pie6 = this.pie6 || adjust(this.tertiaryColor, { l: -10 });
		this.pie7 = this.pie7 || adjust(this.primaryColor, {
			h: 60,
			l: -10
		});
		this.pie8 = this.pie8 || adjust(this.primaryColor, {
			h: -60,
			l: -10
		});
		this.pie9 = this.pie9 || adjust(this.primaryColor, {
			h: 120,
			l: 0
		});
		this.pie10 = this.pie10 || adjust(this.primaryColor, {
			h: 60,
			l: -20
		});
		this.pie11 = this.pie11 || adjust(this.primaryColor, {
			h: -60,
			l: -20
		});
		this.pie12 = this.pie12 || adjust(this.primaryColor, {
			h: 120,
			l: -10
		});
		this.pieTitleTextSize = this.pieTitleTextSize || "25px";
		this.pieTitleTextColor = this.pieTitleTextColor || this.taskTextDarkColor;
		this.pieSectionTextSize = this.pieSectionTextSize || "17px";
		this.pieSectionTextColor = this.pieSectionTextColor || this.textColor;
		this.pieLegendTextSize = this.pieLegendTextSize || "17px";
		this.pieLegendTextColor = this.pieLegendTextColor || this.taskTextDarkColor;
		this.pieStrokeColor = this.pieStrokeColor || "black";
		this.pieStrokeWidth = this.pieStrokeWidth || "2px";
		this.pieOuterStrokeWidth = this.pieOuterStrokeWidth || "2px";
		this.pieOuterStrokeColor = this.pieOuterStrokeColor || "black";
		this.pieOpacity = this.pieOpacity || "0.7";
		this.vennTitleTextColor = this.vennTitleTextColor ?? this.titleColor;
		this.vennSetTextColor = this.vennSetTextColor ?? this.textColor;
		this.quadrant1Fill = this.quadrant1Fill || this.primaryColor;
		this.quadrant2Fill = this.quadrant2Fill || adjust(this.primaryColor, {
			r: 5,
			g: 5,
			b: 5
		});
		this.quadrant3Fill = this.quadrant3Fill || adjust(this.primaryColor, {
			r: 10,
			g: 10,
			b: 10
		});
		this.quadrant4Fill = this.quadrant4Fill || adjust(this.primaryColor, {
			r: 15,
			g: 15,
			b: 15
		});
		this.quadrant1TextFill = this.quadrant1TextFill || this.primaryTextColor;
		this.quadrant2TextFill = this.quadrant2TextFill || adjust(this.primaryTextColor, {
			r: -5,
			g: -5,
			b: -5
		});
		this.quadrant3TextFill = this.quadrant3TextFill || adjust(this.primaryTextColor, {
			r: -10,
			g: -10,
			b: -10
		});
		this.quadrant4TextFill = this.quadrant4TextFill || adjust(this.primaryTextColor, {
			r: -15,
			g: -15,
			b: -15
		});
		this.quadrantPointFill = this.quadrantPointFill || isDark(this.quadrant1Fill) ? lighten(this.quadrant1Fill) : darken(this.quadrant1Fill);
		this.quadrantPointTextFill = this.quadrantPointTextFill || this.primaryTextColor;
		this.quadrantXAxisTextFill = this.quadrantXAxisTextFill || this.primaryTextColor;
		this.quadrantYAxisTextFill = this.quadrantYAxisTextFill || this.primaryTextColor;
		this.quadrantInternalBorderStrokeFill = this.quadrantInternalBorderStrokeFill || this.primaryBorderColor;
		this.quadrantExternalBorderStrokeFill = this.quadrantExternalBorderStrokeFill || this.primaryBorderColor;
		this.quadrantTitleFill = this.quadrantTitleFill || this.primaryTextColor;
		this.xyChart = {
			backgroundColor: this.xyChart?.backgroundColor || this.background,
			titleColor: this.xyChart?.titleColor || this.primaryTextColor,
			xAxisTitleColor: this.xyChart?.xAxisTitleColor || this.primaryTextColor,
			xAxisLabelColor: this.xyChart?.xAxisLabelColor || this.primaryTextColor,
			xAxisTickColor: this.xyChart?.xAxisTickColor || this.primaryTextColor,
			xAxisLineColor: this.xyChart?.xAxisLineColor || this.primaryTextColor,
			yAxisTitleColor: this.xyChart?.yAxisTitleColor || this.primaryTextColor,
			yAxisLabelColor: this.xyChart?.yAxisLabelColor || this.primaryTextColor,
			yAxisTickColor: this.xyChart?.yAxisTickColor || this.primaryTextColor,
			yAxisLineColor: this.xyChart?.yAxisLineColor || this.primaryTextColor,
			plotColorPalette: this.xyChart?.plotColorPalette || "#FFF4DD,#FFD8B1,#FFA07A,#ECEFF1,#D6DBDF,#C3E0A8,#FFB6A4,#FFD74D,#738FA7,#FFFFF0"
		};
		this.requirementBackground = this.requirementBackground || this.primaryColor;
		this.requirementBorderColor = this.requirementBorderColor || this.primaryBorderColor;
		this.requirementBorderSize = this.requirementBorderSize || "1";
		this.requirementTextColor = this.requirementTextColor || this.primaryTextColor;
		this.relationColor = this.relationColor || this.lineColor;
		this.relationLabelBackground = this.relationLabelBackground || (this.darkMode ? darken(this.secondaryColor, 30) : this.secondaryColor);
		this.relationLabelColor = this.relationLabelColor || this.actorTextColor;
		this.git0 = this.git0 || this.primaryColor;
		this.git1 = this.git1 || this.secondaryColor;
		this.git2 = this.git2 || this.tertiaryColor;
		this.git3 = this.git3 || adjust(this.primaryColor, { h: -30 });
		this.git4 = this.git4 || adjust(this.primaryColor, { h: -60 });
		this.git5 = this.git5 || adjust(this.primaryColor, { h: -90 });
		this.git6 = this.git6 || adjust(this.primaryColor, { h: 60 });
		this.git7 = this.git7 || adjust(this.primaryColor, { h: 120 });
		if (this.darkMode) {
			this.git0 = lighten(this.git0, 25);
			this.git1 = lighten(this.git1, 25);
			this.git2 = lighten(this.git2, 25);
			this.git3 = lighten(this.git3, 25);
			this.git4 = lighten(this.git4, 25);
			this.git5 = lighten(this.git5, 25);
			this.git6 = lighten(this.git6, 25);
			this.git7 = lighten(this.git7, 25);
		} else {
			this.git0 = darken(this.git0, 25);
			this.git1 = darken(this.git1, 25);
			this.git2 = darken(this.git2, 25);
			this.git3 = darken(this.git3, 25);
			this.git4 = darken(this.git4, 25);
			this.git5 = darken(this.git5, 25);
			this.git6 = darken(this.git6, 25);
			this.git7 = darken(this.git7, 25);
		}
		this.gitInv0 = this.gitInv0 || invert(this.git0);
		this.gitInv1 = this.gitInv1 || invert(this.git1);
		this.gitInv2 = this.gitInv2 || invert(this.git2);
		this.gitInv3 = this.gitInv3 || invert(this.git3);
		this.gitInv4 = this.gitInv4 || invert(this.git4);
		this.gitInv5 = this.gitInv5 || invert(this.git5);
		this.gitInv6 = this.gitInv6 || invert(this.git6);
		this.gitInv7 = this.gitInv7 || invert(this.git7);
		this.branchLabelColor = this.branchLabelColor || (this.darkMode ? "black" : this.labelTextColor);
		this.gitBranchLabel0 = this.gitBranchLabel0 || this.branchLabelColor;
		this.gitBranchLabel1 = this.gitBranchLabel1 || this.branchLabelColor;
		this.gitBranchLabel2 = this.gitBranchLabel2 || this.branchLabelColor;
		this.gitBranchLabel3 = this.gitBranchLabel3 || this.branchLabelColor;
		this.gitBranchLabel4 = this.gitBranchLabel4 || this.branchLabelColor;
		this.gitBranchLabel5 = this.gitBranchLabel5 || this.branchLabelColor;
		this.gitBranchLabel6 = this.gitBranchLabel6 || this.branchLabelColor;
		this.gitBranchLabel7 = this.gitBranchLabel7 || this.branchLabelColor;
		this.tagLabelColor = this.tagLabelColor || this.primaryTextColor;
		this.tagLabelBackground = this.tagLabelBackground || this.primaryColor;
		this.tagLabelBorder = this.tagBorder || this.primaryBorderColor;
		this.tagLabelFontSize = this.tagLabelFontSize || "10px";
		this.commitLabelColor = this.commitLabelColor || this.secondaryTextColor;
		this.commitLabelBackground = this.commitLabelBackground || this.secondaryColor;
		this.commitLabelFontSize = this.commitLabelFontSize || "10px";
		this.commitLineColor = this.commitLineColor ?? "#BDBCCC";
		this.fontWeight = 600;
		this.erEdgeLabelBackground = "#16141F";
		this.attributeBackgroundColorOdd = this.attributeBackgroundColorOdd || oldAttributeBackgroundColorOdd;
		this.attributeBackgroundColorEven = this.attributeBackgroundColorEven || oldAttributeBackgroundColorEven;
	}
	calculate(overrides) {
		if (typeof overrides !== "object") {
			this.updateColors();
			return;
		}
		const keys = Object.keys(overrides);
		keys.forEach((k) => {
			this[k] = overrides[k];
		});
		this.updateColors();
		keys.forEach((k) => {
			this[k] = overrides[k];
		});
	}
};
var themes_default = {
	base: { getThemeVariables },
	dark: { getThemeVariables: getThemeVariables2 },
	default: { getThemeVariables: getThemeVariables3 },
	forest: { getThemeVariables: getThemeVariables4 },
	neutral: { getThemeVariables: getThemeVariables5 },
	neo: { getThemeVariables: getThemeVariables6 },
	"neo-dark": { getThemeVariables: getThemeVariables7 },
	redux: { getThemeVariables: getThemeVariables8 },
	"redux-dark": { getThemeVariables: getThemeVariables9 },
	"redux-color": { getThemeVariables: getThemeVariables10 },
	"redux-dark-color": { getThemeVariables: /* @__PURE__ */ __name((userOverrides) => {
		const theme = new Theme11();
		theme.calculate(userOverrides);
		return theme;
	}, "getThemeVariables") }
};
var config_schema_default = {
	"flowchart": {
		"useMaxWidth": true,
		"titleTopMargin": 25,
		"subGraphTitleMargin": {
			"top": 0,
			"bottom": 0
		},
		"diagramPadding": 8,
		"htmlLabels": null,
		"nodeSpacing": 50,
		"rankSpacing": 50,
		"curve": "basis",
		"padding": 15,
		"defaultRenderer": "dagre-wrapper",
		"wrappingWidth": 200,
		"inheritDir": false
	},
	"sequence": {
		"useMaxWidth": true,
		"hideUnusedParticipants": false,
		"activationWidth": 10,
		"diagramMarginX": 50,
		"diagramMarginY": 10,
		"actorMargin": 50,
		"width": 150,
		"height": 65,
		"boxMargin": 10,
		"boxTextMargin": 5,
		"noteMargin": 10,
		"messageMargin": 35,
		"messageAlign": "center",
		"mirrorActors": true,
		"forceMenus": false,
		"bottomMarginAdj": 1,
		"rightAngles": false,
		"showSequenceNumbers": false,
		"actorFontSize": 14,
		"actorFontFamily": "\"Open Sans\", sans-serif",
		"actorFontWeight": 400,
		"noteFontSize": 14,
		"noteFontFamily": "\"trebuchet ms\", verdana, arial, sans-serif",
		"noteFontWeight": 400,
		"noteAlign": "center",
		"messageFontSize": 16,
		"messageFontFamily": "\"trebuchet ms\", verdana, arial, sans-serif",
		"messageFontWeight": 400,
		"wrap": false,
		"wrapPadding": 10,
		"labelBoxWidth": 50,
		"labelBoxHeight": 20
	},
	"gantt": {
		"useMaxWidth": true,
		"titleTopMargin": 25,
		"barHeight": 20,
		"barGap": 4,
		"topPadding": 50,
		"rightPadding": 75,
		"leftPadding": 75,
		"gridLineStartPadding": 35,
		"fontSize": 11,
		"sectionFontSize": 11,
		"numberSectionStyles": 4,
		"axisFormat": "%Y-%m-%d",
		"topAxis": false,
		"displayMode": "",
		"weekday": "sunday"
	},
	"journey": {
		"useMaxWidth": true,
		"diagramMarginX": 50,
		"diagramMarginY": 10,
		"leftMargin": 150,
		"maxLabelWidth": 360,
		"width": 150,
		"height": 50,
		"boxMargin": 10,
		"boxTextMargin": 5,
		"noteMargin": 10,
		"messageMargin": 35,
		"messageAlign": "center",
		"bottomMarginAdj": 1,
		"rightAngles": false,
		"taskFontSize": 14,
		"taskFontFamily": "\"Open Sans\", sans-serif",
		"taskMargin": 50,
		"activationWidth": 10,
		"textPlacement": "fo",
		"actorColours": [
			"#8FBC8F",
			"#7CFC00",
			"#00FFFF",
			"#20B2AA",
			"#B0E0E6",
			"#FFFFE0"
		],
		"sectionFills": [
			"#191970",
			"#8B008B",
			"#4B0082",
			"#2F4F4F",
			"#800000",
			"#8B4513",
			"#00008B"
		],
		"sectionColours": ["#fff"],
		"titleColor": "",
		"titleFontFamily": "\"trebuchet ms\", verdana, arial, sans-serif",
		"titleFontSize": "4ex"
	},
	"class": {
		"useMaxWidth": true,
		"titleTopMargin": 25,
		"arrowMarkerAbsolute": false,
		"dividerMargin": 10,
		"padding": 5,
		"textHeight": 10,
		"defaultRenderer": "dagre-wrapper",
		"htmlLabels": false,
		"hideEmptyMembersBox": false,
		"hierarchicalNamespaces": true
	},
	"state": {
		"useMaxWidth": true,
		"titleTopMargin": 25,
		"dividerMargin": 10,
		"sizeUnit": 5,
		"padding": 8,
		"textHeight": 10,
		"titleShift": -15,
		"noteMargin": 10,
		"forkWidth": 70,
		"forkHeight": 7,
		"miniPadding": 2,
		"fontSizeFactor": 5.02,
		"fontSize": 24,
		"labelHeight": 16,
		"edgeLengthFactor": "20",
		"compositTitleSize": 35,
		"radius": 5,
		"defaultRenderer": "dagre-wrapper"
	},
	"er": {
		"useMaxWidth": true,
		"titleTopMargin": 25,
		"diagramPadding": 20,
		"layoutDirection": "TB",
		"minEntityWidth": 100,
		"minEntityHeight": 75,
		"entityPadding": 15,
		"nodeSpacing": 140,
		"rankSpacing": 80,
		"stroke": "gray",
		"fill": "honeydew",
		"fontSize": 12
	},
	"pie": {
		"useMaxWidth": true,
		"textPosition": .75
	},
	"quadrantChart": {
		"useMaxWidth": true,
		"chartWidth": 500,
		"chartHeight": 500,
		"titleFontSize": 20,
		"titlePadding": 10,
		"quadrantPadding": 5,
		"xAxisLabelPadding": 5,
		"yAxisLabelPadding": 5,
		"xAxisLabelFontSize": 16,
		"yAxisLabelFontSize": 16,
		"quadrantLabelFontSize": 16,
		"quadrantTextTopPadding": 5,
		"pointTextPadding": 5,
		"pointLabelFontSize": 12,
		"pointRadius": 5,
		"xAxisPosition": "top",
		"yAxisPosition": "left",
		"quadrantInternalBorderStrokeWidth": 1,
		"quadrantExternalBorderStrokeWidth": 2
	},
	"xyChart": {
		"useMaxWidth": true,
		"width": 700,
		"height": 500,
		"titleFontSize": 20,
		"titlePadding": 10,
		"showDataLabel": false,
		"showDataLabelOutsideBar": false,
		"showTitle": true,
		"xAxis": {
			"$ref": "#/$defs/XYChartAxisConfig",
			"showLabel": true,
			"labelFontSize": 14,
			"labelPadding": 5,
			"showTitle": true,
			"titleFontSize": 16,
			"titlePadding": 5,
			"showTick": true,
			"tickLength": 5,
			"tickWidth": 2,
			"showAxisLine": true,
			"axisLineWidth": 2
		},
		"yAxis": {
			"$ref": "#/$defs/XYChartAxisConfig",
			"showLabel": true,
			"labelFontSize": 14,
			"labelPadding": 5,
			"showTitle": true,
			"titleFontSize": 16,
			"titlePadding": 5,
			"showTick": true,
			"tickLength": 5,
			"tickWidth": 2,
			"showAxisLine": true,
			"axisLineWidth": 2
		},
		"chartOrientation": "vertical",
		"plotReservedSpacePercent": 50
	},
	"requirement": {
		"useMaxWidth": true,
		"rect_fill": "#f9f9f9",
		"text_color": "#333",
		"rect_border_size": "0.5px",
		"rect_border_color": "#bbb",
		"rect_min_width": 200,
		"rect_min_height": 200,
		"fontSize": 14,
		"rect_padding": 10,
		"line_height": 20
	},
	"mindmap": {
		"useMaxWidth": true,
		"padding": 10,
		"maxNodeWidth": 200,
		"layoutAlgorithm": "cose-bilkent"
	},
	"ishikawa": {
		"useMaxWidth": true,
		"diagramPadding": 20
	},
	"kanban": {
		"useMaxWidth": true,
		"padding": 8,
		"sectionWidth": 200,
		"ticketBaseUrl": ""
	},
	"timeline": {
		"useMaxWidth": true,
		"diagramMarginX": 50,
		"diagramMarginY": 10,
		"leftMargin": 150,
		"width": 150,
		"height": 50,
		"boxMargin": 10,
		"boxTextMargin": 5,
		"noteMargin": 10,
		"messageMargin": 35,
		"messageAlign": "center",
		"bottomMarginAdj": 1,
		"rightAngles": false,
		"taskFontSize": 14,
		"taskFontFamily": "\"Open Sans\", sans-serif",
		"taskMargin": 50,
		"activationWidth": 10,
		"textPlacement": "fo",
		"actorColours": [
			"#8FBC8F",
			"#7CFC00",
			"#00FFFF",
			"#20B2AA",
			"#B0E0E6",
			"#FFFFE0"
		],
		"sectionFills": [
			"#191970",
			"#8B008B",
			"#4B0082",
			"#2F4F4F",
			"#800000",
			"#8B4513",
			"#00008B"
		],
		"sectionColours": ["#fff"],
		"disableMulticolor": false
	},
	"gitGraph": {
		"useMaxWidth": true,
		"titleTopMargin": 25,
		"diagramPadding": 8,
		"nodeLabel": {
			"width": 75,
			"height": 100,
			"x": -25,
			"y": 0
		},
		"mainBranchName": "main",
		"mainBranchOrder": 0,
		"showCommitLabel": true,
		"showBranches": true,
		"rotateCommitLabel": true,
		"parallelCommits": false,
		"arrowMarkerAbsolute": false
	},
	"c4": {
		"useMaxWidth": true,
		"diagramMarginX": 50,
		"diagramMarginY": 10,
		"c4ShapeMargin": 50,
		"c4ShapePadding": 20,
		"width": 216,
		"height": 60,
		"boxMargin": 10,
		"c4ShapeInRow": 4,
		"nextLinePaddingX": 0,
		"c4BoundaryInRow": 2,
		"personFontSize": 14,
		"personFontFamily": "\"Open Sans\", sans-serif",
		"personFontWeight": "normal",
		"external_personFontSize": 14,
		"external_personFontFamily": "\"Open Sans\", sans-serif",
		"external_personFontWeight": "normal",
		"systemFontSize": 14,
		"systemFontFamily": "\"Open Sans\", sans-serif",
		"systemFontWeight": "normal",
		"external_systemFontSize": 14,
		"external_systemFontFamily": "\"Open Sans\", sans-serif",
		"external_systemFontWeight": "normal",
		"system_dbFontSize": 14,
		"system_dbFontFamily": "\"Open Sans\", sans-serif",
		"system_dbFontWeight": "normal",
		"external_system_dbFontSize": 14,
		"external_system_dbFontFamily": "\"Open Sans\", sans-serif",
		"external_system_dbFontWeight": "normal",
		"system_queueFontSize": 14,
		"system_queueFontFamily": "\"Open Sans\", sans-serif",
		"system_queueFontWeight": "normal",
		"external_system_queueFontSize": 14,
		"external_system_queueFontFamily": "\"Open Sans\", sans-serif",
		"external_system_queueFontWeight": "normal",
		"boundaryFontSize": 14,
		"boundaryFontFamily": "\"Open Sans\", sans-serif",
		"boundaryFontWeight": "normal",
		"messageFontSize": 12,
		"messageFontFamily": "\"Open Sans\", sans-serif",
		"messageFontWeight": "normal",
		"containerFontSize": 14,
		"containerFontFamily": "\"Open Sans\", sans-serif",
		"containerFontWeight": "normal",
		"external_containerFontSize": 14,
		"external_containerFontFamily": "\"Open Sans\", sans-serif",
		"external_containerFontWeight": "normal",
		"container_dbFontSize": 14,
		"container_dbFontFamily": "\"Open Sans\", sans-serif",
		"container_dbFontWeight": "normal",
		"external_container_dbFontSize": 14,
		"external_container_dbFontFamily": "\"Open Sans\", sans-serif",
		"external_container_dbFontWeight": "normal",
		"container_queueFontSize": 14,
		"container_queueFontFamily": "\"Open Sans\", sans-serif",
		"container_queueFontWeight": "normal",
		"external_container_queueFontSize": 14,
		"external_container_queueFontFamily": "\"Open Sans\", sans-serif",
		"external_container_queueFontWeight": "normal",
		"componentFontSize": 14,
		"componentFontFamily": "\"Open Sans\", sans-serif",
		"componentFontWeight": "normal",
		"external_componentFontSize": 14,
		"external_componentFontFamily": "\"Open Sans\", sans-serif",
		"external_componentFontWeight": "normal",
		"component_dbFontSize": 14,
		"component_dbFontFamily": "\"Open Sans\", sans-serif",
		"component_dbFontWeight": "normal",
		"external_component_dbFontSize": 14,
		"external_component_dbFontFamily": "\"Open Sans\", sans-serif",
		"external_component_dbFontWeight": "normal",
		"component_queueFontSize": 14,
		"component_queueFontFamily": "\"Open Sans\", sans-serif",
		"component_queueFontWeight": "normal",
		"external_component_queueFontSize": 14,
		"external_component_queueFontFamily": "\"Open Sans\", sans-serif",
		"external_component_queueFontWeight": "normal",
		"wrap": true,
		"wrapPadding": 10,
		"person_bg_color": "#08427B",
		"person_border_color": "#073B6F",
		"external_person_bg_color": "#686868",
		"external_person_border_color": "#8A8A8A",
		"system_bg_color": "#1168BD",
		"system_border_color": "#3C7FC0",
		"system_db_bg_color": "#1168BD",
		"system_db_border_color": "#3C7FC0",
		"system_queue_bg_color": "#1168BD",
		"system_queue_border_color": "#3C7FC0",
		"external_system_bg_color": "#999999",
		"external_system_border_color": "#8A8A8A",
		"external_system_db_bg_color": "#999999",
		"external_system_db_border_color": "#8A8A8A",
		"external_system_queue_bg_color": "#999999",
		"external_system_queue_border_color": "#8A8A8A",
		"container_bg_color": "#438DD5",
		"container_border_color": "#3C7FC0",
		"container_db_bg_color": "#438DD5",
		"container_db_border_color": "#3C7FC0",
		"container_queue_bg_color": "#438DD5",
		"container_queue_border_color": "#3C7FC0",
		"external_container_bg_color": "#B3B3B3",
		"external_container_border_color": "#A6A6A6",
		"external_container_db_bg_color": "#B3B3B3",
		"external_container_db_border_color": "#A6A6A6",
		"external_container_queue_bg_color": "#B3B3B3",
		"external_container_queue_border_color": "#A6A6A6",
		"component_bg_color": "#85BBF0",
		"component_border_color": "#78A8D8",
		"component_db_bg_color": "#85BBF0",
		"component_db_border_color": "#78A8D8",
		"component_queue_bg_color": "#85BBF0",
		"component_queue_border_color": "#78A8D8",
		"external_component_bg_color": "#CCCCCC",
		"external_component_border_color": "#BFBFBF",
		"external_component_db_bg_color": "#CCCCCC",
		"external_component_db_border_color": "#BFBFBF",
		"external_component_queue_bg_color": "#CCCCCC",
		"external_component_queue_border_color": "#BFBFBF"
	},
	"sankey": {
		"useMaxWidth": true,
		"width": 600,
		"height": 400,
		"linkColor": "gradient",
		"nodeAlignment": "justify",
		"showValues": true,
		"prefix": "",
		"suffix": "",
		"nodeWidth": 10,
		"nodePadding": 12,
		"labelStyle": "legacy"
	},
	"block": {
		"useMaxWidth": true,
		"padding": 8
	},
	"packet": {
		"useMaxWidth": true,
		"rowHeight": 32,
		"bitWidth": 32,
		"bitsPerRow": 32,
		"showBits": true,
		"paddingX": 5,
		"paddingY": 5
	},
	"treeView": {
		"useMaxWidth": true,
		"rowIndent": 10,
		"paddingX": 5,
		"paddingY": 5,
		"lineThickness": 1
	},
	"architecture": {
		"useMaxWidth": true,
		"padding": 40,
		"iconSize": 80,
		"fontSize": 16,
		"randomize": false,
		"nodeSeparation": 75,
		"idealEdgeLengthMultiplier": 1.5,
		"edgeElasticity": .45,
		"numIter": 2500
	},
	"eventmodeling": {
		"useMaxWidth": true,
		"padding": 30,
		"rowHeight": 32
	},
	"radar": {
		"useMaxWidth": true,
		"width": 600,
		"height": 600,
		"marginTop": 50,
		"marginRight": 50,
		"marginBottom": 50,
		"marginLeft": 50,
		"axisScaleFactor": 1,
		"axisLabelFactor": 1.05,
		"curveTension": .17
	},
	"venn": {
		"useMaxWidth": true,
		"width": 800,
		"height": 450,
		"padding": 8,
		"useDebugLayout": false
	},
	"theme": "default",
	"look": "classic",
	"handDrawnSeed": 0,
	"layout": "dagre",
	"maxTextSize": 5e4,
	"maxEdges": 500,
	"darkMode": false,
	"fontFamily": "\"trebuchet ms\", verdana, arial, sans-serif;",
	"logLevel": 5,
	"securityLevel": "strict",
	"startOnLoad": true,
	"arrowMarkerAbsolute": false,
	"secure": [
		"secure",
		"securityLevel",
		"startOnLoad",
		"maxTextSize",
		"suppressErrorRendering",
		"maxEdges"
	],
	"legacyMathML": false,
	"forceLegacyMathML": false,
	"deterministicIds": false,
	"fontSize": 16,
	"markdownAutoWrap": true,
	"suppressErrorRendering": false
};
var config = {
	...config_schema_default,
	deterministicIDSeed: void 0,
	elk: {
		mergeEdges: false,
		nodePlacementStrategy: "BRANDES_KOEPF",
		forceNodeModelOrder: false,
		considerModelOrder: "NODES_AND_EDGES"
	},
	themeCSS: void 0,
	themeVariables: themes_default.default.getThemeVariables(),
	sequence: {
		...config_schema_default.sequence,
		messageFont: /* @__PURE__ */ __name(function() {
			return {
				fontFamily: this.messageFontFamily,
				fontSize: this.messageFontSize,
				fontWeight: this.messageFontWeight
			};
		}, "messageFont"),
		noteFont: /* @__PURE__ */ __name(function() {
			return {
				fontFamily: this.noteFontFamily,
				fontSize: this.noteFontSize,
				fontWeight: this.noteFontWeight
			};
		}, "noteFont"),
		actorFont: /* @__PURE__ */ __name(function() {
			return {
				fontFamily: this.actorFontFamily,
				fontSize: this.actorFontSize,
				fontWeight: this.actorFontWeight
			};
		}, "actorFont")
	},
	class: {
		hideEmptyMembersBox: false,
		hierarchicalNamespaces: true
	},
	gantt: {
		...config_schema_default.gantt,
		tickInterval: void 0,
		useWidth: void 0
	},
	c4: {
		...config_schema_default.c4,
		useWidth: void 0,
		personFont: /* @__PURE__ */ __name(function() {
			return {
				fontFamily: this.personFontFamily,
				fontSize: this.personFontSize,
				fontWeight: this.personFontWeight
			};
		}, "personFont"),
		flowchart: {
			...config_schema_default.flowchart,
			inheritDir: false
		},
		external_personFont: /* @__PURE__ */ __name(function() {
			return {
				fontFamily: this.external_personFontFamily,
				fontSize: this.external_personFontSize,
				fontWeight: this.external_personFontWeight
			};
		}, "external_personFont"),
		systemFont: /* @__PURE__ */ __name(function() {
			return {
				fontFamily: this.systemFontFamily,
				fontSize: this.systemFontSize,
				fontWeight: this.systemFontWeight
			};
		}, "systemFont"),
		external_systemFont: /* @__PURE__ */ __name(function() {
			return {
				fontFamily: this.external_systemFontFamily,
				fontSize: this.external_systemFontSize,
				fontWeight: this.external_systemFontWeight
			};
		}, "external_systemFont"),
		system_dbFont: /* @__PURE__ */ __name(function() {
			return {
				fontFamily: this.system_dbFontFamily,
				fontSize: this.system_dbFontSize,
				fontWeight: this.system_dbFontWeight
			};
		}, "system_dbFont"),
		external_system_dbFont: /* @__PURE__ */ __name(function() {
			return {
				fontFamily: this.external_system_dbFontFamily,
				fontSize: this.external_system_dbFontSize,
				fontWeight: this.external_system_dbFontWeight
			};
		}, "external_system_dbFont"),
		system_queueFont: /* @__PURE__ */ __name(function() {
			return {
				fontFamily: this.system_queueFontFamily,
				fontSize: this.system_queueFontSize,
				fontWeight: this.system_queueFontWeight
			};
		}, "system_queueFont"),
		external_system_queueFont: /* @__PURE__ */ __name(function() {
			return {
				fontFamily: this.external_system_queueFontFamily,
				fontSize: this.external_system_queueFontSize,
				fontWeight: this.external_system_queueFontWeight
			};
		}, "external_system_queueFont"),
		containerFont: /* @__PURE__ */ __name(function() {
			return {
				fontFamily: this.containerFontFamily,
				fontSize: this.containerFontSize,
				fontWeight: this.containerFontWeight
			};
		}, "containerFont"),
		external_containerFont: /* @__PURE__ */ __name(function() {
			return {
				fontFamily: this.external_containerFontFamily,
				fontSize: this.external_containerFontSize,
				fontWeight: this.external_containerFontWeight
			};
		}, "external_containerFont"),
		container_dbFont: /* @__PURE__ */ __name(function() {
			return {
				fontFamily: this.container_dbFontFamily,
				fontSize: this.container_dbFontSize,
				fontWeight: this.container_dbFontWeight
			};
		}, "container_dbFont"),
		external_container_dbFont: /* @__PURE__ */ __name(function() {
			return {
				fontFamily: this.external_container_dbFontFamily,
				fontSize: this.external_container_dbFontSize,
				fontWeight: this.external_container_dbFontWeight
			};
		}, "external_container_dbFont"),
		container_queueFont: /* @__PURE__ */ __name(function() {
			return {
				fontFamily: this.container_queueFontFamily,
				fontSize: this.container_queueFontSize,
				fontWeight: this.container_queueFontWeight
			};
		}, "container_queueFont"),
		external_container_queueFont: /* @__PURE__ */ __name(function() {
			return {
				fontFamily: this.external_container_queueFontFamily,
				fontSize: this.external_container_queueFontSize,
				fontWeight: this.external_container_queueFontWeight
			};
		}, "external_container_queueFont"),
		componentFont: /* @__PURE__ */ __name(function() {
			return {
				fontFamily: this.componentFontFamily,
				fontSize: this.componentFontSize,
				fontWeight: this.componentFontWeight
			};
		}, "componentFont"),
		external_componentFont: /* @__PURE__ */ __name(function() {
			return {
				fontFamily: this.external_componentFontFamily,
				fontSize: this.external_componentFontSize,
				fontWeight: this.external_componentFontWeight
			};
		}, "external_componentFont"),
		component_dbFont: /* @__PURE__ */ __name(function() {
			return {
				fontFamily: this.component_dbFontFamily,
				fontSize: this.component_dbFontSize,
				fontWeight: this.component_dbFontWeight
			};
		}, "component_dbFont"),
		external_component_dbFont: /* @__PURE__ */ __name(function() {
			return {
				fontFamily: this.external_component_dbFontFamily,
				fontSize: this.external_component_dbFontSize,
				fontWeight: this.external_component_dbFontWeight
			};
		}, "external_component_dbFont"),
		component_queueFont: /* @__PURE__ */ __name(function() {
			return {
				fontFamily: this.component_queueFontFamily,
				fontSize: this.component_queueFontSize,
				fontWeight: this.component_queueFontWeight
			};
		}, "component_queueFont"),
		external_component_queueFont: /* @__PURE__ */ __name(function() {
			return {
				fontFamily: this.external_component_queueFontFamily,
				fontSize: this.external_component_queueFontSize,
				fontWeight: this.external_component_queueFontWeight
			};
		}, "external_component_queueFont"),
		boundaryFont: /* @__PURE__ */ __name(function() {
			return {
				fontFamily: this.boundaryFontFamily,
				fontSize: this.boundaryFontSize,
				fontWeight: this.boundaryFontWeight
			};
		}, "boundaryFont"),
		messageFont: /* @__PURE__ */ __name(function() {
			return {
				fontFamily: this.messageFontFamily,
				fontSize: this.messageFontSize,
				fontWeight: this.messageFontWeight
			};
		}, "messageFont")
	},
	pie: {
		...config_schema_default.pie,
		useWidth: 984
	},
	xyChart: {
		...config_schema_default.xyChart,
		useWidth: void 0
	},
	requirement: {
		...config_schema_default.requirement,
		useWidth: void 0
	},
	packet: { ...config_schema_default.packet },
	eventmodeling: { ...config_schema_default.eventmodeling },
	treeView: {
		...config_schema_default.treeView,
		useWidth: void 0
	},
	radar: { ...config_schema_default.radar },
	ishikawa: { ...config_schema_default.ishikawa },
	sankey: {
		...config_schema_default.sankey,
		nodeColors: void 0
	},
	treemap: {
		useMaxWidth: true,
		padding: 10,
		diagramPadding: 8,
		showValues: true,
		nodeWidth: 100,
		nodeHeight: 40,
		borderWidth: 1,
		valueFontSize: 12,
		labelFontSize: 14,
		valueFormat: ","
	},
	venn: { ...config_schema_default.venn }
};
var keyify = /* @__PURE__ */ __name((obj, prefix = "") => Object.keys(obj).reduce((res, el) => {
	if (Array.isArray(obj[el])) return res;
	else if (typeof obj[el] === "object" && obj[el] !== null) return [
		...res,
		prefix + el,
		...keyify(obj[el], "")
	];
	return [...res, prefix + el];
}, []), "keyify");
var configKeys = new Set(keyify(config, ""));
var defaultConfig_default = config;
var sanitizeDirective = /* @__PURE__ */ __name((args) => {
	log.debug("sanitizeDirective called with", args);
	if (typeof args !== "object" || args == null) return;
	if (Array.isArray(args)) {
		args.forEach((arg) => sanitizeDirective(arg));
		return;
	}
	for (const key of Object.keys(args)) {
		log.debug("Checking key", key);
		if (key.startsWith("__") || key.includes("proto") || key.includes("constr") || !configKeys.has(key) || args[key] == null) {
			log.debug("sanitize deleting key: ", key);
			delete args[key];
			continue;
		}
		if (typeof args[key] === "object") {
			if (key === "nodeColors") {
				const colorPattern = /^#[\da-f]{3,8}$|^rgb\([\d\s%,.]+\)$|^hsl\([\d\s%,.]+\)$|^[a-z]+$/i;
				for (const colorKey of Object.keys(args[key])) if (typeof args[key][colorKey] !== "string" || !colorPattern.test(args[key][colorKey])) {
					log.debug("sanitize deleting invalid color:", colorKey, args[key][colorKey]);
					delete args[key][colorKey];
				}
			} else {
				log.debug("sanitizing object", key);
				sanitizeDirective(args[key]);
			}
			continue;
		}
		for (const cssKey of [
			"themeCSS",
			"fontFamily",
			"altFontFamily"
		]) if (key.includes(cssKey)) {
			log.debug("sanitizing css option", key);
			args[key] = sanitizeCss(args[key]);
		}
	}
	if (args.themeVariables) for (const k of Object.keys(args.themeVariables)) {
		const val = args.themeVariables[k];
		if (val?.match && !val.match(/^[\d "#%(),.;A-Za-z]+$/)) args.themeVariables[k] = "";
	}
	log.debug("After sanitization", args);
}, "sanitizeDirective");
var sanitizeCss = /* @__PURE__ */ __name((str) => {
	let startCnt = 0;
	let endCnt = 0;
	for (const element of str) {
		if (startCnt < endCnt) return "{ /* ERROR: Unbalanced CSS */ }";
		if (element === "{") startCnt++;
		else if (element === "}") endCnt++;
	}
	if (startCnt !== endCnt) return "{ /* ERROR: Unbalanced CSS */ }";
	return str;
}, "sanitizeCss");
var defaultConfig = Object.freeze(defaultConfig_default);
var evaluate = /* @__PURE__ */ __name((val) => val === false || [
	"false",
	"null",
	"0"
].includes(String(val).trim().toLowerCase()) ? false : true, "evaluate");
var siteConfig = assignWithDepth_default({}, defaultConfig);
var configFromInitialize;
var directives = [];
var currentConfig = assignWithDepth_default({}, defaultConfig);
var updateCurrentConfig = /* @__PURE__ */ __name((siteCfg, _directives) => {
	let cfg = assignWithDepth_default({}, siteCfg);
	let sumOfDirectives = {};
	for (const d of _directives) {
		sanitize(d);
		sumOfDirectives = assignWithDepth_default(sumOfDirectives, d);
	}
	cfg = assignWithDepth_default(cfg, sumOfDirectives);
	if (sumOfDirectives.theme && sumOfDirectives.theme in themes_default) {
		const themeVariables = assignWithDepth_default(assignWithDepth_default({}, configFromInitialize).themeVariables || {}, sumOfDirectives.themeVariables);
		if (cfg.theme && cfg.theme in themes_default) cfg.themeVariables = themes_default[cfg.theme].getThemeVariables(themeVariables);
	}
	currentConfig = cfg;
	checkConfig(currentConfig);
	return currentConfig;
}, "updateCurrentConfig");
var setSiteConfig = /* @__PURE__ */ __name((conf) => {
	siteConfig = assignWithDepth_default({}, defaultConfig);
	siteConfig = assignWithDepth_default(siteConfig, conf);
	if (conf.theme && themes_default[conf.theme]) siteConfig.themeVariables = themes_default[conf.theme].getThemeVariables(conf.themeVariables);
	updateCurrentConfig(siteConfig, directives);
	return siteConfig;
}, "setSiteConfig");
var saveConfigFromInitialize = /* @__PURE__ */ __name((conf) => {
	configFromInitialize = assignWithDepth_default({}, conf);
}, "saveConfigFromInitialize");
var updateSiteConfig = /* @__PURE__ */ __name((conf) => {
	siteConfig = assignWithDepth_default(siteConfig, conf);
	updateCurrentConfig(siteConfig, directives);
	return siteConfig;
}, "updateSiteConfig");
var getSiteConfig = /* @__PURE__ */ __name(() => {
	return assignWithDepth_default({}, siteConfig);
}, "getSiteConfig");
var setConfig = /* @__PURE__ */ __name((conf) => {
	checkConfig(conf);
	assignWithDepth_default(currentConfig, conf);
	return getConfig();
}, "setConfig");
var getConfig = /* @__PURE__ */ __name(() => {
	return assignWithDepth_default({}, currentConfig);
}, "getConfig");
var sanitize = /* @__PURE__ */ __name((options) => {
	if (!options) return;
	["secure", ...siteConfig.secure ?? []].forEach((key) => {
		if (Object.hasOwn(options, key)) {
			log.debug(`Denied attempt to modify a secure key ${key}`, options[key]);
			delete options[key];
		}
	});
	Object.keys(options).forEach((key) => {
		if (key.startsWith("__")) delete options[key];
	});
	Object.keys(options).forEach((key) => {
		if (typeof options[key] === "string" && (options[key].includes("<") || options[key].includes(">") || options[key].includes("url(data:"))) delete options[key];
		if (typeof options[key] === "object") sanitize(options[key]);
	});
}, "sanitize");
var addDirective = /* @__PURE__ */ __name((directive) => {
	sanitizeDirective(directive);
	if (directive.fontFamily && !directive.themeVariables?.fontFamily) directive.themeVariables = {
		...directive.themeVariables,
		fontFamily: directive.fontFamily
	};
	directives.push(directive);
	updateCurrentConfig(siteConfig, directives);
}, "addDirective");
var reset = /* @__PURE__ */ __name((config2 = siteConfig) => {
	directives = [];
	updateCurrentConfig(config2, directives);
}, "reset");
var ConfigWarning = {
	LAZY_LOAD_DEPRECATED: "The configuration options lazyLoadedDiagrams and loadExternalDiagramsAtStartup are deprecated. Please use registerExternalDiagrams instead.",
	FLOWCHART_HTML_LABELS_DEPRECATED: "flowchart.htmlLabels is deprecated. Please use global htmlLabels instead."
};
var issuedWarnings = {};
var issueWarning = /* @__PURE__ */ __name((warning) => {
	if (issuedWarnings[warning]) return;
	log.warn(ConfigWarning[warning]);
	issuedWarnings[warning] = true;
}, "issueWarning");
var checkConfig = /* @__PURE__ */ __name((config2) => {
	if (!config2) return;
	if (config2.lazyLoadedDiagrams || config2.loadExternalDiagramsAtStartup) issueWarning("LAZY_LOAD_DEPRECATED");
}, "checkConfig");
var getUserDefinedConfig = /* @__PURE__ */ __name(() => {
	let userConfig = {};
	if (configFromInitialize) userConfig = assignWithDepth_default(userConfig, configFromInitialize);
	for (const d of directives) userConfig = assignWithDepth_default(userConfig, d);
	return userConfig;
}, "getUserDefinedConfig");
var getEffectiveHtmlLabels = /* @__PURE__ */ __name((config2) => {
	if (config2.flowchart?.htmlLabels != void 0) issueWarning("FLOWCHART_HTML_LABELS_DEPRECATED");
	return evaluate(config2.htmlLabels ?? config2.flowchart?.htmlLabels ?? true);
}, "getEffectiveHtmlLabels");
var lineBreakRegex = /<br\s*\/?>/gi;
var getRows = /* @__PURE__ */ __name((s) => {
	if (!s) return [""];
	return breakToPlaceholder(s).replace(/\\n/g, "#br#").split("#br#");
}, "getRows");
var setupDompurifyHooksIfNotSetup = /* @__PURE__ */ (() => {
	let setup = false;
	return () => {
		if (!setup) {
			setupDompurifyHooks();
			setup = true;
		}
	};
})();
function setupDompurifyHooks() {
	const TEMPORARY_ATTRIBUTE = "data-temp-href-target";
	purify.addHook("beforeSanitizeAttributes", (node) => {
		if (node.tagName === "A" && node.hasAttribute("target")) node.setAttribute(TEMPORARY_ATTRIBUTE, node.getAttribute("target") ?? "");
	});
	purify.addHook("afterSanitizeAttributes", (node) => {
		if (node.tagName === "A" && node.hasAttribute(TEMPORARY_ATTRIBUTE)) {
			node.setAttribute("target", node.getAttribute(TEMPORARY_ATTRIBUTE) ?? "");
			node.removeAttribute(TEMPORARY_ATTRIBUTE);
			if (node.getAttribute("target") === "_blank") node.setAttribute("rel", "noopener");
		}
	});
}
__name(setupDompurifyHooks, "setupDompurifyHooks");
var removeScript = /* @__PURE__ */ __name((txt) => {
	setupDompurifyHooksIfNotSetup();
	return purify.sanitize(txt);
}, "removeScript");
var sanitizeMore = /* @__PURE__ */ __name((text, config2) => {
	if (getEffectiveHtmlLabels(config2)) {
		const level = config2.securityLevel;
		if (level === "antiscript" || level === "strict" || level === "sandbox") text = removeScript(text);
		else if (level !== "loose") {
			text = breakToPlaceholder(text);
			text = text.replace(/</g, "&lt;").replace(/>/g, "&gt;");
			text = text.replace(/=/g, "&equals;");
			text = placeholderToBreak(text);
		}
	}
	return text;
}, "sanitizeMore");
var sanitizeText = /* @__PURE__ */ __name((text, config2) => {
	if (!text) return text;
	if (config2.dompurifyConfig) text = purify.sanitize(sanitizeMore(text, config2), config2.dompurifyConfig).toString();
	else text = purify.sanitize(sanitizeMore(text, config2), { FORBID_TAGS: ["style"] }).toString();
	return text;
}, "sanitizeText");
var sanitizeTextOrArray = /* @__PURE__ */ __name((a, config2) => {
	if (typeof a === "string") return sanitizeText(a, config2);
	return a.flat().map((x) => sanitizeText(x, config2));
}, "sanitizeTextOrArray");
var hasBreaks = /* @__PURE__ */ __name((text) => {
	return lineBreakRegex.test(text);
}, "hasBreaks");
var splitBreaks = /* @__PURE__ */ __name((text) => {
	return text.split(lineBreakRegex);
}, "splitBreaks");
var placeholderToBreak = /* @__PURE__ */ __name((s) => {
	return s.replace(/#br#/g, "<br/>");
}, "placeholderToBreak");
var breakToPlaceholder = /* @__PURE__ */ __name((s) => {
	return s.replace(lineBreakRegex, "#br#");
}, "breakToPlaceholder");
var getUrl = /* @__PURE__ */ __name((useAbsolute) => {
	let url = "";
	if (useAbsolute) {
		url = window.location.protocol + "//" + window.location.host + window.location.pathname + window.location.search;
		url = CSS.escape(url);
	}
	return url;
}, "getUrl");
var getMax = /* @__PURE__ */ __name(function(...values) {
	const newValues = values.filter((value) => {
		return !isNaN(value);
	});
	return Math.max(...newValues);
}, "getMax");
var getMin = /* @__PURE__ */ __name(function(...values) {
	const newValues = values.filter((value) => {
		return !isNaN(value);
	});
	return Math.min(...newValues);
}, "getMin");
var parseGenericTypes = /* @__PURE__ */ __name(function(input) {
	const inputSets = input.split(/(,)/);
	const output = [];
	for (let i = 0; i < inputSets.length; i++) {
		let thisSet = inputSets[i];
		if (thisSet === "," && i > 0 && i + 1 < inputSets.length) {
			const previousSet = inputSets[i - 1];
			const nextSet = inputSets[i + 1];
			if (shouldCombineSets(previousSet, nextSet)) {
				thisSet = previousSet + "," + nextSet;
				i++;
				output.pop();
			}
		}
		output.push(processSet(thisSet));
	}
	return output.join("");
}, "parseGenericTypes");
var countOccurrence = /* @__PURE__ */ __name((string, substring) => {
	return Math.max(0, string.split(substring).length - 1);
}, "countOccurrence");
var shouldCombineSets = /* @__PURE__ */ __name((previousSet, nextSet) => {
	const prevCount = countOccurrence(previousSet, "~");
	const nextCount = countOccurrence(nextSet, "~");
	return prevCount === 1 && nextCount === 1;
}, "shouldCombineSets");
var processSet = /* @__PURE__ */ __name((input) => {
	const tildeCount = countOccurrence(input, "~");
	let hasStartingTilde = false;
	if (tildeCount <= 1) return input;
	if (tildeCount % 2 !== 0 && input.startsWith("~")) {
		input = input.substring(1);
		hasStartingTilde = true;
	}
	const chars = [...input];
	let first = chars.indexOf("~");
	let last = chars.lastIndexOf("~");
	while (first !== -1 && last !== -1 && first !== last) {
		chars[first] = "<";
		chars[last] = ">";
		first = chars.indexOf("~");
		last = chars.lastIndexOf("~");
	}
	if (hasStartingTilde) chars.unshift("~");
	return chars.join("");
}, "processSet");
var isMathMLSupported = /* @__PURE__ */ __name(() => window.MathMLElement !== void 0, "isMathMLSupported");
var katexRegex = /\$\$(.*)\$\$/g;
var hasKatex = /* @__PURE__ */ __name((text) => (text.match(katexRegex)?.length ?? 0) > 0, "hasKatex");
var calculateMathMLDimensions = /* @__PURE__ */ __name(async (text, config2) => {
	const divElem = document.createElement("div");
	divElem.innerHTML = await renderKatexSanitized(text, config2);
	divElem.id = "katex-temp";
	divElem.style.visibility = "hidden";
	divElem.style.position = "absolute";
	divElem.style.top = "0";
	document.querySelector("body")?.insertAdjacentElement("beforeend", divElem);
	const dim = {
		width: divElem.clientWidth,
		height: divElem.clientHeight
	};
	divElem.remove();
	return dim;
}, "calculateMathMLDimensions");
var renderKatexUnsanitized = /* @__PURE__ */ __name(async (text, config2) => {
	if (!hasKatex(text)) return text;
	if (!(isMathMLSupported() || config2.legacyMathML || config2.forceLegacyMathML)) return text.replace(katexRegex, "MathML is unsupported in this environment.");
	{
		const { default: katex } = await import("./katex-VyT6cXPH.js");
		const outputMode = config2.forceLegacyMathML || !isMathMLSupported() && config2.legacyMathML ? "htmlAndMathml" : "mathml";
		return text.split(lineBreakRegex).map((line) => hasKatex(line) ? `<div style="display: flex; align-items: center; justify-content: center; white-space: nowrap;">${line}</div>` : `<div>${line}</div>`).join("").replace(katexRegex, (_, c) => katex.renderToString(c, {
			throwOnError: true,
			displayMode: true,
			output: outputMode
		}).replace(/\n/g, " ").replace(/<annotation.*<\/annotation>/g, ""));
	}
	return text.replace(katexRegex, "Katex is not supported in @mermaid-js/tiny. Please use the full mermaid library.");
}, "renderKatexUnsanitized");
var renderKatexSanitized = /* @__PURE__ */ __name(async (text, config2) => {
	return sanitizeText(await renderKatexUnsanitized(text, config2), config2);
}, "renderKatexSanitized");
var common_default = {
	getRows,
	sanitizeText,
	sanitizeTextOrArray,
	hasBreaks,
	splitBreaks,
	lineBreakRegex,
	removeScript,
	getUrl,
	evaluate,
	getMax,
	getMin
};
var d3Attrs = /* @__PURE__ */ __name(function(d3Elem, attrs) {
	for (let attr of attrs) d3Elem.attr(attr[0], attr[1]);
}, "d3Attrs");
var calculateSvgSizeAttrs = /* @__PURE__ */ __name(function(height, width, useMaxWidth) {
	let attrs = /* @__PURE__ */ new Map();
	if (useMaxWidth) {
		attrs.set("width", "100%");
		attrs.set("style", `max-width: ${width}px;`);
	} else {
		attrs.set("height", height);
		attrs.set("width", width);
	}
	return attrs;
}, "calculateSvgSizeAttrs");
var configureSvgSize = /* @__PURE__ */ __name(function(svgElem, height, width, useMaxWidth) {
	d3Attrs(svgElem, calculateSvgSizeAttrs(height, width, useMaxWidth));
}, "configureSvgSize");
var setupGraphViewbox = /* @__PURE__ */ __name(function(graph, svgElem, padding, useMaxWidth) {
	const svgBounds = svgElem.node().getBBox();
	const sWidth = svgBounds.width;
	const sHeight = svgBounds.height;
	log.info(`SVG bounds: ${sWidth}x${sHeight}`, svgBounds);
	let width = 0;
	let height = 0;
	log.info(`Graph bounds: ${width}x${height}`, graph);
	width = sWidth + padding * 2;
	height = sHeight + padding * 2;
	log.info(`Calculated bounds: ${width}x${height}`);
	configureSvgSize(svgElem, height, width, useMaxWidth);
	const vBox = `${svgBounds.x - padding} ${svgBounds.y - padding} ${svgBounds.width + 2 * padding} ${svgBounds.height + 2 * padding}`;
	svgElem.attr("viewBox", vBox);
}, "setupGraphViewbox");
var themes = {};
function cssStyleSheetToString(cssStyleSheet) {
	return [...cssStyleSheet.cssRules].map((rule) => rule.cssText).join("\n");
}
__name(cssStyleSheetToString, "cssStyleSheetToString");
var getStyles = /* @__PURE__ */ __name((type, userStyles, options, svgId) => {
	let diagramStyles = "";
	if (type in themes && themes[type]) diagramStyles = themes[type]({
		...options,
		svgId
	});
	else log.warn(`No theme found for ${type}`);
	return ` & {
    font-family: ${options.fontFamily};
    font-size: ${options.fontSize};
    fill: ${options.textColor}
  }
  @keyframes edge-animation-frame {
    from {
      stroke-dashoffset: 0;
    }
  }
  @keyframes dash {
    to {
      stroke-dashoffset: 0;
    }
  }
  & .edge-animation-slow {
    stroke-dasharray: 9,5 !important;
    stroke-dashoffset: 900;
    animation: dash 50s linear infinite;
    stroke-linecap: round;
  }
  & .edge-animation-fast {
    stroke-dasharray: 9,5 !important;
    stroke-dashoffset: 900;
    animation: dash 20s linear infinite;
    stroke-linecap: round;
  }
  /* Classes common for multiple diagrams */

  & .error-icon {
    fill: ${options.errorBkgColor};
  }
  & .error-text {
    fill: ${options.errorTextColor};
    stroke: ${options.errorTextColor};
  }

  & .edge-thickness-normal {
    stroke-width: ${options.strokeWidth ?? 1}px;
  }
  & .edge-thickness-thick {
    stroke-width: 3.5px
  }
  & .edge-pattern-solid {
    stroke-dasharray: 0;
  }
  & .edge-thickness-invisible {
    stroke-width: 0;
    fill: none;
  }
  & .edge-pattern-dashed{
    stroke-dasharray: 3;
  }
  .edge-pattern-dotted {
    stroke-dasharray: 2;
  }

  & .marker {
    fill: ${options.lineColor};
    stroke: ${options.lineColor};
  }
  & .marker.cross {
    stroke: ${options.lineColor};
  }

  & svg {
    font-family: ${options.fontFamily};
    font-size: ${options.fontSize};
  }
   & p {
    margin: 0
   }

  ${diagramStyles}
  .node .neo-node {
    stroke: ${options.nodeBorder};
  }

  [data-look="neo"].node rect, [data-look="neo"].cluster rect, [data-look="neo"].node polygon {
    stroke: ${options.useGradient ? "url(" + svgId + "-gradient)" : options.nodeBorder};
    filter: ${options.dropShadow ? options.dropShadow.replace("url(#drop-shadow)", `url(${svgId}-drop-shadow)`) : "none"};
  }


  [data-look="neo"].node path {
    stroke: ${options.useGradient ? "url(" + svgId + "-gradient)" : options.nodeBorder};
    stroke-width: ${options.strokeWidth ?? 1}px;
  }

  [data-look="neo"].node .outer-path {
    filter: ${options.dropShadow ? options.dropShadow.replace("url(#drop-shadow)", `url(${svgId}-drop-shadow)`) : "none"};
  }

  [data-look="neo"].node .neo-line path {
    stroke: ${options.nodeBorder};
    filter: none;
  }

  [data-look="neo"].node circle{
    stroke: ${options.useGradient ? "url(" + svgId + "-gradient)" : options.nodeBorder};
    filter: ${options.dropShadow ? options.dropShadow.replace("url(#drop-shadow)", `url(${svgId}-drop-shadow)`) : "none"};
  }

  [data-look="neo"].node circle .state-start{
    fill: #000000;
  }

  [data-look="neo"].icon-shape .icon {
    fill: ${options.useGradient ? "url(" + svgId + "-gradient)" : options.nodeBorder};
    filter: ${options.dropShadow ? options.dropShadow.replace("url(#drop-shadow)", `url(${svgId}-drop-shadow)`) : "none"};
  }

    [data-look="neo"].icon-shape .icon-neo path {
    stroke: ${options.useGradient ? "url(" + svgId + "-gradient)" : options.nodeBorder};
    filter: ${options.dropShadow ? options.dropShadow.replace("url(#drop-shadow)", `url(${svgId}-drop-shadow)`) : "none"};
  }

  ${userStyles}
`;
}, "getStyles");
var addStylesForDiagram = /* @__PURE__ */ __name((type, diagramTheme) => {
	if (diagramTheme !== void 0) themes[type] = diagramTheme;
}, "addStylesForDiagram");
var styles_default = getStyles;
var commonDb_exports = {};
__export(commonDb_exports, {
	clear: () => clear,
	getAccDescription: () => getAccDescription,
	getAccTitle: () => getAccTitle,
	getDiagramTitle: () => getDiagramTitle,
	setAccDescription: () => setAccDescription,
	setAccTitle: () => setAccTitle,
	setDiagramTitle: () => setDiagramTitle
});
var accTitle = "";
var diagramTitle = "";
var accDescription = "";
var sanitizeText2 = /* @__PURE__ */ __name((txt) => sanitizeText(txt, getConfig()), "sanitizeText");
var clear = /* @__PURE__ */ __name(() => {
	accTitle = "";
	accDescription = "";
	diagramTitle = "";
}, "clear");
var setAccTitle = /* @__PURE__ */ __name((txt) => {
	accTitle = sanitizeText2(txt).replace(/^\s+/g, "");
}, "setAccTitle");
var getAccTitle = /* @__PURE__ */ __name(() => accTitle, "getAccTitle");
var setAccDescription = /* @__PURE__ */ __name((txt) => {
	accDescription = sanitizeText2(txt).replace(/\n\s+/g, "\n");
}, "setAccDescription");
var getAccDescription = /* @__PURE__ */ __name(() => accDescription, "getAccDescription");
var setDiagramTitle = /* @__PURE__ */ __name((txt) => {
	diagramTitle = sanitizeText2(txt);
}, "setDiagramTitle");
var getDiagramTitle = /* @__PURE__ */ __name(() => diagramTitle, "getDiagramTitle");
var log2 = log;
var setLogLevel2 = setLogLevel;
var getConfig2 = getConfig;
var setConfig2 = setConfig;
var defaultConfig2 = defaultConfig;
var sanitizeText3 = /* @__PURE__ */ __name((text) => sanitizeText(text, getConfig2()), "sanitizeText");
var setupGraphViewbox2 = setupGraphViewbox;
var getCommonDb = /* @__PURE__ */ __name(() => {
	return commonDb_exports;
}, "getCommonDb");
var diagrams = {};
var registerDiagram = /* @__PURE__ */ __name((id, diagram, detector) => {
	if (diagrams[id]) log2.warn(`Diagram with id ${id} already registered. Overwriting.`);
	diagrams[id] = diagram;
	if (detector) addDetector(id, detector);
	addStylesForDiagram(id, diagram.styles);
	diagram.injectUtils?.(log2, setLogLevel2, getConfig2, sanitizeText3, setupGraphViewbox2, getCommonDb(), () => {});
}, "registerDiagram");
var getDiagram = /* @__PURE__ */ __name((name) => {
	if (name in diagrams) return diagrams[name];
	throw new DiagramNotFoundError(name);
}, "getDiagram");
var DiagramNotFoundError = class extends Error {
	static {
		__name(this, "DiagramNotFoundError");
	}
	constructor(name) {
		super(`Diagram ${name} not found.`);
	}
};
//#endregion
export { darken as $, hasKatex as A, sanitizeText3 as B, getDiagramLoader as C, getThemeVariables3 as D, getSiteConfig as E, renderKatexSanitized as F, setConfig2 as G, setAccDescription as H, reset as I, setupGraphViewbox as J, setDiagramTitle as K, sanitizeCss as L, parseGenericTypes as M, registerDiagram as N, getUrl as O, registerLazyLoadedDiagrams as P, updateSiteConfig as Q, sanitizeDirective as R, getDiagram as S, getEffectiveHtmlLabels as T, setAccTitle as U, saveConfigFromInitialize as V, setConfig as W, styles_default as X, setupGraphViewbox2 as Y, themes_default as Z, frontMatterRegex as _, clear as a, Utils as at, getConfig as b, configureSvgSize as c, defaultConfig2 as d, lighten as et, defaultConfig_default as f, evaluate as g, directiveRegex as h, calculateMathMLDimensions as i, Color as it, lineBreakRegex as j, getUserDefinedConfig as k, cssStyleSheetToString as l, detectors as m, addDirective as n, isDark as nt, commonDb_exports as o, detectType as p, setSiteConfig as q, assignWithDepth_default as r, rgba as rt, common_default as s, UnknownDiagramError as t, adjustChannel as tt, defaultConfig as u, getAccDescription as v, getDiagramTitle as w, getConfig2 as x, getAccTitle as y, sanitizeText as z };

//# sourceMappingURL=chunk-CSCIHK7Q-CtOBMFgQ.js.map