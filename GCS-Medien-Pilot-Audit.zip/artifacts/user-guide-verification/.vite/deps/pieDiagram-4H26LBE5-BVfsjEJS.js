import { H as __name, U as log } from "./src-BFTritsu.js";
import { H as setAccDescription, K as setDiagramTitle, U as setAccTitle, a as clear, c as configureSvgSize, f as defaultConfig_default, v as getAccDescription, w as getDiagramTitle, x as getConfig2, y as getAccTitle } from "./chunk-CSCIHK7Q-CtOBMFgQ.js";
import { t as ordinal } from "./ordinal-CwuWvYe0.js";
import { n as constant_default } from "./path-B2YYvyHp.js";
import { m as tau } from "./dist-BV2hxVcr.js";
import { t as arc_default } from "./arc-ySl5hicX.js";
import { t as array_default } from "./array-75Ih5Qg4.js";
import { i as cleanAndMerge, p as parseFontSize } from "./chunk-5ZQYHXKU-UjcI8I9R.js";
import { t as selectSvgElement } from "./chunk-WU5MYG2G-DqE-W9mY.js";
import { t as parse } from "./mermaid-parser.core-COAgKAZM.js";
import { t as populateCommonDb } from "./chunk-4BX2VUAB-ByYM0Sap.js";
//#region node_modules/d3-shape/src/descending.js
function descending_default(a, b) {
	return b < a ? -1 : b > a ? 1 : b >= a ? 0 : NaN;
}
//#endregion
//#region node_modules/d3-shape/src/identity.js
function identity_default(d) {
	return d;
}
//#endregion
//#region node_modules/d3-shape/src/pie.js
function pie_default() {
	var value = identity_default, sortValues = descending_default, sort = null, startAngle = constant_default(0), endAngle = constant_default(tau), padAngle = constant_default(0);
	function pie(data) {
		var i, n = (data = array_default(data)).length, j, k, sum = 0, index = new Array(n), arcs = new Array(n), a0 = +startAngle.apply(this, arguments), da = Math.min(tau, Math.max(-tau, endAngle.apply(this, arguments) - a0)), a1, p = Math.min(Math.abs(da) / n, padAngle.apply(this, arguments)), pa = p * (da < 0 ? -1 : 1), v;
		for (i = 0; i < n; ++i) if ((v = arcs[index[i] = i] = +value(data[i], i, data)) > 0) sum += v;
		if (sortValues != null) index.sort(function(i, j) {
			return sortValues(arcs[i], arcs[j]);
		});
		else if (sort != null) index.sort(function(i, j) {
			return sort(data[i], data[j]);
		});
		for (i = 0, k = sum ? (da - n * pa) / sum : 0; i < n; ++i, a0 = a1) j = index[i], v = arcs[j], a1 = a0 + (v > 0 ? v * k : 0) + pa, arcs[j] = {
			data: data[j],
			index: i,
			value: v,
			startAngle: a0,
			endAngle: a1,
			padAngle: p
		};
		return arcs;
	}
	pie.value = function(_) {
		return arguments.length ? (value = typeof _ === "function" ? _ : constant_default(+_), pie) : value;
	};
	pie.sortValues = function(_) {
		return arguments.length ? (sortValues = _, sort = null, pie) : sortValues;
	};
	pie.sort = function(_) {
		return arguments.length ? (sort = _, sortValues = null, pie) : sort;
	};
	pie.startAngle = function(_) {
		return arguments.length ? (startAngle = typeof _ === "function" ? _ : constant_default(+_), pie) : startAngle;
	};
	pie.endAngle = function(_) {
		return arguments.length ? (endAngle = typeof _ === "function" ? _ : constant_default(+_), pie) : endAngle;
	};
	pie.padAngle = function(_) {
		return arguments.length ? (padAngle = typeof _ === "function" ? _ : constant_default(+_), pie) : padAngle;
	};
	return pie;
}
//#endregion
//#region node_modules/mermaid/dist/chunks/mermaid.core/pieDiagram-4H26LBE5.mjs
var DEFAULT_PIE_CONFIG = defaultConfig_default.pie;
var DEFAULT_PIE_DB = {
	sections: /* @__PURE__ */ new Map(),
	showData: false,
	config: DEFAULT_PIE_CONFIG
};
var sections = DEFAULT_PIE_DB.sections;
var showData = DEFAULT_PIE_DB.showData;
var config = structuredClone(DEFAULT_PIE_CONFIG);
var db = {
	getConfig: /* @__PURE__ */ __name(() => structuredClone(config), "getConfig"),
	clear: /* @__PURE__ */ __name(() => {
		sections = /* @__PURE__ */ new Map();
		showData = DEFAULT_PIE_DB.showData;
		clear();
	}, "clear"),
	setDiagramTitle,
	getDiagramTitle,
	setAccTitle,
	getAccTitle,
	setAccDescription,
	getAccDescription,
	addSection: /* @__PURE__ */ __name(({ label, value }) => {
		if (value < 0) throw new Error(`"${label}" has invalid value: ${value}. Negative values are not allowed in pie charts. All slice values must be >= 0.`);
		if (!sections.has(label)) {
			sections.set(label, value);
			log.debug(`added new section: ${label}, with value: ${value}`);
		}
	}, "addSection"),
	getSections: /* @__PURE__ */ __name(() => sections, "getSections"),
	setShowData: /* @__PURE__ */ __name((toggle) => {
		showData = toggle;
	}, "setShowData"),
	getShowData: /* @__PURE__ */ __name(() => showData, "getShowData")
};
var populateDb = /* @__PURE__ */ __name((ast, db2) => {
	populateCommonDb(ast, db2);
	db2.setShowData(ast.showData);
	ast.sections.map(db2.addSection);
}, "populateDb");
var parser = { parse: /* @__PURE__ */ __name(async (input) => {
	const ast = await parse("pie", input);
	log.debug(ast);
	populateDb(ast, db);
}, "parse") };
var pieStyles_default = /* @__PURE__ */ __name((options) => `
  .pieCircle{
    stroke: ${options.pieStrokeColor};
    stroke-width : ${options.pieStrokeWidth};
    opacity : ${options.pieOpacity};
  }
  .pieOuterCircle{
    stroke: ${options.pieOuterStrokeColor};
    stroke-width: ${options.pieOuterStrokeWidth};
    fill: none;
  }
  .pieTitleText {
    text-anchor: middle;
    font-size: ${options.pieTitleTextSize};
    fill: ${options.pieTitleTextColor};
    font-family: ${options.fontFamily};
  }
  .slice {
    font-family: ${options.fontFamily};
    fill: ${options.pieSectionTextColor};
    font-size:${options.pieSectionTextSize};
    // fill: white;
  }
  .legend text {
    fill: ${options.pieLegendTextColor};
    font-family: ${options.fontFamily};
    font-size: ${options.pieLegendTextSize};
  }
`, "getStyles");
var createPieArcs = /* @__PURE__ */ __name((sections2) => {
	const sum = [...sections2.values()].reduce((acc, val) => acc + val, 0);
	const pieData = [...sections2.entries()].map(([label, value]) => ({
		label,
		value
	})).filter((d) => d.value / sum * 100 >= 1);
	return pie_default().value((d) => d.value).sort(null)(pieData);
}, "createPieArcs");
var diagram = {
	parser,
	db,
	renderer: { draw: /* @__PURE__ */ __name((text, id, _version, diagObj) => {
		log.debug("rendering pie chart\n" + text);
		const db2 = diagObj.db;
		const globalConfig = getConfig2();
		const pieConfig = cleanAndMerge(db2.getConfig(), globalConfig.pie);
		const MARGIN = 40;
		const LEGEND_RECT_SIZE = 18;
		const LEGEND_SPACING = 4;
		const height = 450;
		const pieWidth = height;
		const svg = selectSvgElement(id);
		const group = svg.append("g");
		group.attr("transform", "translate(225,225)");
		const { themeVariables } = globalConfig;
		let [outerStrokeWidth] = parseFontSize(themeVariables.pieOuterStrokeWidth);
		outerStrokeWidth ??= 2;
		const textPosition = pieConfig.textPosition;
		const radius = Math.min(pieWidth, height) / 2 - MARGIN;
		const arcGenerator = arc_default().innerRadius(0).outerRadius(radius);
		const labelArcGenerator = arc_default().innerRadius(radius * textPosition).outerRadius(radius * textPosition);
		group.append("circle").attr("cx", 0).attr("cy", 0).attr("r", radius + outerStrokeWidth / 2).attr("class", "pieOuterCircle");
		const sections2 = db2.getSections();
		const arcs = createPieArcs(sections2);
		const myGeneratedColors = [
			themeVariables.pie1,
			themeVariables.pie2,
			themeVariables.pie3,
			themeVariables.pie4,
			themeVariables.pie5,
			themeVariables.pie6,
			themeVariables.pie7,
			themeVariables.pie8,
			themeVariables.pie9,
			themeVariables.pie10,
			themeVariables.pie11,
			themeVariables.pie12
		];
		let sum = 0;
		sections2.forEach((section) => {
			sum += section;
		});
		const filteredArcs = arcs.filter((datum) => (datum.data.value / sum * 100).toFixed(0) !== "0");
		const color = ordinal(myGeneratedColors).domain([...sections2.keys()]);
		group.selectAll("mySlices").data(filteredArcs).enter().append("path").attr("d", arcGenerator).attr("fill", (datum) => {
			return color(datum.data.label);
		}).attr("class", "pieCircle");
		group.selectAll("mySlices").data(filteredArcs).enter().append("text").text((datum) => {
			return (datum.data.value / sum * 100).toFixed(0) + "%";
		}).attr("transform", (datum) => {
			return "translate(" + labelArcGenerator.centroid(datum) + ")";
		}).style("text-anchor", "middle").attr("class", "slice");
		const titleText = group.append("text").text(db2.getDiagramTitle()).attr("x", 0).attr("y", -400 / 2).attr("class", "pieTitleText");
		const allSectionData = [...sections2.entries()].map(([label, value]) => ({
			label,
			value
		}));
		const legend = group.selectAll(".legend").data(allSectionData).enter().append("g").attr("class", "legend").attr("transform", (_datum, index) => {
			const height2 = 22;
			const offset = height2 * allSectionData.length / 2;
			return "translate(216," + (index * height2 - offset) + ")";
		});
		legend.append("rect").attr("width", LEGEND_RECT_SIZE).attr("height", LEGEND_RECT_SIZE).style("fill", (d) => color(d.label)).style("stroke", (d) => color(d.label));
		legend.append("text").attr("x", 22).attr("y", LEGEND_RECT_SIZE - LEGEND_SPACING).text((d) => {
			if (db2.getShowData()) return `${d.label} [${d.value}]`;
			return d.label;
		});
		const chartAndLegendWidth = 512 + Math.max(...legend.selectAll("text").nodes().map((node) => node?.getBoundingClientRect().width ?? 0));
		const titleWidth = titleText.node()?.getBoundingClientRect().width ?? 0;
		const titleLeft = pieWidth / 2 - titleWidth / 2;
		const titleRight = pieWidth / 2 + titleWidth / 2;
		const viewBoxX = Math.min(0, titleLeft);
		const totalWidth = Math.max(chartAndLegendWidth, titleRight) - viewBoxX;
		svg.attr("viewBox", `${viewBoxX} 0 ${totalWidth} ${height}`);
		configureSvgSize(svg, height, totalWidth, pieConfig.useMaxWidth);
	}, "draw") },
	styles: pieStyles_default
};
//#endregion
export { diagram };

//# sourceMappingURL=pieDiagram-4H26LBE5-BVfsjEJS.js.map