import { H as __name } from "./src-BFTritsu.js";
//#region node_modules/mermaid/dist/chunks/mermaid.core/chunk-FMBD7UC4.mjs
var getIconStyles = /* @__PURE__ */ __name(() => `
  /* Font Awesome icon styling - consolidated */
  .label-icon {
    display: inline-block;
    height: 1em;
    overflow: visible;
    vertical-align: -0.125em;
  }
  
  .node .label-icon path {
    fill: currentColor;
    stroke: revert;
    stroke-width: revert;
  }
`, "getIconStyles");
//#endregion
export { getIconStyles as t };

//# sourceMappingURL=chunk-FMBD7UC4-XHAf4gn8.js.map