import { B as select_default, H as __name } from "./src-BFTritsu.js";
import { x as getConfig2 } from "./chunk-CSCIHK7Q-CtOBMFgQ.js";
//#region node_modules/mermaid/dist/chunks/mermaid.core/chunk-WU5MYG2G.mjs
var selectSvgElement = /* @__PURE__ */ __name((id) => {
	const { securityLevel } = getConfig2();
	let root = select_default("body");
	if (securityLevel === "sandbox") root = select_default((select_default(`#i${id}`).node()?.contentDocument ?? document).body);
	return root.select(`#${id}`);
}, "selectSvgElement");
//#endregion
export { selectSvgElement as t };

//# sourceMappingURL=chunk-WU5MYG2G-DqE-W9mY.js.map