import { at as Utils, it as Color } from "./chunk-CSCIHK7Q-CtOBMFgQ.js";
//#region node_modules/khroma/dist/methods/channel.js
var channel = (color, channel) => {
	return Utils.lang.round(Color.parse(color)[channel]);
};
//#endregion
export { channel as t };

//# sourceMappingURL=channel-Cgxxj64V.js.map