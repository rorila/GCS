import { H as __name } from "./src-BFTritsu.js";
//#region node_modules/mermaid/dist/chunks/mermaid.core/chunk-QZHKN3VN.mjs
var ImperativeState = class {
	/**
	* @param init - Function that creates the default state.
	*/
	constructor(init) {
		this.init = init;
		this.records = this.init();
	}
	static {
		__name(this, "ImperativeState");
	}
	reset() {
		this.records = this.init();
	}
};
//#endregion
export { ImperativeState as t };

//# sourceMappingURL=chunk-QZHKN3VN-CblZK_nI.js.map