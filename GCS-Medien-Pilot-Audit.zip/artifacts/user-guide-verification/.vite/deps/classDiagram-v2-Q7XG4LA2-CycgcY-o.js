import { H as __name } from "./src-BFTritsu.js";
import "./chunk-CSCIHK7Q-CtOBMFgQ.js";
import "./chunk-5ZQYHXKU-UjcI8I9R.js";
import "./chunk-BSJP7CBP-CWPjFAHg.js";
import "./chunk-L5ZTLDWV-CbQVxUrJ.js";
import "./chunk-NZK2D7GU-8piYZBx-.js";
import "./chunk-O5CBEL6O-BMotHkza.js";
import "./chunk-3OPIFGDE-4uZiM6GZ.js";
import "./chunk-KSCS5N6A-DnmGFall.js";
import "./chunk-LZXEDZCA-D7V2YBhx.js";
import "./chunk-FMBD7UC4-XHAf4gn8.js";
import "./chunk-ND2GUHAM-Cq8XYYOW.js";
import "./chunk-55IACEB6-P6R6YxcE.js";
import "./chunk-2J33WTMH-DrCjK793.js";
import { i as styles_default, n as classDiagram_default, r as classRenderer_v3_unified_default, t as ClassDB } from "./chunk-727SXJPM-DGPUIv7x.js";
//#region node_modules/mermaid/dist/chunks/mermaid.core/classDiagram-v2-Q7XG4LA2.mjs
var diagram = {
	parser: classDiagram_default,
	get db() {
		return new ClassDB();
	},
	renderer: classRenderer_v3_unified_default,
	styles: styles_default,
	init: /* @__PURE__ */ __name((cnf) => {
		if (!cnf.class) cnf.class = {};
		cnf.class.arrowMarkerAbsolute = cnf.arrowMarkerAbsolute;
	}, "init")
};
//#endregion
export { diagram };

//# sourceMappingURL=classDiagram-v2-Q7XG4LA2-CycgcY-o.js.map