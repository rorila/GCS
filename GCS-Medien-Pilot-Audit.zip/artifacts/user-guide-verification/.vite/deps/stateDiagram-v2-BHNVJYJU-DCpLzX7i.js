import { H as __name } from "./src-BFTritsu.js";
import "./chunk-CSCIHK7Q-CtOBMFgQ.js";
import "./chunk-5ZQYHXKU-UjcI8I9R.js";
import "./chunk-BSJP7CBP-CWPjFAHg.js";
import "./chunk-L5ZTLDWV-CbQVxUrJ.js";
import "./chunk-NZK2D7GU-8piYZBx-.js";
import "./chunk-O5CBEL6O-BMotHkza.js";
import "./chunk-3OPIFGDE-4uZiM6GZ.js";
import "./chunk-KSCS5N6A-DnmGFall.js";
import "./chunk-LZXEDZCA-D7V2YBhx.js";
import "./chunk-55IACEB6-P6R6YxcE.js";
import "./chunk-2J33WTMH-DrCjK793.js";
import { i as styles_default, n as stateDiagram_default, r as stateRenderer_v3_unified_default, t as StateDB } from "./chunk-AQP2D5EJ-BeiTvBc0.js";
//#region node_modules/mermaid/dist/chunks/mermaid.core/stateDiagram-v2-BHNVJYJU.mjs
var diagram = {
	parser: stateDiagram_default,
	get db() {
		return new StateDB(2);
	},
	renderer: stateRenderer_v3_unified_default,
	styles: styles_default,
	init: /* @__PURE__ */ __name((cnf) => {
		if (!cnf.state) cnf.state = {};
		cnf.state.arrowMarkerAbsolute = cnf.arrowMarkerAbsolute;
	}, "init")
};
//#endregion
export { diagram };

//# sourceMappingURL=stateDiagram-v2-BHNVJYJU-DCpLzX7i.js.map